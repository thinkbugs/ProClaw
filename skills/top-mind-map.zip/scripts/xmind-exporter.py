#!/usr/bin/env python3
"""
思维导图软件格式导出工具
支持导出为XMind、FreeMind、MindManager等主流思维导图软件可导入的格式
"""

import argparse
import json
import sys
import zipfile
import tempfile
import os
import uuid
from typing import Dict, Any, List
from xml.etree import ElementTree as ET
from xml.dom import minidom


def load_json_file(filepath: str) -> Dict[str, Any]:
    """加载JSON文件"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"错误：文件 '{filepath}' 不存在", file=sys.stderr)
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"错误：JSON解析失败 - {e}", file=sys.stderr)
        sys.exit(1)


def prettify_xml(element: ET.Element) -> str:
    """美化XML输出"""
    rough_string = ET.tostring(element, 'utf-8')
    reparsed = minidom.parseString(rough_string)
    return reparsed.toprettyxml(indent="  ")


def export_to_xmind(data: Dict[str, Any]) -> str:
    """
    导出为XMind格式（.xmind文件，实际是zip压缩包）
    
    参数：
        data: 思维导图JSON数据
        
    返回：
        XMind文件内容（需要在临时文件中创建zip）
    """
    # XMind使用XML格式，但最终打包为zip
    # 创建content.xml
    root = ET.Element('xmap-content')
    root.set('xmlns', 'urn:xmind:xmap:xmlns:content:2.0')
    root.set('xmlns:fo', 'http://www.w3.org/1999/XSL/Format')
    
    # 创建sheet
    sheet = ET.SubElement(root, 'sheet')
    sheet.set('id', str(uuid.uuid4()))
    
    # 创建topic（根节点）
    topic = ET.SubElement(sheet, 'topic')
    topic.set('id', str(uuid.uuid4()))
    
    title = ET.SubElement(topic, 'title')
    title.text = data.get('title', '思维导图')
    
    # 添加描述
    description = data.get('description', '')
    if description:
        notes = ET.SubElement(topic, 'notes')
        plain = ET.SubElement(notes, 'plain')
        plain_content = ET.SubElement(plain, 'content')
        plain_content.text = description
    
    # 递归添加子节点
    def add_children(parent_topic: ET.Element, nodes: List[Dict[str, Any]]):
        for node in nodes:
            child_topic = ET.SubElement(parent_topic, 'topic')
            child_topic.set('id', str(uuid.uuid4()))
            
            # 添加标题
            child_title = ET.SubElement(child_topic, 'title')
            child_title.text = node.get('name', '未命名')
            
            # 添加描述
            node_desc = node.get('description', '')
            if node_desc:
                child_notes = ET.SubElement(child_topic, 'notes')
                child_plain = ET.SubElement(child_notes, 'plain')
                child_plain_content = ET.SubElement(child_plain, 'content')
                child_plain_content.text = node_desc
            
            # 递归添加子节点
            children = node.get('children', [])
            if children:
                add_children(child_topic, children)
    
    # 添加主分支
    add_children(topic, data.get('branches', []))
    
    # 生成XML
    xml_content = prettify_xml(root)
    
    return xml_content


def export_to_xmind_zip(data: Dict[str, Any], output_path: str):
    """
    创建XMind zip文件
    
    参数：
        data: 思维导图JSON数据
        output_path: 输出文件路径
    """
    # 创建content.xml
    content_xml = export_to_xmind(data)
    
    # 创建manifest.xml
    manifest = ET.Element('manifest')
    manifest.set('xmlns', 'urn:xmind:xmap:xmlns:manifest:1.0')
    
    file_entry = ET.SubElement(manifest, 'file-entry')
    file_entry.set('full-path', 'content.xml')
    file_entry.set('media-type', 'text/xml')
    
    manifest_xml = prettify_xml(manifest)
    
    # 创建meta.xml
    meta = ET.Element('meta')
    meta.set('xmlns', 'urn:xmind:xmap:xmlns:meta:2.0')
    
    creator = ET.SubElement(meta, 'Creator')
    creator.text = 'top-mind-map'
    
    meta_xml = prettify_xml(meta)
    
    # 创建styles.xml
    styles = ET.Element('xmap-styles')
    styles.set('xmlns', 'urn:xmind:xmap:xmlns:style:2.0')
    
    styles_xml = prettify_xml(styles)
    
    # 创建zip文件
    with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.writestr('content.xml', content_xml)
        zf.writestr('META-INF/manifest.xml', manifest_xml)
        zf.writestr('meta.xml', meta_xml)
        zf.writestr('styles.xml', styles_xml)
    
    print(f"XMind文件已创建：{output_path}")


def export_to_freemind(data: Dict[str, Any]) -> str:
    """
    导出为FreeMind格式（.mm文件，XML格式）
    
    参数：
        data: 思维导图JSON数据
        
    返回：
        FreeMind格式的XML字符串
    """
    # FreeMind使用XML格式
    root = ET.Element('map')
    root.set('version', '1.0.1')
    
    # 创建根节点
    node = ET.SubElement(root, 'node')
    node.set('ID', str(uuid.uuid4()))
    node.set('TEXT', data.get('title', '思维导图'))
    
    # 添加描述
    description = data.get('description', '')
    if description:
        node.set('NOTE', description)
    
    # 递归添加子节点
    def add_children(parent_node: ET.Element, nodes: List[Dict[str, Any]]):
        for node_data in nodes:
            child_node = ET.SubElement(parent_node, 'node')
            child_node.set('ID', str(uuid.uuid4()))
            child_node.set('TEXT', node_data.get('name', '未命名'))
            
            # 添加描述
            node_desc = node_data.get('description', '')
            if node_desc:
                child_node.set('NOTE', node_desc)
            
            # 递归添加子节点
            children = node_data.get('children', [])
            if children:
                add_children(child_node, children)
    
    # 添加主分支
    add_children(node, data.get('branches', []))
    
    # 生成XML
    xml_content = prettify_xml(root)
    
    return xml_content


def export_to_opml(data: Dict[str, Any]) -> str:
    """
    导出为OPML格式（通用大纲格式，多软件支持）
    
    参数：
        data: 思维导图JSON数据
        
    返回：
        OPML格式的XML字符串
    """
    # OPML使用XML格式
    root = ET.Element('opml')
    root.set('version', '2.0')
    
    head = ET.SubElement(root, 'head')
    title = ET.SubElement(head, 'title')
    title.text = data.get('title', '思维导图')
    
    description = data.get('description', '')
    if description:
        desc = ET.SubElement(head, 'description')
        desc.text = description
    
    body = ET.SubElement(root, 'body')
    
    # 递归添加子节点
    def add_outline(parent: ET.Element, nodes: List[Dict[str, Any]]):
        for node_data in nodes:
            outline = ET.SubElement(parent, 'outline')
            outline.set('text', node_data.get('name', '未命名'))
            
            # 添加描述
            node_desc = node_data.get('description', '')
            if node_desc:
                outline.set('_note', node_desc)
            
            # 递归添加子节点
            children = node_data.get('children', [])
            if children:
                add_outline(outline, children)
    
    # 添加主分支
    add_outline(body, data.get('branches', []))
    
    # 生成XML
    xml_content = prettify_xml(root)
    
    return xml_content


def export_to_markdown_outline(data: Dict[str, Any]) -> str:
    """
    导出为Markdown大纲格式（兼容多种软件）
    
    参数：
        data: 思维导图JSON数据
        
    返回：
        Markdown大纲格式的字符串
    """
    lines = [
        f"# {data.get('title', '思维导图')}",
        ""
    ]
    
    if data.get('description'):
        lines.append(f"{data.get('description')}")
        lines.append("")
    
    # 递归添加节点
    def add_outline(level: int, nodes: List[Dict[str, Any]]):
        prefix = "  " * (level - 1)
        for node in nodes:
            name = node.get('name', '未命名')
            desc = node.get('description', '')
            
            lines.append(f"{prefix}* {name}")
            if desc:
                lines.append(f"{prefix}  {desc}")
            
            # 递归添加子节点
            children = node.get('children', [])
            if children:
                add_outline(level + 1, children)
    
    # 添加主分支
    add_outline(1, data.get('branches', []))
    
    return '\n'.join(lines)


def export_to_txt_indented(data: Dict[str, Any]) -> str:
    """
    导出为缩进文本格式（最通用的格式）
    
    参数：
        data: 思维导图JSON数据
        
    返回：
        缩进文本格式的字符串
    """
    lines = [
        f"{data.get('title', '思维导图')}"
    ]
    
    if data.get('description'):
        lines.append(f"{data.get('description')}")
    
    lines.append("")
    
    # 递归添加节点
    def add_indented(level: int, nodes: List[Dict[str, Any]]):
        prefix = "    " * level
        for node in nodes:
            name = node.get('name', '未命名')
            desc = node.get('description', '')
            
            lines.append(f"{prefix}- {name}")
            if desc:
                lines.append(f"{prefix}  {desc}")
            
            # 递归添加子节点
            children = node.get('children', [])
            if children:
                add_indented(level + 1, children)
    
    # 添加主分支
    add_indented(0, data.get('branches', []))
    
    return '\n'.join(lines)


def main():
    parser = argparse.ArgumentParser(
        description='思维导图软件格式导出工具'
    )
    parser.add_argument(
        '--format',
        choices=['xmind', 'freemind', 'opml', 'markdown-outline', 'txt-indented'],
        required=True,
        help='输出格式：xmind（XMind格式）、freemind（FreeMind格式）、opml（OPML格式）、markdown-outline（Markdown大纲）、txt-indented（缩进文本）'
    )
    parser.add_argument(
        '--input',
        required=True,
        help='输入的思维导图JSON文件路径'
    )
    parser.add_argument(
        '--output',
        required=True,
        help='输出文件路径'
    )
    
    args = parser.parse_args()
    
    # 加载思维导图数据
    data = load_json_file(args.input)
    
    # 根据格式生成输出
    if args.format == 'xmind':
        export_to_xmind_zip(data, args.output)
    elif args.format == 'freemind':
        content = export_to_freemind(data)
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"成功导出到：{args.output}")
    elif args.format == 'opml':
        content = export_to_opml(data)
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"成功导出到：{args.output}")
    elif args.format == 'markdown-outline':
        content = export_to_markdown_outline(data)
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"成功导出到：{args.output}")
    elif args.format == 'txt-indented':
        content = export_to_txt_indented(data)
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"成功导出到：{args.output}")
    else:
        print(f"错误：不支持的格式 '{args.format}'", file=sys.stderr)
        sys.exit(1)
    
    print(f"格式：{args.format}")


if __name__ == '__main__':
    main()
