#!/usr/bin/env python3
"""
多格式思维导图导出工具
支持将JSON格式的思维导图数据转换为Mermaid、Markdown表格、增强JSON等格式
"""

import argparse
import json
import sys
from typing import Dict, Any


def load_json_file(filepath: str) -> Dict[str, Any]:
    """加载JSON文件"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"错误：文件 '{filepath}' 不存在", file=sys.stderr)
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"错误：JSON解析失败 - {e}", file=sys.stderr)
        sys.exit(1)


def export_to_mermaid(data: Dict[str, Any]) -> str:
    """
    将思维导图数据转换为Mermaid格式
    
    参数：
        data: 思维导图JSON数据
        
    返回：
        Mermaid格式的字符串
    """
    lines = [
        "mindmap",
        "  root(({}))".format(data.get('title', '思维导图'))
    ]
    
    # 递归生成节点
    def add_node(node: Dict[str, Any], level: int):
        indent = "  " * (level + 1)
        name = node.get('name', '未命名')
        desc = node.get('description', '')
        
        # 添加节点
        if desc:
            lines.append(f"{indent}{name}")
            lines.append(f"{indent}::{desc}")
        else:
            lines.append(f"{indent}{name}")
        
        # 递归处理子节点
        children = node.get('children', [])
        for child in children:
            add_node(child, level + 1)
    
    # 处理主分支
    for branch in data.get('branches', []):
        add_node(branch, 0)
    
    return '\n'.join(lines)


def export_to_markdown_table(data: Dict[str, Any]) -> str:
    """
    将思维导图数据转换为Markdown表格格式
    
    参数：
        data: 思维导图JSON数据
        
    返回：
        Markdown表格格式的字符串
    """
    lines = [
        f"# {data.get('title', '思维导图')}",
        "",
        "## 节点结构",
        "",
        "| 层级 | 节点名称 | 描述 |",
        "|------|----------|------|"
    ]
    
    # 递归添加节点到表格
    def add_node_to_table(node: Dict[str, Any], level: int):
        indent = "  " * level
        name = node.get('name', '未命名')
        desc = node.get('description', '')
        
        lines.append(f"| L{level} | {indent}{name} | {desc} |")
        
        # 递归处理子节点
        for child in node.get('children', []):
            add_node_to_table(child, level + 1)
    
    # 处理主分支
    for branch in data.get('branches', []):
        add_node_to_table(branch, 1)
    
    return '\n'.join(lines)


def export_to_enhanced_json(data: Dict[str, Any]) -> str:
    """
    生成增强的JSON格式（添加元数据和统计信息）
    
    参数：
        data: 思维导图JSON数据
        
    返回：
        增强JSON字符串
    """
    # 计算节点统计
    def count_nodes(node: Dict[str, Any]) -> int:
        count = 1
        for child in node.get('children', []):
            count += count_nodes(child)
        return count
    
    total_nodes = sum(count_nodes(branch) for branch in data.get('branches', []))
    
    # 添加元数据
    enhanced = {
        'metadata': {
            'version': '1.0',
            'generated_by': 'top-mind-map',
            'total_nodes': total_nodes + 1,  # +1 for root
            'max_depth': calculate_max_depth(data)
        },
        'data': data
    }
    
    return json.dumps(enhanced, ensure_ascii=False, indent=2)


def calculate_max_depth(data: Dict[str, Any]) -> int:
    """计算思维导图的最大深度"""
    def get_depth(node: Dict[str, Any]) -> int:
        if not node.get('children'):
            return 0
        return 1 + max(get_depth(child) for child in node['children'])
    
    depths = [get_depth(branch) for branch in data.get('branches', [])]
    return max(depths) + 1 if depths else 1


def main():
    parser = argparse.ArgumentParser(
        description='多格式思维导图导出工具'
    )
    parser.add_argument(
        '--format',
        choices=['mermaid', 'markdown', 'json'],
        required=True,
        help='输出格式：mermaid（Mermaid图）、markdown（Markdown表格）、json（增强JSON）'
    )
    parser.add_argument(
        '--input',
        required=True,
        help='输入的JSON文件路径'
    )
    parser.add_argument(
        '--output',
        required=True,
        help='输出文件路径'
    )
    
    args = parser.parse_args()
    
    # 加载输入数据
    data = load_json_file(args.input)
    
    # 根据格式生成输出
    if args.format == 'mermaid':
        content = export_to_mermaid(data)
    elif args.format == 'markdown':
        content = export_to_markdown_table(data)
    elif args.format == 'json':
        content = export_to_enhanced_json(data)
    else:
        print(f"错误：不支持的格式 '{args.format}'", file=sys.stderr)
        sys.exit(1)
    
    # 写入输出文件
    try:
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"成功导出到：{args.output}")
    except IOError as e:
        print(f"错误：写入文件失败 - {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
