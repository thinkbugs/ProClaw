#!/usr/bin/env python3
"""
价值网络导出工具
支持将思维导图中的关键价值点和互链关系导出为多种可视化格式
"""

import argparse
import json
import sys
from typing import Dict, Any, List


def load_json_file(filepath: str) -> Dict[str, Any]:
    """加载JSON文件"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"错误：文件 '{filepath}' 不存在", file=sys.stderr)
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"错误：JSON解析失败 - {e}", file=sys.stderr)
        sys.exit(1)


def export_to_mermaid_graph(data: Dict[str, Any]) -> str:
    """
    导出为Mermaid图格式（价值网络图）

    参数：
        data: 思维导图JSON数据（包含价值网络）

    返回：
        Mermaid图格式的字符串
    """
    lines = [
        "graph TD",
        "    %% 价值点定义",
        ""
    ]
    
    # 生成价值点
    value_points = data.get('value_points', [])
    value_point_map = {}
    
    for vp in value_points:
        vp_id = vp.get('id', 'unknown')
        name = vp.get('name', '未命名')
        weight = vp.get('weight', 5)
        
        # 根据权重选择样式
        if weight >= 9:
            style = "fill:#ff6b6b,stroke:#c92a2a,stroke-width:3px"
        elif weight >= 7:
            style = "fill:#ffd43b,stroke:#f08c00,stroke-width:2px"
        else:
            style = "fill:#b2f2bb,stroke:#40c057,stroke-width:2px"
        
        # 生成节点
        lines.append(f"    {vp_id}[{name}]")
        lines.append(f"    style {vp_id} {style}")
        lines.append("")
    
        # 生成注释
        annotations = vp.get('annotations', [])
        if annotations:
            lines.append(f"    %% {vp_id} 注释")
            for ann in annotations:
                ann_type = ann.get('type', '')
                ann_content = ann.get('content', '')
                lines.append(f"    %% {ann_type}: {ann_content}")
            lines.append("")
        
        value_point_map[vp.get('node_ref', '')] = vp_id
    
    # 生成互链关系
    lines.append("    %% 互链关系")
    lines.append("")
    
    value_links = data.get('value_links', [])
    
    for link in value_links:
        source = link.get('source', '')
        target = link.get('target', '')
        link_type = link.get('type', '关联')
        strength = link.get('strength', 5)
        direction = link.get('direction', 'forward')
        
        # 生成连接线样式
        if strength >= 8:
            line_style = "==>"
        elif strength >= 6:
            line_style = "-->"
        else:
            line_style = "-.->"
        
        # 生成连接关系
        if direction == 'bidirectional':
            lines.append(f"    {source} {line_style}|{link_type}| {target}")
            lines.append(f"    {target} {line_style}|{link_type}| {source}")
        else:
            lines.append(f"    {source} {line_style}|{link_type}| {target}")
        
        # 生成注释
        annotations = link.get('annotations', [])
        if annotations:
            lines.append(f"    %% 关系注释")
            for ann in annotations:
                ann_content = ann.get('content', '')
                lines.append(f"    %% {ann_content}")
            lines.append("")
    
    lines.append("")
    lines.append("    %% 图例")
    lines.append("    classDef high fill:#ff6b6b,stroke:#c92a2a,stroke-width:3px")
    lines.append("    classDef medium fill:#ffd43b,stroke:#f08c00,stroke-width:2px")
    lines.append("    classDef low fill:#b2f2bb,stroke:#40c057,stroke-width:2px")
    
    return '\n'.join(lines)


def export_to_html_network(data: Dict[str, Any]) -> str:
    """
    导出为HTML交互图格式

    参数：
        data: 思维导图JSON数据（包含价值网络）

    返回：
        HTML交互图格式的字符串
    """
    title = data.get('title', '价值网络图')
    description = data.get('description', '')
    value_points = data.get('value_points', [])
    value_links = data.get('value_links', [])
    
    # 计算节点位置（简单布局）
    positions = {}
    for i, vp in enumerate(value_points):
        x = (i % 4) * 200 + 100
        y = (i // 4) * 150 + 100
        positions[vp['id']] = {'x': x, 'y': y}
    
    html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title} - 价值网络</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
        }}
        
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 16px;
            padding: 30px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2);
        }}
        
        .header {{
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #eee;
        }}
        
        .header h1 {{
            color: #333;
            font-size: 32px;
            margin-bottom: 10px;
        }}
        
        .header p {{
            color: #666;
            font-size: 16px;
        }}
        
        .network-container {{
            position: relative;
            height: 500px;
            background: #f8f9fa;
            border-radius: 12px;
            margin-bottom: 30px;
            overflow: hidden;
        }}
        
        .value-point {{
            position: absolute;
            padding: 15px 20px;
            border-radius: 10px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            min-width: 120px;
            text-align: center;
        }}
        
        .value-point:hover {{
            transform: translateY(-3px);
            box-shadow: 0 8px 12px rgba(0, 0, 0, 0.15);
        }}
        
        .value-point.high {{
            background: linear-gradient(135deg, #ff6b6b 0%, #ee5a5a 100%);
            color: white;
            border: 3px solid #c92a2a;
        }}
        
        .value-point.medium {{
            background: linear-gradient(135deg, #ffd43b 0%, #fcc419 100%);
            color: #333;
            border: 2px solid #f08c00;
        }}
        
        .value-point.low {{
            background: linear-gradient(135deg, #b2f2bb 0%, #8ce99a 100%);
            color: #333;
            border: 2px solid #40c057;
        }}
        
        .connection {{
            position: absolute;
            height: 2px;
            background: #999;
            transform-origin: left center;
            pointer-events: none;
        }}
        
        .annotations {{
            margin-top: 20px;
        }}
        
        .annotation-section {{
            background: #f8f9fa;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
            border-left: 4px solid #667eea;
        }}
        
        .annotation-section h3 {{
            color: #333;
            font-size: 18px;
            margin-bottom: 10px;
        }}
        
        .annotation-item {{
            margin-bottom: 8px;
            padding-left: 20px;
        }}
        
        .annotation-type {{
            font-weight: 600;
            color: #667eea;
        }}
        
        .annotation-content {{
            color: #666;
            margin-left: 10px;
        }}
        
        .link-legend {{
            display: flex;
            gap: 20px;
            margin-top: 20px;
            justify-content: center;
        }}
        
        .legend-item {{
            display: flex;
            align-items: center;
            gap: 8px;
        }}
        
        .legend-line {{
            width: 40px;
            height: 2px;
            background: #999;
        }}
        
        .legend-line.causal {{
            border-top: 3px solid #ff6b6b;
            border-style: solid;
        }}
        
        .legend-line.dependency {{
            border-top: 2px dashed #ffd43b;
        }}
        
        .legend-line.logical {{
            border-top: 1px dotted #40c057;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>{title}</h1>
            <p>{description}</p>
        </div>
        
        <div class="network-container" id="network">
"""
    
    # 生成连接线
    for link in value_links:
        source_id = link.get('source', '')
        target_id = link.get('target', '')
        
        if source_id in positions and target_id in positions:
            source_pos = positions[source_id]
            target_pos = positions[target_id]
            
            # 计算连接线位置和角度
            dx = target_pos['x'] - source_pos['x']
            dy = target_pos['y'] - source_pos['y']
            length = (dx**2 + dy**2)**0.5
            angle = (dy / dx) * (180 / 3.14159265359) if dx != 0 else 90
            
            # 根据关系类型选择样式
            link_type = link.get('type', '关联')
            if link_type == '因果关系':
                line_style = "causal"
            elif link_type == '依赖关系':
                line_style = "dependency"
            else:
                line_style = "logical"
            
            html += f'''
            <div class="connection {line_style}" style="
                left: {source_pos['x'] + 60}px;
                top: {source_pos['y'] + 20}px;
                width: {length}px;
                transform: rotate({angle}deg);
            "></div>'''
    
    # 生成价值点
    for vp in value_points:
        weight = vp.get('weight', 5)
        vp_id = vp.get('id', '')
        name = vp.get('name', '未命名')
        pos = positions.get(vp_id, {'x': 100, 'y': 100})
        
        if weight >= 9:
            level_class = 'high'
        elif weight >= 7:
            level_class = 'medium'
        else:
            level_class = 'low'
        
        html += f'''
            <div class="value-point {level_class}" style="
                left: {pos['x']}px;
                top: {pos['y']}px;
            " onclick="showAnnotations('{vp_id}')">
                {name}
            </div>'''
    
    html += '''
        </div>
        
        <div class="link-legend">
            <div class="legend-item">
                <div class="legend-line causal"></div>
                <span>因果关系</span>
            </div>
            <div class="legend-item">
                <div class="legend-line dependency"></div>
                <span>依赖关系</span>
            </div>
            <div class="legend-item">
                <div class="legend-line logical"></div>
                <span>逻辑关联</span>
            </div>
        </div>
        
        <div class="annotations" id="annotations">
            <h2>价值点注释</h2>
'''
    
    # 生成注释
    for vp in value_points:
        vp_id = vp.get('id', '')
        name = vp.get('name', '未命名')
        annotations = vp.get('annotations', [])
        
        html += f'''
            <div class="annotation-section" id="annotations-{vp_id}">
                <h3>{name}</h3>
'''
        
        for ann in annotations:
            ann_type = ann.get('type', '')
            ann_content = ann.get('content', '')
            html += f'''
                <div class="annotation-item">
                    <span class="annotation-type">{ann_type}:</span>
                    <span class="annotation-content">{ann_content}</span>
                </div>'''
        
        html += '''
            </div>
'''
    
    html += '''
        </div>
    </div>
    
    <script>
        function showAnnotations(vpId) {
            const allSections = document.querySelectorAll('.annotation-section');
            allSections.forEach(section => {
                section.style.display = 'none';
            });
            
            const targetSection = document.getElementById('annotations-' + vpId);
            if (targetSection) {
                targetSection.style.display = 'block';
                targetSection.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            }
        }
    </script>
</body>
</html>'''
    
    return html


def export_to_value_network_json(data: Dict[str, Any]) -> str:
    """
    导出为价值网络JSON格式（独立的价值网络数据）

    参数：
        data: 思维导图JSON数据（包含价值网络）

    返回：
        价值网络JSON字符串
    """
    network_data = {
        "title": data.get('title', '价值网络'),
        "description": data.get('description', ''),
        "metadata": data.get('value_network_metadata', {}),
        "value_points": data.get('value_points', []),
        "value_links": data.get('value_links', [])
    }
    
    return json.dumps(network_data, ensure_ascii=False, indent=2)


def main():
    parser = argparse.ArgumentParser(
        description='价值网络导出工具'
    )
    parser.add_argument(
        '--format',
        choices=['mermaid', 'html', 'json'],
        required=True,
        help='输出格式：mermaid（Mermaid图）、html（HTML交互图）、json（价值网络JSON）'
    )
    parser.add_argument(
        '--input',
        required=True,
        help='输入的思维导图JSON文件路径'
    )
    parser.add_argument(
        '--output',
        required=True,
        help='输出文件路径'
    )
    
    args = parser.parse_args()
    
    # 加载思维导图数据
    data = load_json_file(args.input)
    
    # 检查是否包含价值网络数据
    if 'value_points' not in data or 'value_links' not in data:
        print("警告：输入文件不包含价值网络数据，请使用带价值网络的模板", file=sys.stderr)
        print("提示：可以使用 assets/templates/mindmap-with-value-network.json 作为模板", file=sys.stderr)
    
    # 根据格式生成输出
    if args.format == 'mermaid':
        content = export_to_mermaid_graph(data)
    elif args.format == 'html':
        content = export_to_html_network(data)
    elif args.format == 'json':
        content = export_to_value_network_json(data)
    else:
        print(f"错误：不支持的格式 '{args.format}'", file=sys.stderr)
        sys.exit(1)
    
    # 写入输出文件
    try:
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"成功导出到：{args.output}")
        print(f"格式：{args.format}")
    except IOError as e:
        print(f"错误：写入文件失败 - {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
