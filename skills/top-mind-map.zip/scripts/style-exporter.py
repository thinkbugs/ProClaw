#!/usr/bin/env python3
"""
精美样式导出工具
支持将思维导图导出为多种精美可视化格式，包括HTML、PlantUML、Mermaid（带样式）等
"""

import argparse
import json
import sys
from typing import Dict, Any


def load_json_file(filepath: str) -> Dict[str, Any]:
    """加载JSON文件"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"错误：文件 '{filepath}' 不存在", file=sys.stderr)
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"错误：JSON解析失败 - {e}", file=sys.stderr)
        sys.exit(1)


def generate_colors(index: int, total: int) -> str:
    """
    生成颜色调色板（渐变色）
    
    参数：
        index: 当前索引
        total: 总数
        
    返回：
        颜色代码
    """
    # 预定义的精美配色方案
    color_palettes = [
        ["#4E79A7", "#F28E2B", "#E15759", "#76B7B2", "#59A14F"],  # 经典配色
        ["#6366F1", "#8B5CF6", "#EC4899", "#F43F5E", "#F97316"],  # 紫色渐变
        ["#10B981", "#3B82F6", "#6366F1", "#8B5CF6", "#EC4899"],  # 现代渐变
        ["#264653", "#2A9D8F", "#E9C46A", "#F4A261", "#E76F51"],  # 自然配色
        ["#003049", "#D62828", "#F77F00", "#FCBF49", "#EAE2B7"],  # 强对比配色
    ]
    
    # 选择配色方案
    palette_idx = 0
    color = color_palettes[palette_idx][index % len(color_palettes[palette_idx])]
    
    return color


def export_to_mermaid_styled(data: Dict[str, Any], style: str = "default") -> str:
    """
    导出为带样式的Mermaid格式
    
    参数：
        data: 思维导图JSON数据
        style: 样式风格
        
    返回：
        Mermaid格式的字符串
    """
    lines = [
        "%%{init: {'theme': 'base', 'themeVariables': { 'primaryColor': '#f0f0f0', 'primaryTextColor': '#333', 'primaryBorderColor': '#ccc', 'lineColor': '#666', 'sectionBkgColor': '#e0e0e0', 'altSectionBkgColor': '#f0f0f0'}}}%%",
        "mindmap",
        "  root((<b>{}</b>))".format(data.get('title', '思维导图'))
    ]
    
    # 递归生成节点
    def add_node(node: Dict[str, Any], level: int, branch_idx: int = 0):
        indent = "  " * (level + 1)
        name = node.get('name', '未命名')
        desc = node.get('description', '')
        
        # 根据层级应用不同的样式
        if level == 0:
            # 主分支
            color = generate_colors(branch_idx, 10)
            if desc:
                lines.append(f"{indent}{{{name}}}")
                lines.append(f"{indent}::{desc}")
            else:
                lines.append(f"{indent}{{{name}}}")
        elif level == 1:
            # 子节点
            lines.append(f"{indent}[{name}]")
            if desc:
                lines.append(f"{indent}::{desc}")
        else:
            # 细节节点
            lines.append(f"{indent}{name}")
            if desc:
                lines.append(f"{indent}::{desc}")
        
        # 递归处理子节点
        children = node.get('children', [])
        for i, child in enumerate(children):
            add_node(child, level + 1, branch_idx)
    
    # 处理主分支
    for i, branch in enumerate(data.get('branches', [])):
        add_node(branch, 0, i)
    
    return '\n'.join(lines)


def export_to_plantuml(data: Dict[str, Any], style: str = "default") -> str:
    """
    导出为PlantUML格式（支持丰富样式）
    
    参数：
        data: 思维导图JSON数据
        style: 样式风格
        
    返回：
        PlantUML格式的字符串
    """
    lines = [
        "@startmindmap",
        "* <b>{}</b>".format(data.get('title', '思维导图')),
        "",
        "!'样式定义'",
        "skinparam backgroundColor #FFFFFF",
        "skinparam defaultFontColor #333333",
        "skinparam nodeBackgroundColor #F8F9FA",
        "skinparam nodeBorderColor #DEE2E6",
        "skinparam nodeFontColor #212529",
        "skinparam lineColor #ADB5BD",
        "skinparam arrowColor #ADB5BD",
        ""
    ]
    
    # 递归生成节点
    def add_node(node: Dict[str, Any], level: int, branch_idx: int = 0):
        prefix = "*" * (level + 2)
        name = node.get('name', '未命名')
        desc = node.get('description', '')
        
        # 根据层级应用样式
        if level == 0:
            # 主分支 - 使用不同颜色
            color = generate_colors(branch_idx, 10)
            lines.append(f"{prefix} <back:{color}><color:white>{name}</color></back>")
            if desc:
                lines.append(f"{prefix}++ {desc}")
        elif level == 1:
            # 子节点
            lines.append(f"{prefix} {name}")
            if desc:
                lines.append(f"{prefix}** {desc}")
        else:
            # 细节节点
            lines.append(f"{prefix} {name}")
            if desc:
                lines.append(f"{prefix}_ {desc}")
        
        # 递归处理子节点
        children = node.get('children', [])
        for i, child in enumerate(children):
            add_node(child, level + 1, branch_idx)
    
    # 处理主分支
    for i, branch in enumerate(data.get('branches', [])):
        add_node(branch, 0, i)
    
    lines.append("")
    lines.append("@endmindmap")
    
    return '\n'.join(lines)


def export_to_html(data: Dict[str, Any], style: str = "modern") -> str:
    """
    导出为HTML格式（交互式可视化）
    
    参数：
        data: 思维导图JSON数据
        style: 样式风格
        
    返回：
        HTML格式的字符串
    """
    # 样式定义
    styles = {
        "modern": {
            "primary": "#6366F1",
            "secondary": "#8B5CF6",
            "background": "#F8FAFC",
            "card_bg": "#FFFFFF",
            "text": "#1E293B",
            "border": "#E2E8F0"
        },
        "elegant": {
            "primary": "#0F172A",
            "secondary": "#334155",
            "background": "#F1F5F9",
            "card_bg": "#FFFFFF",
            "text": "#1E293B",
            "border": "#CBD5E1"
        },
        "colorful": {
            "primary": "#F59E0B",
            "secondary": "#EF4444",
            "background": "#FFFBEB",
            "card_bg": "#FFFFFF",
            "text": "#1F2937",
            "border": "#FCD34D"
        }
    }
    
    theme = styles.get(style, styles["modern"])
    
    # HTML模板
    html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{data.get('title', '思维导图')}</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif;
            background: linear-gradient(135deg, {theme['background']} 0%, {theme['card_bg']} 100%);
            min-height: 100vh;
            padding: 40px 20px;
        }}
        
        .container {{
            max-width: 1400px;
            margin: 0 auto;
        }}
        
        .header {{
            text-align: center;
            margin-bottom: 40px;
            padding: 30px;
            background: linear-gradient(135deg, {theme['primary']} 0%, {theme['secondary']} 100%);
            border-radius: 16px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
        }}
        
        .header h1 {{
            color: white;
            font-size: 36px;
            font-weight: 700;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2);
        }}
        
        .header p {{
            color: rgba(255, 255, 255, 0.9);
            font-size: 18px;
            margin-top: 10px;
        }}
        
        .mindmap {{
            display: flex;
            flex-direction: column;
            gap: 20px;
        }}
        
        .node {{
            background: {theme['card_bg']};
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
            border: 2px solid {theme['border']};
            transition: all 0.3s ease;
        }}
        
        .node:hover {{
            transform: translateY(-2px);
            box-shadow: 0 8px 12px rgba(0, 0, 0, 0.1);
        }}
        
        .node-name {{
            font-size: 18px;
            font-weight: 600;
            color: {theme['text']};
            margin-bottom: 8px;
        }}
        
        .node-description {{
            font-size: 14px;
            color: {theme['text']};
            opacity: 0.8;
            line-height: 1.6;
        }}
        
        .level-0 {{
            background: linear-gradient(135deg, {theme['primary']} 0%, {theme['secondary']} 100%);
        }}
        
        .level-0 .node-name,
        .level-0 .node-description {{
            color: white;
        }}
        
        .level-1 {{
            margin-left: 20px;
            border-left: 4px solid {theme['primary']};
        }}
        
        .level-2 {{
            margin-left: 40px;
            border-left: 4px solid {theme['secondary']};
            background: {theme['background']};
        }}
        
        .level-3 {{
            margin-left: 60px;
            border-left: 4px solid {theme['border']};
            background: {theme['card_bg']};
        }}
        
        .children {{
            margin-top: 15px;
        }}
        
        @media (max-width: 768px) {{
            body {{
                padding: 20px 10px;
            }}
            
            .header h1 {{
                font-size: 28px;
            }}
            
            .level-1 {{ margin-left: 10px; }}
            .level-2 {{ margin-left: 20px; }}
            .level-3 {{ margin-left: 30px; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>{data.get('title', '思维导图')}</h1>
            <p>{data.get('description', '')}</p>
        </div>
        
        <div class="mindmap">
"""
    
    # 递归生成HTML节点
    def add_node_html(node: Dict[str, Any], level: int, branch_idx: int = 0) -> str:
        name = node.get('name', '未命名')
        desc = node.get('description', '')
        children = node.get('children', [])
        
        level_class = f"level-{min(level, 3)}"
        
        html_node = f"""            <div class="node {level_class}">
                <div class="node-name">{name}</div>
                <div class="node-description">{desc}</div>
"""
        
        if children:
            html_node += '                <div class="children">\n'
            for child in children:
                html_node += add_node_html(child, level + 1, branch_idx)
            html_node += '                </div>\n'
        
        html_node += '            </div>\n'
        return html_node
    
    # 处理主分支
    for i, branch in enumerate(data.get('branches', [])):
        html += add_node_html(branch, 0, i)
    
    html += """        </div>
    </div>
</body>
</html>"""
    
    return html


def export_to_ascii_tree(data: Dict[str, Any]) -> str:
    """
    导出为ASCII树形结构（文本格式）
    
    参数：
        data: 思维导图JSON数据
        
    返回：
        ASCII树形结构的字符串
    """
    lines = [
        f"{data.get('title', '思维导图')}",
        "=" * 60,
        ""
    ]
    
    # 递归生成ASCII树
    def add_node_ascii(node: Dict[str, Any], prefix: str = "", is_last: bool = True):
        name = node.get('name', '未命名')
        desc = node.get('description', '')
        children = node.get('children', [])
        
        # 节点符号
        connector = "└── " if is_last else "├── "
        
        lines.append(f"{prefix}{connector}{name}")
        
        if desc:
            desc_prefix = "    " if is_last else "│   "
            lines.append(f"{prefix}{desc_prefix}{desc}")
        
        # 处理子节点
        if children:
            child_prefix = "    " if is_last else "│   "
            for i, child in enumerate(children):
                add_node_ascii(child, prefix + child_prefix, i == len(children) - 1)
    
    # 处理主分支
    for i, branch in enumerate(data.get('branches', [])):
        add_node_ascii(branch, "", i == len(data.get('branches', [])) - 1)
        if i < len(data.get('branches', [])) - 1:
            lines.append("")
    
    return '\n'.join(lines)


def main():
    parser = argparse.ArgumentParser(
        description='精美样式导出工具'
    )
    parser.add_argument(
        '--format',
        choices=['mermaid-styled', 'plantuml', 'html', 'ascii'],
        required=True,
        help='输出格式：mermaid-styled（带样式的Mermaid）、plantuml（PlantUML）、html（HTML可视化）、ascii（ASCII树形）'
    )
    parser.add_argument(
        '--style',
        choices=['default', 'modern', 'elegant', 'colorful'],
        default='default',
        help='样式风格：default（默认）、modern（现代）、elegant（优雅）、colorful（多彩）'
    )
    parser.add_argument(
        '--input',
        required=True,
        help='输入的思维导图JSON文件路径'
    )
    parser.add_argument(
        '--output',
        required=True,
        help='输出文件路径'
    )
    
    args = parser.parse_args()
    
    # 加载思维导图数据
    data = load_json_file(args.input)
    
    # 根据格式生成输出
    if args.format == 'mermaid-styled':
        content = export_to_mermaid_styled(data, args.style)
    elif args.format == 'plantuml':
        content = export_to_plantuml(data, args.style)
    elif args.format == 'html':
        content = export_to_html(data, args.style)
    elif args.format == 'ascii':
        content = export_to_ascii_tree(data)
    else:
        print(f"错误：不支持的格式 '{args.format}'", file=sys.stderr)
        sys.exit(1)
    
    # 写入输出文件
    try:
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"成功导出到：{args.output}")
        print(f"格式：{args.format}")
        print(f"样式：{args.style}")
    except IOError as e:
        print(f"错误：写入文件失败 - {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
