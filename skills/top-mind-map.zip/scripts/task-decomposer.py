#!/usr/bin/env python3
"""
智能任务分解工具
将思维导图节点转换为可执行的任务清单，支持多级任务分解和依赖关系
"""

import argparse
import json
import sys
from typing import Dict, Any, List


def load_json_file(filepath: str) -> Dict[str, Any]:
    """加载JSON文件"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"错误：文件 '{filepath}' 不存在", file=sys.stderr)
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"错误：JSON解析失败 - {e}", file=sys.stderr)
        sys.exit(1)


def generate_task_id(level: int, parent_id: str, index: int) -> str:
    """
    生成任务ID
    
    参数：
        level: 任务层级
        parent_id: 父任务ID
        index: 当前任务在同层级的索引
        
    返回：
        任务ID字符串
    """
    if level == 1:
        return f"T{index + 1:02d}"
    else:
        return f"{parent_id}.{index + 1}"


def decompose_node_to_tasks(node: Dict[str, Any], level: int = 1, parent_id: str = "") -> List[Dict[str, Any]]:
    """
    将节点及其子节点递归分解为任务
    
    参数：
        node: 节点数据
        level: 当前层级
        parent_id: 父任务ID
        
    返回：
        任务列表
    """
    tasks = []
    node_name = node.get('name', '未命名')
    node_desc = node.get('description', '')
    
    # 生成任务ID
    task_id = generate_task_id(level, parent_id, len(tasks))
    
    # 根据层级定义任务类型
    if level == 1:
        task_type = "里程碑"
    elif level == 2:
        task_type = "阶段任务"
    elif level == 3:
        task_type = "执行任务"
    else:
        task_type = "子任务"
    
    # 创建任务
    task = {
        "task_id": task_id,
        "task_type": task_type,
        "name": node_name,
        "description": node_desc,
        "level": level,
        "parent_id": parent_id if parent_id else None,
        "status": "待开始",
        "estimated_effort": "",  # 预估工作量（待填写）
        "priority": "中等",  # 优先级：高/中/低
        "deliverables": [],  # 交付物列表
        "dependencies": [] if not parent_id else [parent_id]  # 依赖关系
    }
    
    tasks.append(task)
    
    # 递归处理子节点
    children = node.get('children', [])
    for i, child in enumerate(children):
        child_tasks = decompose_node_to_tasks(child, level + 1, task_id)
        tasks.extend(child_tasks)
    
    return tasks


def decompose_mindmap_to_tasks(data: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    将整个思维导图分解为任务清单
    
    参数：
        data: 思维导图JSON数据
        
    返回：
        任务列表
    """
    all_tasks = []
    
    # 处理每个主分支
    for branch in data.get('branches', []):
        tasks = decompose_node_to_tasks(branch)
        all_tasks.extend(tasks)
    
    return all_tasks


def export_to_markdown_tasks(tasks: List[Dict[str, Any]], title: str = "任务清单") -> str:
    """
    将任务列表导出为Markdown格式
    
    参数：
        tasks: 任务列表
        title: 标题
        
    返回：
        Markdown格式的任务清单
    """
    lines = [
        f"# {title}",
        "",
        "## 任务概览",
        "",
        f"- 总任务数：{len(tasks)}",
        f"- 里程碑：{len([t for t in tasks if t['task_type'] == '里程碑'])}",
        f"- 阶段任务：{len([t for t in tasks if t['task_type'] == '阶段任务'])}",
        f"- 执行任务：{len([t for t in tasks if t['task_type'] == '执行任务'])}",
        "",
        "---",
        "",
        "## 任务清单",
        ""
    ]
    
    # 按任务ID排序
    sorted_tasks = sorted(tasks, key=lambda x: x['task_id'])
    
    # 分组显示
    current_level = 0
    for task in sorted_tasks:
        if task['level'] > current_level:
            lines.append("")
            current_level = task['level']
        
        indent = "  " * (task['level'] - 1)
        
        lines.append(f"{indent}### {task['task_id']} - {task['name']}")
        lines.append(f"{indent}- **类型**：{task['task_type']}")
        lines.append(f"{indent}- **描述**：{task['description']}")
        lines.append(f"{indent}- **优先级**：{task['priority']}")
        lines.append(f"{indent}- **状态**：{task['status']}")
        
        if task['parent_id']:
            lines.append(f"{indent}- **父任务**：{task['parent_id']}")
        
        lines.append(f"{indent}- **预估工作量**：{task['estimated_effort'] or '待填写'}")
        lines.append(f"{indent}- **交付物**：{', '.join(task['deliverables']) if task['deliverables'] else '待定义'}")
        lines.append("")
    
    # 添加任务依赖说明
    lines.append("---")
    lines.append("")
    lines.append("## 依赖关系")
    lines.append("")
    
    for task in sorted_tasks:
        if task['dependencies']:
            lines.append(f"- {task['task_id']} 依赖于：{', '.join(task['dependencies'])}")
    
    return '\n'.join(lines)


def export_to_json_tasks(tasks: List[Dict[str, Any]], title: str = "任务清单") -> str:
    """
    将任务列表导出为JSON格式
    
    参数：
        tasks: 任务列表
        title: 标题
        
    返回：
        JSON格式的任务清单
    """
    result = {
        "title": title,
        "metadata": {
            "total_tasks": len(tasks),
            "task_types": {
                "里程碑": len([t for t in tasks if t['task_type'] == '里程碑']),
                "阶段任务": len([t for t in tasks if t['task_type'] == '阶段任务']),
                "执行任务": len([t for t in tasks if t['task_type'] == '执行任务']),
                "子任务": len([t for t in tasks if t['task_type'] == '子任务'])
            }
        },
        "tasks": tasks
    }
    
    return json.dumps(result, ensure_ascii=False, indent=2)


def main():
    parser = argparse.ArgumentParser(
        description='智能任务分解工具'
    )
    parser.add_argument(
        '--format',
        choices=['markdown', 'json'],
        required=True,
        help='输出格式：markdown（Markdown任务清单）、json（JSON任务清单）'
    )
    parser.add_argument(
        '--input',
        required=True,
        help='输入的思维导图JSON文件路径'
    )
    parser.add_argument(
        '--output',
        required=True,
        help='输出文件路径'
    )
    parser.add_argument(
        '--title',
        default="任务分解清单",
        help='任务清单标题'
    )
    
    args = parser.parse_args()
    
    # 加载思维导图数据
    data = load_json_file(args.input)
    
    # 分解为任务
    tasks = decompose_mindmap_to_tasks(data)
    
    # 根据格式导出
    if args.format == 'markdown':
        content = export_to_markdown_tasks(tasks, args.title)
    elif args.format == 'json':
        content = export_to_json_tasks(tasks, args.title)
    else:
        print(f"错误：不支持的格式 '{args.format}'", file=sys.stderr)
        sys.exit(1)
    
    # 写入输出文件
    try:
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"成功导出任务清单到：{args.output}")
        print(f"共生成 {len(tasks)} 个任务")
    except IOError as e:
        print(f"错误：写入文件失败 - {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
