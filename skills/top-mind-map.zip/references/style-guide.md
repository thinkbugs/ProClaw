# 精美样式设计指南

## 目录
- 概览
- 样式类型
- 配色方案
- 使用场景
- 渲染工具

## 概览
本指南提供了思维导图的各种精美样式设计，帮助用户选择适合不同场景的可视化风格。

## 样式类型

### 1. Mermaid Styled（带样式的Mermaid）
**特点**：
- 基于Mermaid.js，广泛支持
- 支持自定义主题和颜色
- 自动布局，无需手动调整
- 适合在线文档和演示

**优势**：
- 渲染速度快
- 支持多种平台（GitHub、Notion等）
- 文本格式，易于版本控制

**适用场景**：
- 技术文档
- 在线协作平台
- 快速预览

### 2. PlantUML（专业格式）
**特点**：
- 功能强大的图形绘制工具
- 支持丰富的样式定制
- 高质量输出
- 支持导出为PNG、SVG等格式

**优势**：
- 专业级渲染效果
- 支持复杂的样式配置
- 输出质量高

**适用场景**：
- 专业文档
- 学术论文
- 出版物

### 3. HTML可视化（交互式网页）
**特点**：
- 完全交互式
- 支持响应式设计
- 可自定义CSS样式
- 支持动画效果

**优势**：
- 视觉效果最佳
- 可在浏览器中直接查看
- 支持移动端
- 可嵌入网站

**适用场景**：
- 演示文稿
- 网站展示
- 分享链接
- 移动端查看

### 4. ASCII树形（纯文本）
**特点**：
- 纯文本格式
- 无需额外工具
- 适合终端显示
- 文件体积小

**优势**：
- 兼容性最强
- 易于嵌入代码注释
- 适合技术文档

**适用场景**：
- 终端环境
- 代码注释
- README文档
- 邮件正文

## 配色方案

### Default（默认配色）
```
主色：#4E79A7（蓝色）
强调色：#F28E2B（橙色）
背景色：#FFFFFF（白色）
文字色：#333333（深灰）
```
**特点**：简洁清晰，适合通用场景

### Modern（现代配色）
```
主色：#6366F1（靛蓝）
渐变：#8B5CF6（紫色）
背景色：#F8FAFC（浅蓝灰）
文字色：#1E293B（深蓝灰）
```
**特点**：现代感强，渐变效果，适合演示

### Elegant（优雅配色）
```
主色：#0F172A（深蓝灰）
辅助色：#334155（灰蓝）
背景色：#F1F5F9（浅灰）
文字色：#1E293B（深灰）
```
**特点**：优雅专业，低调奢华，适合正式场合

### Colorful（多彩配色）
```
主色：#F59E0B（琥珀色）
强调色：#EF4444（红色）
背景色：#FFFBEB（浅黄）
文字色：#1F2937（深灰）
```
**特点**：色彩鲜艳，活力十足，适合创意场景

## 使用场景对照表

| 场景 | 推荐样式 | 推荐配色 | 原因 |
|-----|---------|---------|------|
| 技术文档 | Mermaid | Default | 兼容性好，清晰易读 |
| 演示文稿 | HTML | Modern | 视觉效果最佳 |
| 学术论文 | PlantUML | Elegant | 专业级输出质量 |
| README文档 | ASCII | - | 纯文本，兼容性强 |
| 网站展示 | HTML | Colorful | 吸引眼球，交互性好 |
| 在线协作 | Mermaid | Default | 多平台支持 |
| 项目报告 | PlantUML | Elegant | 正式专业 |
| 快速分享 | Mermaid | Modern | 渲染快，美观 |

## 渲染工具

### Mermaid渲染
**在线工具**：
- [Mermaid Live Editor](https://mermaid.live/) - 在线编辑和预览
- [GitHub](https://github.com/) - 自动渲染.mmd文件
- [Notion](https://www.notion.so/) - 支持Mermaid语法

**本地工具**：
- mermaid-cli - 命令行工具
- VS Code插件 - Mermaid Preview

### PlantUML渲染
**在线工具**：
- [PlantUML Online Server](http://www.plantuml.com/plantuml/uml/)
- [PlantText](https://www.planttext.com/)

**本地工具**：
- PlantUML JAR包
- VS Code插件 - PlantUML

### HTML渲染
**查看方式**：
- 直接在浏览器中打开
- 部署到Web服务器
- 使用在线预览工具

### ASCII查看
**查看方式**：
- 任何文本编辑器
- 终端命令（cat, less）
- Markdown编辑器

## 样式定制

### Mermaid样式定制
```mermaid
%%{init: {
  'theme': 'base',
  'themeVariables': {
    'primaryColor': '#f0f0f0',
    'primaryTextColor': '#333',
    'primaryBorderColor': '#ccc'
  }
}}%%
```

### PlantUML样式定制
```plantuml
skinparam backgroundColor #FFFFFF
skinparam nodeBackgroundColor #F8F9FA
skinparam nodeBorderColor #DEE2E6
```

### HTML样式定制
通过修改CSS样式实现：
```css
.node {
    background: linear-gradient(135deg, #6366F1 0%, #8B5CF6 100%);
    border-radius: 12px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
}
```

## 最佳实践

### 选择建议
1. **优先兼容性**：选择Mermaid + Default配色
2. **优先视觉效果**：选择HTML + Modern配色
3. **优先专业性**：选择PlantUML + Elegant配色
4. **优先简洁性**：选择ASCII格式

### 组合使用
- 技术文档：Mermaid（主）+ ASCII（备）
- 演示文稿：HTML（主）+ PlantUML（导出PDF）
- 团队协作：Mermaid（在线）+ HTML（分享）

### 性能考虑
- 大型导图（100+节点）：建议使用ASCII或Mermaid
- 复杂样式：建议使用PlantUML
- 交互需求：建议使用HTML
