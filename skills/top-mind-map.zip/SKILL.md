---
name: top-mind-map
description: 深度洞察主题本质，构建多级节点层层穿透的层级结构，支持智能任务分解、精美样式导出的专业思维导图系统；当用户需要分析主题、梳理知识结构、规划方案路径、生成可视化导图或分解执行任务时使用
dependency:
  python:
    - pyyaml>=6.0
  system: []
---

# 顶级思维导图生成

## 任务目标
- 本 Skill 用于：深度分析主题本质，构建多级节点层层穿透的思维导图结构，支持智能任务分解
- 能力包含：主题洞察、多级层级设计、节点精炼、智能任务分解、多格式输出
- 触发条件：用户需要分析主题、梳理知识结构、规划方案路径、生成可视化导图或分解执行任务

## 前置准备
- 依赖说明：Python依赖包
  ```bash
  pyyaml>=6.0
  ```

## 操作步骤

### 1. 主题深度洞察（智能体主导）
根据用户提供的主题，执行以下分析：
- **核心定位**：提取主题的本质属性和核心价值
- **关键维度**：识别主题的主要构成维度（3-7个维度最佳）
- **关联关系**：梳理各维度之间的逻辑关系（并列、递进、因果等）
- **穿透深度**：确定每个维度需要展开的层级深度（建议3-5层）

### 2. 结构化路径设计（智能体主导）
基于主题洞察，构建清晰的层级结构：
- **第一层（核心）**：主题的终极目标或核心问题（1个节点）
- **第二层（主分支）**：关键维度或主要方向（3-7个节点）
- **第三层（子节点）**：具体要点或执行路径（每个主分支下2-5个节点）
- **第四层及以下**：细节说明或支撑数据（根据需要添加）

### 3. 节点精炼与定义（智能体主导）
为每个节点提供清晰明确的定义：
- **命名规范**：简洁有力，体现核心价值（3-8字最佳）
- **内容说明**：每个节点附带1-2句话的清晰定义
- **价值标定**：说明该节点在整体结构中的作用和意义

### 4. 多格式导出（脚本+智能体混合）
根据用户需求，选择合适的输出格式：

#### 格式A：Markdown表格（智能体生成）
适合文档展示，结构清晰易读

#### 格式B：Mermaid图（脚本导出）
适合可视化展示，支持在支持Mermaid的环境渲染
```bash
python scripts/export-mindmap.py \
  --format mermaid \
  --input ./mindmap.json \
  --output ./mindmap.mmd
```

#### 格式C：JSON结构（脚本导出）
适合程序化处理和二次开发
```bash
python scripts/export-mindmap.py \
  --format json \
  --input ./mindmap.json \
  --output ./mindmap-enhanced.json
```

### 5. 智能任务分解（脚本+智能体混合）

将思维导图的节点结构转换为可执行的任务清单，实现从规划到执行的闭环。

#### 5.1 任务类型定义（智能体主导）
根据节点层级自动定义任务类型：
- **L1节点（主分支）**：里程碑（Milestone）
- **L2节点（子节点）**：阶段任务（Phase Task）
- **L3节点（细节节点）**：执行任务（Execution Task）
- **L4+节点**：子任务（Sub-task）

#### 5.2 任务属性完善（智能体主导）
为每个任务补充关键属性：
- **任务描述**：基于节点描述补充具体执行要求
- **优先级**：根据战略重要性定义（高/中/低）
- **预估工作量**：估算所需时间或资源
- **交付物**：定义任务完成后的产出物
- **依赖关系**：明确任务之间的前后依赖

#### 5.3 任务清单导出（脚本导出）

#### 格式D：Markdown任务清单（脚本导出）
适合项目管理、团队协作
```bash
python scripts/task-decomposer.py \
  --format markdown \
  --input ./mindmap.json \
  --output ./tasks.md
```

#### 格式E：JSON任务清单（脚本导出）
适合集成到任务管理系统
```bash
python scripts/task-decomposer.py \
  --format json \
  --input ./mindmap.json \
  --output ./tasks.json
```

### 6. 精美样式导出（脚本主导）

支持多种精美的可视化样式，满足不同场景的展示需求。

#### 样式A：带样式的Mermaid图（脚本导出）
增强的Mermaid格式，支持主题定制和颜色方案
```bash
python scripts/style-exporter.py \
  --format mermaid-styled \
  --style modern \
  --input ./mindmap.json \
  --output ./mindmap-styled.mmd
```

#### 样式B：PlantUML图（脚本导出）
支持丰富样式和自定义配色的专业格式
```bash
python scripts/style-exporter.py \
  --format plantuml \
  --style elegant \
  --input ./mindmap.json \
  --output ./mindmap.puml
```

#### 样式C：HTML可视化（脚本导出）
交互式网页格式，支持响应式设计和多种主题
```bash
python scripts/style-exporter.py \
  --format html \
  --style colorful \
  --input ./mindmap.json \
  --output ./mindmap.html
```

#### 样式D：ASCII树形（脚本导出）
纯文本格式，适合终端显示和文档嵌入
```bash
python scripts/style-exporter.py \
  --format ascii \
  --input ./mindmap.json \
  --output ./mindmap.txt
```

#### 可用样式风格
- **default**：默认样式，简洁清晰
- **modern**：现代风格，渐变色和圆角设计
- **elegant**：优雅风格，深色调和精细边框
- **colorful**：多彩风格，鲜艳的配色方案

### 7. 思维导图软件格式导出（脚本主导）

支持导出为主流思维导图软件可导入的格式，实现跨软件兼容。

#### 格式A：XMind格式（脚本导出）
XMind专用格式，可直接在XMind中打开和编辑
```bash
python scripts/xmind-exporter.py \
  --format xmind \
  --input ./mindmap.json \
  --output ./mindmap.xmind
```

#### 格式B：FreeMind格式（脚本导出）
FreeMind兼容格式，支持.mm文件
```bash
python scripts/xmind-exporter.py \
  --format freemind \
  --input ./mindmap.json \
  --output ./mindmap.mm
```

#### 格式C：OPML格式（脚本导出）
通用大纲格式，支持MindManager、OmniOutliner等软件
```bash
python scripts/xmind-exporter.py \
  --format opml \
  --input ./mindmap.json \
  --output ./mindmap.opml
```

#### 格式D：Markdown大纲（脚本导出）
兼容多种软件的Markdown格式
```bash
python scripts/xmind-exporter.py \
  --format markdown-outline \
  --input ./mindmap.json \
  --output ./mindmap-outline.md
```

#### 格式E：缩进文本（脚本导出）
最通用的文本格式，几乎所有软件都能导入
```bash
python scripts/xmind-exporter.py \
  --format txt-indented \
  --input ./mindmap.json \
  --output ./mindmap.txt
```

#### 软件兼容性说明
| 格式 | 兼容软件 | 特点 |
|-----|---------|------|
| XMind | XMind、XMind ZEN | 原生格式，功能完整 |
| FreeMind | FreeMind、Freeplane | 开源软件通用格式 |
| OPML | MindManager、OmniOutliner、Workflowy | 通用大纲格式 |
| Markdown | Notion、Obsidian、Typora | 跨平台支持 |
| 缩进文本 | 几乎所有文本编辑器 | 最高兼容性 |

### 8. 价值网络构建（智能体+脚本混合）

构建关键价值点之间的智能互链和注释系统，实现价值网络的可视化。

#### 8.1 价值点识别（智能体主导）
从思维导图中识别关键价值点（KVP - Key Value Points）
- **识别标准**：
  - 重要性：对整体目标有重大影响
  - 可衡量性：可以被量化或验证
  - 独立性：与其他价值点相对独立
- **层级选择**：
  - L1节点：全部作为价值点（3-7个）
  - L2节点：选择关键节点（20-30%）
  - L3节点：仅选择可量化节点（10-20%）
- **权重评估**：
  - 9-10分：核心价值点，必须实现
  - 7-8分：重要价值点，强烈建议
  - 5-6分：一般价值点，建议实现

#### 8.2 互链关系构建（智能体主导）
在价值点之间建立各种关系
- **关系类型**：
  - 因果关系：A导致B
  - 依赖关系：A依赖B
  - 支撑关系：A支撑B
  - 逻辑关联：A与B逻辑相关
- **关系强度**：
  - 9-10分：强关联，几乎必然发生
  - 7-8分：中等关联，很可能发生
  - 5-6分：弱关联，可能发生
- **关系方向**：
  - 单向：A → B
  - 双向：A ↔ B

#### 8.3 注释系统完善（智能体主导）
为价值点和互链关系添加详细注释
- **价值点注释**：
  - 背景说明：为什么重要
  - 实现路径：如何实现
  - 成功标准：如何判断实现
  - 风险提示：可能的风险
- **互链注释**：
  - 逻辑说明：为什么存在这种关系
  - 影响范围：关系的影响范围
  - 时间维度：关系的时间特征

#### 8.4 价值网络可视化（脚本导出）

#### 格式A：Mermaid价值网络图（脚本导出）
支持多种关系类型和连接线样式
```bash
python scripts/value-network-exporter.py \
  --format mermaid \
  --input mindmap-with-value-network.json \
  --output value-network.mmd
```

#### 格式B：HTML交互图（脚本导出）
交互式价值网络图，点击查看注释
```bash
python scripts/value-network-exporter.py \
  --format html \
  --input mindmap-with-value-network.json \
  --output value-network.html
```

#### 格式C：价值网络JSON（脚本导出）
结构化价值网络数据，便于系统集成
```bash
python scripts/value-network-exporter.py \
  --format json \
  --input mindmap-with-value-network.json \
  --output value-network.json
```

#### 关系可视化样式
- **因果关系**：实线（==），红色
- **依赖关系**：虚线（--），橙色
- **逻辑关联**：点线（-.），绿色
- **支撑关系**：双线（<=>），蓝色

## 资源索引
- 核心能力（OpenClaw风格）：
  - [core/AGENTS.md](core/AGENTS.md)（元准则：核心原则、行为准则、质量标准、价值网络构建原则）
  - [core/SouL.md](core/SouL.md)（性格内核：内在特质、价值观、驱动力）
  - [core/TOOLS.md](core/TOOLS.md)（工具映射：智能体能力、脚本能力、协作模式）
  - [core/IDENTITY.md](core/IDENTITY.md)（外在身份：角色定位、专业形象、沟通风格）
  - [core/USER.md](core/USER.md)（用户画像：目标用户、核心需求、使用场景）
  - [core/HEARTBEAT.md](core/HEARTBEAT.md)（自检清单：质量检查、功能检查、完整性检查）
  - [core/BOOTSTRAP.md](core/BOOTSTRAP.md)（首次引导：快速入门、最佳实践、常见问题）
  - [core/MEMORY.md](core/MEMORY.md)（长期记忆：用户偏好、行业经验、案例库）
- 必要脚本：
  - [scripts/export-mindmap.py](scripts/export-mindmap.py)（多格式导出工具）
  - [scripts/task-decomposer.py](scripts/task-decomposer.py)（智能任务分解工具）
  - [scripts/style-exporter.py](scripts/style-exporter.py)（精美样式导出工具）
  - [scripts/xmind-exporter.py](scripts/xmind-exporter.py)（思维导图软件格式导出工具）
  - [scripts/value-network-exporter.py](scripts/value-network-exporter.py)（价值网络导出工具）
- 结构参考：
  - [references/mindmap-structure.md](references/mindmap-structure.md)（层级设计原则）
  - [references/task-decomposition.md](references/task-decomposition.md)（任务分解规范）
  - [references/style-guide.md](references/style-guide.md)（样式设计指南）
  - [references/software-compatibility.md](references/software-compatibility.md)（软件兼容性指南）
  - [references/value-network.md](references/value-network.md)（价值网络设计指南）
- 格式参考：[references/formats.md](references/formats.md)（输出格式说明）
- 输入模板：
  - [assets/templates/mindmap-template.json](assets/templates/mindmap-template.json)（思维导图JSON格式）
  - [assets/templates/mindmap-with-value-network.json](assets/templates/mindmap-with-value-network.json)（带价值网络的思维导图格式）
  - [assets/templates/task-template.json](assets/templates/task-template.json)（任务清单JSON格式）
- 输出示例：
  - [assets/templates/mermaid-template.md](assets/templates/mermaid-template.md)（Mermaid输出示例）
  - [assets/templates/task-template.md](assets/templates/task-template.md)（任务清单输出示例）

## 注意事项
- 智能体负责所有分析、设计和内容生成工作
- 脚本仅用于格式转换和导出，不参与思维过程
- 支持多级穿透，层级深度可扩展（建议3-6层）
- 每个主分支下的节点数量保持平衡（2-5个）
- 节点命名统一使用简体中文，避免使用缩写或符号
- 任务分解保持与思维导图的一致性，任务ID自动生成

## 使用示例

### 示例1：战略规划导图
- 功能说明：为产品战略生成清晰的执行路径
- 执行方式：智能体分析主题→设计层级→生成Mermaid图→分解任务清单
- 关键要点：核心目标→关键维度→执行节点→支撑数据→可执行任务

### 示例2：知识体系梳理
- 功能说明：将复杂知识领域结构化呈现
- 执行方式：智能体提取核心概念→构建知识树→导出JSON格式→生成学习任务
- 关键要点：核心概念→知识分支→知识点→关联关系→学习路径

### 示例3：项目方案执行
- 功能说明：将复杂项目方案拆解为可执行的任务体系
- 执行方式：智能体定义项目目标→分析关键路径→设计任务层级→生成任务清单
- 关键要点：项目目标→关键路径→阶段任务→执行步骤→依赖关系
