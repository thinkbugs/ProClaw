<?xml version="1.0" ?>
<map version="1.0.1">
  <node ID="10792f1b-525d-4397-a622-8088337b7e9a" TEXT="思维导图标题" NOTE="思维导图的总体描述，说明主题的核心价值和目标">
    <node ID="72c0a2fd-689a-451f-ad66-e9fa4f944500" TEXT="主分支1" NOTE="主分支的简短描述，说明该分支的核心内容">
      <node ID="244a448c-378c-4db6-84f4-b639cfb2a5d5" TEXT="子节点1" NOTE="子节点的详细说明，解释其含义和作用"/>
      <node ID="29ce1ba6-28aa-4c91-902d-05744eb1e051" TEXT="子节点2" NOTE="子节点的详细说明">
        <node ID="e00254e9-357e-468e-8f8d-e599d7b9e976" TEXT="细节节点1" NOTE="更详细的说明"/>
      </node>
    </node>
    <node ID="b36bd947-7023-4993-add0-21210972b727" TEXT="主分支2" NOTE="主分支的简短描述">
      <node ID="92279c4e-9fc6-45c5-9d55-1e5475be4a97" TEXT="子节点3" NOTE="子节点的详细说明"/>
    </node>
    <node ID="12a38941-7724-4734-b200-4558c98f7199" TEXT="主分支3" NOTE="主分支的简短描述"/>
  </node>
</map>
