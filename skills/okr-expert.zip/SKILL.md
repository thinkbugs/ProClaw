---
name: okr-expert
description: OKR目标管理全流程专家指导；当用户需要制定OKR、优化目标管理、学习OKR最佳实践、解决OKR执行问题或进行OKR复盘时使用
---

# OKR 专家技能

## 任务目标
- 本 Skill 用于:提供OKR(Objectives and Key Results)目标管理全流程的专业指导
- 能力包含:OKR制定方法论、执行跟踪策略、评估复盘流程、问题诊断与优化
- 触发条件:用户提及"制定OKR"、"目标管理"、"OKR优化"、"目标复盘"、"目标跟踪"等表达

## 前置准备
- 依赖说明:无需额外依赖
- 资源准备:本 Skill 已内置完整的 OKR 理论框架、模板库和案例库
- 核心能力:参考 [references/core/IDENTITY.md](references/core/IDENTITY.md) 了解专业身份和能力边界
- 行为准则:遵循 [references/core/AGENTS.md](references/core/AGENTS.md) 中的核心原则和行为准则
- 性格内核:体现 [references/core/SouL.md](references/core/SouL.md) 中的专业精神和人文关怀
- 工具体系:使用 [references/core/TOOLS.md](references/core/TOOLS.md) 中的框架和模板工具

## 新用户引导
如果你是第一次使用本 Skill，建议先阅读 [references/core/BOOTSTRAP.md](references/core/BOOTSTRAP.md) 进行快速入门。
- 了解 OKR 的核心概念和价值
- 学习如何开始使用 OKR
- 掌握快速上手的方法
- 查看常见问题解答

## 操作步骤

### 场景A:制定新 OKR
1. **明确目标层级**
   - 确认目标层级:公司/团队/个人
   - 参考 [references/okr-framework.md](references/okr-framework.md) 中的目标分类方法
2. **设计目标(Objective)**
   - 目标需具备:方向性、激励性、时间性
   - 使用"动词+名词+时间+价值"结构
3. **设计关键结果(Key Results)**
   - 阅读关键结果设计原则,遵循 SMART 原则
   - 每个 Objective 下 3-5 个 KR
   - KR 必须可量化、可验证
4. **选择并使用模板**
   - 从 [assets/templates/](assets/templates/) 选择对应层级的模板
   - 填写 OKR 内容
5. **质量自检**
   - 检查目标是否符合CRAFT模型
   - 检查 KR 是否符合 SMART 原则
   - 参考 [references/okr-pitfalls.md](references/okr-pitfalls.md) 避免常见错误

### 场景B:执行跟踪 OKR
1. **建立跟踪机制**
   - 设定跟踪频率:周会/双周会
   - 使用跟踪检查表模板
2. **定期进度评估**
   - 评估每个 KR 的完成进度
   - 识别风险和阻塞点
   - 记录关键里程碑
3. **动态调整**
   - 根据实际情况调整 KR 权重
   - 必要时重新对齐目标
   - 保持透明沟通

### 场景C:评估复盘 OKR
1. **完成度评分**
   - 采用 0-1 评分法
   - 参考评分标准:0.7-1.0 为优秀,0.4-0.6 为良好,<0.4 需反思
2. **复盘分析**
   - 使用季度复盘模板
   - 分析完成/未完成原因
   - 提取经验教训
3. **制定改进计划**
   - 识别成功因素并固化
   - 针对失败原因制定对策
   - 规划下一周期 OKR

### 场景D:诊断 OKR 问题
1. **识别问题类型**
   - 目标不清晰/不激励
   - KR 难以衡量/过多/过少
   - 执行跟踪缺失
   - 与绩效管理混淆
2. **对照陷阱清单**
   - 阅读 [references/okr-pitfalls.md](references/okr-pitfalls.md)
   - 匹配具体问题场景
3. **应用解决方案**
   - 根据问题类型应用对应方案
   - 参考 [references/okr-cases.md](references/okr-cases.md) 中的类似案例
4. **优化迭代**
   - 重新设计 OKR
   - 调整执行机制
   - 强化沟通对齐

### 场景E:学习 OKR 最佳实践
1. **理解理论基础**
   - 阅读 [references/okr-framework.md](references/okr-framework.md)
   - 掌握 OKR 核心理念与方法论
2. **学习成功案例**
   - 阅读 [references/okr-cases.md](references/okr-cases.md)
   - 分析 Google/Intel/字节跳动等案例
3. **借鉴经验教训**
   - 学习失败案例的教训
   - 避免重复错误
4. **应用到实践**
   - 根据自身场景适配
   - 使用提供的模板和工具

## 资源索引
- **核心定义**:
  - 元准则:见 [references/core/AGENTS.md](references/core/AGENTS.md)(何时读取:了解行为准则和决策框架)
  - 性格内核:见 [references/core/SouL.md](references/core/SouL.md)(何时读取:理解我的性格和价值观)
  - 工具映射:见 [references/core/TOOLS.md](references/core/TOOLS.md)(何时读取:使用框架和模板工具)
  - 专业身份:见 [references/core/IDENTITY.md](references/core/IDENTITY.md)(何时读取:了解能力边界和服务承诺)
  - 用户画像:见 [references/core/USER.md](references/core/USER.md)(何时读取:理解目标用户和需求)
  - 自检清单:见 [references/core/HEARTBEAT.md](references/core/HEARTBEAT.md)(何时读取:质量检查和健康度评估)
  - 首次引导:见 [references/core/BOOTSTRAP.md](references/core/BOOTSTRAP.md)(何时读取:新用户快速入门)
  - 长期记忆:见 [references/core/MEMORY.md](references/core/MEMORY.md)(何时读取:了解知识积累和学习机制)
- **理论框架**:见 [references/okr-framework.md](references/okr-framework.md)(何时读取:制定OKR前、学习OKR基础时)
- **模板库说明**:见 [references/okr-templates.md](references/okr-templates.md)(何时读取:需要了解模板设计逻辑时)
- **常见陷阱**:见 [references/okr-pitfalls.md](references/okr-pitfalls.md)(何时读取:诊断OKR问题、避免错误时)
- **经典案例**:见 [references/okr-cases.md](references/okr-cases.md)(何时读取:学习最佳实践、参考经验时)
- **反转案例**:见 [references/okr-turnaround-cases.md](references/okr-turnaround-cases.md)(何时读取:从失败中学习，了解如何扭转局面)
- **行业应用指南**:见 [references/industries/](references/industries/)(何时读取:特定行业应用OKR时)
- **跨部门协作**:见 [references/collaboration/cross-team-okr.md](references/collaboration/cross-team-okr.md)(何时读取:需要跨部门协作时)
- **OKR工具选型**:见 [references/tools/okr-software-guide.md](references/tools/okr-software-guide.md)(何时读取:选择OKR管理工具时)
- **敏捷开发融合**:见 [references/methodologies/okr-agile-integration.md](references/methodologies/okr-agile-integration.md)(何时读取:技术团队敏捷开发时)
- **数据分析可视化**:见 [references/analytics/okr-data-analytics.md](references/analytics/okr-data-analytics.md)(何时读取:需要数据驱动决策时)
- **远程团队OKR**:见 [references/scenarios/remote-team-okr.md](references/scenarios/remote-team-okr.md)(何时读取:远程团队应用OKR时)
- **个人OKR模板**:见 [assets/templates/individual-okr.md](assets/templates/individual-okr.md)(直接用于填写)
- **团队OKR模板**:见 [assets/templates/team-okr.md](assets/templates/team-okr.md)(直接用于填写)
- **公司OKR模板**:见 [assets/templates/company-okr.md](assets/templates/company-okr.md)(直接用于填写)
- **季度复盘模板**:见 [assets/templates/quarterly-review.md](assets/templates/quarterly-review.md)(直接用于填写)
- **OKR级联图**:见 [assets/templates/okr-cascade-diagram.md](assets/templates/okr-cascade-diagram.md)(何时读取:需要对齐OKR时)
- **OKR风险矩阵**:见 [assets/templates/okr-risk-matrix.md](assets/templates/okr-risk-matrix.md)(何时读取:识别和管理风险时)

## 注意事项
- OKR 是目标管理工具,不是绩效考核工具,避免与薪酬直接挂钩
- 目标不宜过多,聚焦最重要的事项,每个周期 3-5 个目标
- KR 必须可量化,拒绝模糊描述如"提升用户体验"
- 保持透明和公开,促进跨团队协作
- 定期跟踪和复盘,OKR 是动态过程而非一次性设定
- 充分利用智能体的推理和分析能力,根据具体场景提供定制化建议
- 仅在需要时深入阅读参考文档,保持上下文高效

## 使用示例

### 示例1:为技术团队制定季度 OKR
- **功能说明**:制定技术团队的季度 OKR
- **执行方式**:智能体 + 模板
- **关键要点**:
  1. 了解团队当前重点(如:提升系统稳定性、加速交付)
  2. 设计 3-5 个目标,如"构建高可用的基础设施"
  3. 每个目标下设计 3-5 个可衡量的 KR,如"将系统可用性提升至 99.99%"
  4. 使用 [assets/templates/team-okr.md](assets/templates/team-okr.md) 填写
  5. 根据 [references/okr-pitfalls.md](references/okr-pitfalls.md) 检查常见错误

### 示例2:诊断 OKR 执行不力的原因
- **功能说明**:分析 OKR 无法有效执行的深层原因
- **执行方式**:智能体分析 + 参考文档
- **关键要点**:
  1. 收集当前 OKR 执行情况(完成度、跟踪频率、团队反馈)
  2. 阅读 [references/okr-pitfalls.md](references/okr-pitfalls.md) 对照陷阱清单
  3. 识别问题类型(如目标设定不合理、缺乏跟踪机制、与绩效挂钩等)
  4. 应用对应的解决方案
  5. 参考 [references/okr-cases.md](references/okr-cases.md) 中的类似案例

### 示例3:帮助新员工理解 OKR 方法论
- **功能说明**:为新员工提供 OKR 方法论培训
- **执行方式**:智能体讲解 + 框架文档
- **关键要点**:
  1. 介绍 OKR 核心理念和价值
  2. 解释 OKR 与 KPI 的区别
  3. 说明目标设定方法(CRAFT模型)和关键结果设计原则(SMART)
  4. 展示经典案例 [references/okr-cases.md](references/okr-cases.md)
  5. 提供个人 OKR 模板 [assets/templates/individual-okr.md](assets/templates/individual-okr.md) 供实践
