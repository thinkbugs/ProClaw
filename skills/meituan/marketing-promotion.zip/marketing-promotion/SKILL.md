---
name: marketing-promotion
description: 餐饮营销推广能力，包含会员营销、活动策划、私域运营、优惠券策略；当用户需要进行营销活动、会员运营、私域维护时使用
author: ProClaw
author_url: https://www.ProClaw.top
dependency:
  python:
    - numpy==1.26.2
---

# 营销推广Skill

## 任务目标
- 本Skill用于：餐饮门店的营销推广
- 能力包含：会员营销、活动策划、私域运营、优惠券策略、社群互动
- 触发条件：营销活动、会员运营、复购提升、私域建设

## 操作步骤

### 标准流程

#### 1. 会员营销
- 会员体系设计
- 积分规则制定
- 会员权益规划
- 会员画像分析

#### 2. 活动策划
- 节日活动策划
- 主题活动设计
- 活动效果预估
- 执行与复盘

#### 3. 私域运营
- 企业微信搭建
- 社群运营策略
- 内容营销
- 顾客互动

#### 4. 优惠券策略
- 券类型设计
- 发放策略
- 核销跟踪
- ROI分析

## 资源索引

### 必要脚本
- [scripts/membership_analyzer.py](scripts/membership_analyzer.py) - 会员分析与优惠券优化引擎，支持RFM会员分层、精准营销策略、优惠券ROI分析，输出会员报告与营销建议

### 领域参考
- [references/member_strategy.md](references/member_strategy.md) - 会员策略
- [references/activity_cases.md](references/activity_cases.md) - 活动案例库

## 顶级玩家实战要点

### 1. 会员运营核心
- **拉新**：降低入会门槛
- **活跃**：定期触达互动
- **复购**：专属优惠激励
- **裂变**：老带新机制

### 2. 活动ROI导向
- 每次活动都要算账
- 目标ROI > 3.0
- 持续优化活动设计

### 3. 私域价值
- 私域流量免费触达
- 建立长期顾客关系
- 提升复购率和客单价
