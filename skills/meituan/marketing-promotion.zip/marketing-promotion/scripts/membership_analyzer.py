#!/usr/bin/env python3
"""
会员分析与优惠券优化引擎
会员价值分析、优惠券效果追踪、营销ROI计算

使用方式:
    python membership_analyzer.py --output membership_report.json
"""

import argparse
import json
import sys
from datetime import datetime, timedelta
from typing import Dict, List
import numpy as np


class MembershipAnalyzer:
    """会员分析引擎"""
    
    def __init__(self):
        self.members = {}
        self.rfm_thresholds = {
            'recency': {'high': 7, 'medium': 30, 'low': 90},
            'frequency': {'high': 10, 'medium': 5, 'low': 2},
            'monetary': {'high': 500, 'medium': 200, 'low': 100}
        }
    
    def add_member(self, member_data: Dict):
        """
        添加会员数据
        
        参数:
            member_data: {
                'member_id': 'M001',
                'name': '张三',
                'phone': '138****1234',
                'register_date': '2023-01-15',
                'last_visit': '2024-01-10',
                'total_visits': 12,
                'total_spent': 1580,
                'avg_spend': 132,
                'favorite_dishes': ['宫保鸡丁', '水煮鱼']
            }
        """
        self.members[member_data['member_id']] = member_data
    
    def calculate_rfm(self, member_id: str) -> Dict:
        """
        计算RFM值
        
        R (Recency): 最近一次消费距今天数
        F (Frequency): 消费频次
        M (Monetary): 消费金额
        """
        if member_id not in self.members:
            return {}
        
        member = self.members[member_id]
        last_visit = datetime.strptime(member['last_visit'], '%Y-%m-%d')
        recency = (datetime.now() - last_visit).days
        
        return {
            'member_id': member_id,
            'name': member['name'],
            'recency': recency,
            'frequency': member['total_visits'],
            'monetary': member['total_spent'],
            'r_score': self._score_recency(recency),
            'f_score': self._score_frequency(member['total_visits']),
            'm_score': self._score_monetary(member['total_spent']),
            'segment': self._segment_member(recency, member['total_visits'], member['total_spent'])
        }
    
    def _score_recency(self, days: int) -> int:
        """R评分"""
        if days <= self.rfm_thresholds['recency']['high']:
            return 5
        elif days <= self.rfm_thresholds['recency']['medium']:
            return 3
        elif days <= self.rfm_thresholds['recency']['low']:
            return 2
        else:
            return 1
    
    def _score_frequency(self, visits: int) -> int:
        """F评分"""
        if visits >= self.rfm_thresholds['frequency']['high']:
            return 5
        elif visits >= self.rfm_thresholds['frequency']['medium']:
            return 3
        elif visits >= self.rfm_thresholds['frequency']['low']:
            return 2
        else:
            return 1
    
    def _score_monetary(self, amount: float) -> int:
        """M评分"""
        if amount >= self.rfm_thresholds['monetary']['high']:
            return 5
        elif amount >= self.rfm_thresholds['monetary']['medium']:
            return 3
        elif amount >= self.rfm_thresholds['monetary']['low']:
            return 2
        else:
            return 1
    
    def _segment_member(self, r: int, f: int, m: float) -> str:
        """会员分层"""
        if r <= 7 and f >= 10 and m >= 500:
            return 'champion'
        elif r <= 30 and f >= 5 and m >= 200:
            return 'loyal'
        elif r <= 30 and f < 5 and m >= 200:
            return 'potential_loyal'
        elif r > 90 and f >= 5 and m >= 200:
            return 'at_risk'
        elif r > 90:
            return 'lost'
        else:
            return 'new'
    
    def get_segment_summary(self) -> Dict:
        """会员分层统计"""
        segments = {
            'champion': {'name': '冠军会员', 'count': 0, 'total_spent': 0},
            'loyal': {'name': '忠诚会员', 'count': 0, 'total_spent': 0},
            'potential_loyal': {'name': '潜力会员', 'count': 0, 'total_spent': 0},
            'at_risk': {'name': '流失风险', 'count': 0, 'total_spent': 0},
            'lost': {'name': '已流失', 'count': 0, 'total_spent': 0},
            'new': {'name': '新会员', 'count': 0, 'total_spent': 0}
        }
        
        for member_id in self.members.keys():
            rfm = self.calculate_rfm(member_id)
            segment = rfm['segment']
            segments[segment]['count'] += 1
            segments[segment]['total_spent'] += rfm['monetary']
        
        total_members = sum(s['count'] for s in segments.values())
        
        for segment in segments.values():
            segment['percentage'] = round(segment['count'] / total_members * 100, 1) if total_members > 0 else 0
            segment['avg_spent'] = round(segment['total_spent'] / segment['count'], 2) if segment['count'] > 0 else 0
        
        return {
            'timestamp': datetime.now().isoformat(),
            'total_members': total_members,
            'segments': segments
        }
    
    def generate_targeting_strategy(self) -> List[Dict]:
        """生成精准营销策略"""
        strategies = []
        
        # 冠军会员：VIP专属服务
        strategies.append({
            'segment': 'champion',
            'strategy': 'VIP专属服务',
            'actions': [
                '优先预留座位',
                '生日专属优惠',
                '主厨推荐体验'
            ],
            'expected_roi': '高'
        })
        
        # 流失风险会员：召回活动
        strategies.append({
            'segment': 'at_risk',
            'strategy': '召回活动',
            'actions': [
                '发送回归优惠券',
                '电话回访关怀',
                '新品试吃邀请'
            ],
            'expected_roi': '中'
        })
        
        # 潜力会员：转化激励
        strategies.append({
            'segment': 'potential_loyal',
            'strategy': '转化激励',
            'actions': [
                '充值返现活动',
                '会员升级礼包',
                '推荐有礼'
            ],
            'expected_roi': '高'
        })
        
        return strategies


class CouponOptimizer:
    """优惠券优化引擎"""
    
    def __init__(self):
        self.coupons = {}
    
    def add_coupon(self, coupon_data: Dict):
        """
        添加优惠券数据
        
        参数:
            coupon_data: {
                'coupon_id': 'C001',
                'type': 'discount',  # discount/amount/percent
                'value': 20,  # 减20元 / 8折
                'min_spend': 100,
                'valid_days': 30,
                'issued': 1000,
                'used': 350,
                'total_revenue': 45000
            }
        """
        self.coupons[coupon_data['coupon_id']] = coupon_data
    
    def calculate_coupon_performance(self, coupon_id: str) -> Dict:
        """计算优惠券表现"""
        if coupon_id not in self.coupons:
            return {}
        
        coupon = self.coupons[coupon_id]
        usage_rate = (coupon['used'] / coupon['issued']) * 100 if coupon['issued'] > 0 else 0
        avg_order_value = coupon['total_revenue'] / coupon['used'] if coupon['used'] > 0 else 0
        
        # 计算ROI
        if coupon['type'] == 'amount':
            discount_cost = coupon['value'] * coupon['used']
        elif coupon['type'] == 'percent':
            discount_cost = coupon['total_revenue'] * (1 - coupon['value'] / 100)
        else:
            discount_cost = 0
        
        roi = (coupon['total_revenue'] - discount_cost) / discount_cost * 100 if discount_cost > 0 else 0
        
        return {
            'coupon_id': coupon_id,
            'type': coupon['type'],
            'value': coupon['value'],
            'issued': coupon['issued'],
            'used': coupon['used'],
            'usage_rate': f"{round(usage_rate, 1)}%",
            'total_revenue': coupon['total_revenue'],
            'avg_order_value': round(avg_order_value, 2),
            'discount_cost': round(discount_cost, 2),
            'roi': f"{round(roi, 1)}%",
            'performance': 'excellent' if usage_rate > 50 else 'good' if usage_rate > 30 else 'poor'
        }
    
    def optimize_coupon_strategy(self) -> Dict:
        """优化优惠券策略"""
        performances = []
        
        for coupon_id in self.coupons.keys():
            performances.append(self.calculate_coupon_performance(coupon_id))
        
        # 按使用率排序
        performances.sort(key=lambda x: float(x['usage_rate'].replace('%', '')), reverse=True)
        
        return {
            'timestamp': datetime.now().isoformat(),
            'recommendations': [
                '高使用率优惠券：增加投放',
                '低使用率优惠券：调整门槛或面值',
                '周末/节假日：发放大额券',
                '工作日午餐：发放小额高频券'
            ],
            'performance_ranking': performances
        }


def main():
    parser = argparse.ArgumentParser(description='会员分析工具')
    parser.add_argument('--output', type=str, default='membership_report.json', help='输出文件')
    
    args = parser.parse_args()
    
    # 会员分析
    member_analyzer = MembershipAnalyzer()
    
    # 添加示例会员
    member_analyzer.add_member({
        'member_id': 'M001',
        'name': '张三',
        'phone': '138****1234',
        'register_date': '2023-01-15',
        'last_visit': '2024-01-10',
        'total_visits': 15,
        'total_spent': 2180,
        'avg_spend': 145,
        'favorite_dishes': ['宫保鸡丁', '水煮鱼']
    })
    
    member_analyzer.add_member({
        'member_id': 'M002',
        'name': '李四',
        'phone': '139****5678',
        'register_date': '2023-06-20',
        'last_visit': '2023-10-15',
        'total_visits': 6,
        'total_spent': 580,
        'avg_spend': 97,
        'favorite_dishes': ['蛋花汤']
    })
    
    # 优惠券分析
    coupon_optimizer = CouponOptimizer()
    
    coupon_optimizer.add_coupon({
        'coupon_id': 'C001',
        'type': 'amount',
        'value': 20,
        'min_spend': 100,
        'valid_days': 30,
        'issued': 1000,
        'used': 350,
        'total_revenue': 45000
    })
    
    coupon_optimizer.add_coupon({
        'coupon_id': 'C002',
        'type': 'percent',
        'value': 85,  # 85折
        'min_spend': 50,
        'valid_days': 7,
        'issued': 500,
        'used': 280,
        'total_revenue': 28000
    })
    
    try:
        # 会员分层统计
        segment_summary = member_analyzer.get_segment_summary()
        
        # 营销策略
        strategies = member_analyzer.generate_targeting_strategy()
        
        # 优惠券优化
        coupon_optimization = coupon_optimizer.optimize_coupon_strategy()
        
        result = {
            'membership_analysis': segment_summary,
            'targeting_strategies': strategies,
            'coupon_optimization': coupon_optimization
        }
        
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        
        print(f"[SUCCESS] 会员分析报告已生成: {args.output}")
        
        print(f"\n[MEMBER SEGMENTS] 会员分层:")
        for segment_key, segment_data in segment_summary['segments'].items():
            if segment_data['count'] > 0:
                print(f"  - {segment_data['name']}: {segment_data['count']}人 ({segment_data['percentage']}%)")
        
        print(f"\n[COUPON PERFORMANCE] 优惠券表现:")
        for perf in coupon_optimization['performance_ranking'][:2]:
            print(f"  - {perf['coupon_id']}: 使用率 {perf['usage_rate']}, ROI {perf['roi']}")
        
        return 0
        
    except Exception as e:
        print(f"[ERROR] 分析失败: {str(e)}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
