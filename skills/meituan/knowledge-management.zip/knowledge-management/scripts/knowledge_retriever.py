#!/usr/bin/env python3
"""
知识检索与经验萃取引擎
知识库管理、智能检索、经验沉淀

使用方式:
    python knowledge_retriever.py --query "如何提升翻台率" --output knowledge_result.json
"""

import argparse
import json
import sys
from datetime import datetime
from typing import Dict, List
import re


class KnowledgeRetriever:
    """知识检索引擎"""
    
    def __init__(self):
        self.knowledge_base = {}
        self.categories = {
            'operations': '运营管理',
            'cost': '成本控制',
            'service': '服务技巧',
            'kitchen': '后厨管理',
            'marketing': '营销策略',
            'safety': '食品安全'
        }
    
    def add_knowledge(self, knowledge_data: Dict):
        """
        添加知识条目
        
        参数:
            knowledge_data: {
                'id': 'K001',
                'title': '提升翻台率的10个技巧',
                'category': 'operations',
                'content': '详细内容...',
                'tags': ['翻台率', '效率', '服务'],
                'author': '店长',
                'created_at': '2024-01-01',
                'views': 150,
                'rating': 4.8
            }
        """
        self.knowledge_base[knowledge_data['id']] = knowledge_data
    
    def search(self, query: str, top_k: int = 5) -> List[Dict]:
        """
        智能检索
        
        参数:
            query: 搜索关键词
            top_k: 返回结果数量
        """
        results = []
        query_lower = query.lower()
        
        for kid, knowledge in self.knowledge_base.items():
            score = 0
            
            # 标题匹配
            if query_lower in knowledge['title'].lower():
                score += 10
            
            # 标签匹配
            for tag in knowledge.get('tags', []):
                if query_lower in tag.lower():
                    score += 5
            
            # 内容匹配
            if query_lower in knowledge['content'].lower():
                score += 3
            
            # 类别匹配
            if query_lower in self.categories.get(knowledge['category'], '').lower():
                score += 2
            
            # 热度加成
            score += min(knowledge.get('views', 0) / 100, 2)
            
            # 评分加成
            score += knowledge.get('rating', 0)
            
            if score > 0:
                results.append({
                    'id': kid,
                    'title': knowledge['title'],
                    'category': self.categories.get(knowledge['category'], knowledge['category']),
                    'tags': knowledge.get('tags', []),
                    'summary': knowledge['content'][:100] + '...',
                    'score': round(score, 1),
                    'views': knowledge.get('views', 0),
                    'rating': knowledge.get('rating', 0)
                })
        
        # 按得分排序
        results.sort(key=lambda x: x['score'], reverse=True)
        
        return results[:top_k]
    
    def get_by_category(self, category: str) -> List[Dict]:
        """按类别获取知识"""
        results = []
        
        for kid, knowledge in self.knowledge_base.items():
            if knowledge['category'] == category:
                results.append({
                    'id': kid,
                    'title': knowledge['title'],
                    'summary': knowledge['content'][:100] + '...',
                    'views': knowledge.get('views', 0),
                    'rating': knowledge.get('rating', 0)
                })
        
        return results
    
    def get_recommendations(self, context: str = None) -> List[Dict]:
        """获取推荐知识"""
        # 按评分和浏览量排序
        all_knowledge = [
            {
                'id': kid,
                'title': k['title'],
                'category': self.categories.get(k['category'], k['category']),
                'views': k.get('views', 0),
                'rating': k.get('rating', 0),
                'score': k.get('views', 0) * 0.3 + k.get('rating', 0) * 2
            }
            for kid, k in self.knowledge_base.items()
        ]
        
        all_knowledge.sort(key=lambda x: x['score'], reverse=True)
        
        return all_knowledge[:5]


class ExperienceExtractor:
    """经验萃取引擎"""
    
    def __init__(self):
        self.experiences = []
    
    def add_experience(self, experience_data: Dict):
        """
        添加经验案例
        
        参数:
            experience_data: {
                'id': 'E001',
                'title': '如何处理顾客投诉',
                'scenario': '顾客投诉菜品口味问题',
                'action': '耐心倾听、道歉、更换菜品、赠送小礼品',
                'result': '顾客满意离开，后续再次光顾',
                'key_learnings': ['耐心倾听是关键', '快速响应最重要'],
                'applicable_situations': ['菜品投诉', '服务投诉'],
                'contributor': '前厅经理',
                'date': '2024-01-10'
            }
        """
        self.experiences.append(experience_data)
    
    def extract_best_practices(self) -> List[Dict]:
        """萃取最佳实践"""
        best_practices = []
        
        for exp in self.experiences:
            practice = {
                'id': exp['id'],
                'title': exp['title'],
                'scenario': exp['scenario'],
                'recommended_action': exp['action'],
                'expected_result': exp['result'],
                'key_points': exp.get('key_learnings', []),
                'applicable_when': exp.get('applicable_situations', [])
            }
            
            best_practices.append(practice)
        
        return best_practices
    
    def find_similar_cases(self, scenario: str) -> List[Dict]:
        """查找相似案例"""
        similar_cases = []
        scenario_lower = scenario.lower()
        
        for exp in self.experiences:
            # 简单的关键词匹配
            match_score = 0
            
            if scenario_lower in exp['scenario'].lower():
                match_score += 5
            
            for situation in exp.get('applicable_situations', []):
                if scenario_lower in situation.lower():
                    match_score += 3
            
            if match_score > 0:
                similar_cases.append({
                    'id': exp['id'],
                    'title': exp['title'],
                    'scenario': exp['scenario'],
                    'action': exp['action'],
                    'result': exp['result'],
                    'match_score': match_score
                })
        
        similar_cases.sort(key=lambda x: x['match_score'], reverse=True)
        
        return similar_cases[:3]
    
    def generate_sop(self, scenario: str) -> Dict:
        """生成标准操作流程"""
        similar_cases = self.find_similar_cases(scenario)
        
        if not similar_cases:
            return {
                'scenario': scenario,
                'message': '未找到相关案例，建议手动创建SOP'
            }
        
        # 整合最佳实践
        steps = []
        for i, case in enumerate(similar_cases, 1):
            steps.append({
                'step': i,
                'action': case['action'],
                'expected_outcome': case['result']
            })
        
        return {
            'scenario': scenario,
            'generated_at': datetime.now().isoformat(),
            'standard_procedure': {
                'title': f"{scenario}处理流程",
                'steps': steps,
                'notes': [
                    '保持冷静和专业',
                    '及时记录处理过程',
                    '跟进客户满意度'
                ]
            },
            'based_on_cases': [c['id'] for c in similar_cases]
        }


def main():
    parser = argparse.ArgumentParser(description='知识检索工具')
    parser.add_argument('--query', type=str, help='搜索关键词')
    parser.add_argument('--output', type=str, default='knowledge_result.json', help='输出文件')
    
    args = parser.parse_args()
    
    # 知识检索
    retriever = KnowledgeRetriever()
    
    retriever.add_knowledge({
        'id': 'K001',
        'title': '提升翻台率的10个技巧',
        'category': 'operations',
        'content': '1. 优化点餐流程，推荐套餐组合。2. 设置合理的用餐时间提醒。3. 提前准备常用菜品。4. 动态调整座位安排。5. 优化结账流程...',
        'tags': ['翻台率', '效率', '运营'],
        'author': '店长',
        'created_at': '2024-01-01',
        'views': 150,
        'rating': 4.8
    })
    
    retriever.add_knowledge({
        'id': 'K002',
        'title': '成本控制最佳实践',
        'category': 'cost',
        'content': '建立成本监控体系，每日记录食材消耗。优化采购流程，集中采购降低成本。减少浪费，合理预估销量...',
        'tags': ['成本', '采购', '浪费'],
        'author': '财务经理',
        'created_at': '2024-01-05',
        'views': 120,
        'rating': 4.6
    })
    
    # 经验萃取
    extractor = ExperienceExtractor()
    
    extractor.add_experience({
        'id': 'E001',
        'title': '如何处理顾客投诉',
        'scenario': '顾客投诉菜品口味问题',
        'action': '耐心倾听、道歉、更换菜品、赠送小礼品',
        'result': '顾客满意离开，后续再次光顾',
        'key_learnings': ['耐心倾听是关键', '快速响应最重要'],
        'applicable_situations': ['菜品投诉', '服务投诉'],
        'contributor': '前厅经理',
        'date': '2024-01-10'
    })
    
    try:
        if args.query:
            # 搜索
            search_results = retriever.search(args.query)
            
            result = {
                'timestamp': datetime.now().isoformat(),
                'query': args.query,
                'search_results': search_results,
                'recommendations': retriever.get_recommendations()
            }
        else:
            # 获取推荐
            result = {
                'timestamp': datetime.now().isoformat(),
                'recommendations': retriever.get_recommendations(),
                'best_practices': extractor.extract_best_practices()
            }
        
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        
        print(f"[SUCCESS] 知识检索结果已生成: {args.output}")
        
        if 'search_results' in result:
            print(f"\n[SEARCH RESULTS] 搜索结果 ({args.query}):")
            for item in result['search_results'][:3]:
                print(f"  - {item['title']} (评分: {item['score']})")
        else:
            print(f"\n[RECOMMENDATIONS] 推荐知识:")
            for item in result['recommendations'][:3]:
                print(f"  - {item['title']} (浏览: {item['views']}, 评分: {item['rating']})")
        
        return 0
        
    except Exception as e:
        print(f"[ERROR] 检索失败: {str(e)}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
