---
name: knowledge-management
description: 餐饮知识管理能力，包含经验萃取、文档向量化、语义检索、最佳实践推送；当用户需要沉淀经验、培训员工、知识传承时使用
author: ProClaw
author_url: https://www.ProClaw.top
dependency:
  python:
    - numpy==1.26.2
---

# 知识管理Skill

## 任务目标
- 本Skill用于：餐饮门店的知识管理与传承
- 能力包含：经验萃取、知识沉淀、培训支持、最佳实践推送
- 触发条件：知识沉淀、员工培训、经验传承、能力建设

## 操作步骤

### 标准流程

#### 1. 经验萃取
- 成功案例收集
- 失败教训总结
- 操作技巧记录
- 最佳实践提炼

#### 2. 知识沉淀
- 菜品配方库
- 服务流程库
- 问题解决库
- 培训资料库

#### 3. 知识检索
- 智能搜索
- 语义匹配
- 知识推荐
- 场景推送

#### 4. 培训支持
- 新员工培训
- 技能提升培训
- 在线学习
- 考核评估

## 资源索引

### 必要脚本
- [scripts/knowledge_retriever.py](scripts/knowledge_retriever.py) - 知识检索与经验萃取引擎，支持智能检索、知识推荐、经验萃取、SOP生成，输出检索结果与最佳实践
- [references/knowledge_framework.md](references/knowledge_framework.md) - 知识框架
- [references/training_materials.md](references/training_materials.md) - 培训资料

## 顶级玩家实战要点

### 1. 知识即资产
- 把隐性知识显性化
- 把个人经验组织化
- 持续积累、迭代

### 2. 培训标准化
- 所有岗位都有培训手册
- 新员工培训周期化
- 培训效果可考核

### 3. 知识更新机制
- 定期更新知识库
- 淘汰过时内容
- 持续优化迭代
