#!/usr/bin/env python3
"""
库存管理与效期监控引擎
库存优化、效期预警、安全库存计算

使用方式:
    python inventory_manager.py --output inventory_report.json
"""

import argparse
import json
import sys
from datetime import datetime, timedelta
from typing import Dict, List
import numpy as np


class InventoryManager:
    """库存管理引擎"""
    
    def __init__(self):
        self.inventory = {}
        self.safety_stock_config = {
            'critical': 0.3,   # 安全库存系数
            'warning': 0.5,    # 预警系数
            'optimal': 0.7     # 最优系数
        }
    
    def add_item(self, item: Dict):
        """
        添加库存项
        
        参数:
            item: {
                'item_id': 'M001',
                'name': '鸡胸肉',
                'category': '肉类',
                'unit': 'kg',
                'current_stock': 50,
                'daily_usage': 10,
                'cost_per_unit': 25,
                'shelf_life_days': 7,
                'expiry_date': '2024-01-22',
                'supplier': '供应商A'
            }
        """
        self.inventory[item['item_id']] = item
    
    def calculate_safety_stock(self, item_id: str) -> Dict:
        """
        计算安全库存
        
        安全库存 = 日均用量 × 补货周期 × 安全系数
        """
        if item_id not in self.inventory:
            return {}
        
        item = self.inventory[item_id]
        daily_usage = item['daily_usage']
        lead_time = 2  # 补货周期（天）
        
        safety_stock = daily_usage * lead_time * self.safety_stock_config['critical']
        warning_stock = daily_usage * lead_time * self.safety_stock_config['warning']
        optimal_stock = daily_usage * lead_time * self.safety_stock_config['optimal']
        
        return {
            'item_id': item_id,
            'name': item['name'],
            'current_stock': item['current_stock'],
            'daily_usage': daily_usage,
            'safety_stock': round(safety_stock, 1),
            'warning_stock': round(warning_stock, 1),
            'optimal_stock': round(optimal_stock, 1),
            'days_of_stock': round(item['current_stock'] / daily_usage, 1),
            'status': self._get_stock_status(item['current_stock'], safety_stock, warning_stock)
        }
    
    def _get_stock_status(self, current: float, safety: float, warning: float) -> str:
        """获取库存状态"""
        if current < safety:
            return 'critical'
        elif current < warning:
            return 'warning'
        else:
            return 'normal'
    
    def check_expiry(self) -> List[Dict]:
        """
        效期检查
        
        规则：
        - 剩余 < 1天：紧急处理
        - 剩余 < 3天：优先使用
        - 剩余 < 5天：正常使用
        """
        expiry_alerts = []
        today = datetime.now()
        
        for item_id, item in self.inventory.items():
            expiry_date = datetime.strptime(item['expiry_date'], '%Y-%m-%d')
            days_left = (expiry_date - today).days
            
            if days_left < 0:
                alert_level = 'expired'
            elif days_left < 1:
                alert_level = 'critical'
            elif days_left < 3:
                alert_level = 'warning'
            elif days_left < 5:
                alert_level = 'notice'
            else:
                continue
            
            expiry_alerts.append({
                'item_id': item_id,
                'name': item['name'],
                'expiry_date': item['expiry_date'],
                'days_left': days_left,
                'current_stock': item['current_stock'],
                'alert_level': alert_level,
                'action': self._get_expiry_action(alert_level, item)
            })
        
        return sorted(expiry_alerts, key=lambda x: x['days_left'])
    
    def _get_expiry_action(self, level: str, item: Dict) -> str:
        """获取效期处理建议"""
        actions = {
            'expired': f"立即报废 {item['current_stock']} {item['unit']}",
            'critical': f"今日内使用或促销处理",
            'warning': f"优先使用，减少采购",
            'notice': f"正常使用，加速周转"
        }
        return actions.get(level, '')
    
    def generate_reorder_suggestions(self) -> List[Dict]:
        """生成补货建议"""
        suggestions = []
        
        for item_id in self.inventory.keys():
            stock_info = self.calculate_safety_stock(item_id)
            
            if stock_info['status'] in ['critical', 'warning']:
                item = self.inventory[item_id]
                
                # 计算建议补货量
                reorder_qty = stock_info['optimal_stock'] - item['current_stock']
                reorder_qty = max(reorder_qty, item['daily_usage'] * 7)  # 至少补一周用量
                
                suggestions.append({
                    'item_id': item_id,
                    'name': item['name'],
                    'current_stock': item['current_stock'],
                    'reorder_quantity': round(reorder_qty, 1),
                    'estimated_cost': round(reorder_qty * item['cost_per_unit'], 2),
                    'supplier': item['supplier'],
                    'priority': 'high' if stock_info['status'] == 'critical' else 'medium'
                })
        
        return sorted(suggestions, key=lambda x: x['priority'], reverse=True)


def main():
    parser = argparse.ArgumentParser(description='库存管理工具')
    parser.add_argument('--output', type=str, default='inventory_report.json', help='输出文件')
    
    args = parser.parse_args()
    
    manager = InventoryManager()
    
    # 添加示例库存
    manager.add_item({
        'item_id': 'M001',
        'name': '鸡胸肉',
        'category': '肉类',
        'unit': 'kg',
        'current_stock': 15,
        'daily_usage': 10,
        'cost_per_unit': 25,
        'shelf_life_days': 7,
        'expiry_date': (datetime.now() + timedelta(days=2)).strftime('%Y-%m-%d'),
        'supplier': '供应商A'
    })
    
    manager.add_item({
        'item_id': 'V001',
        'name': '土豆',
        'category': '蔬菜',
        'unit': 'kg',
        'current_stock': 50,
        'daily_usage': 8,
        'cost_per_unit': 3,
        'shelf_life_days': 14,
        'expiry_date': (datetime.now() + timedelta(days=10)).strftime('%Y-%m-%d'),
        'supplier': '供应商B'
    })
    
    try:
        # 计算安全库存
        safety_stock_reports = []
        for item_id in manager.inventory.keys():
            safety_stock_reports.append(manager.calculate_safety_stock(item_id))
        
        # 效期检查
        expiry_alerts = manager.check_expiry()
        
        # 补货建议
        reorder_suggestions = manager.generate_reorder_suggestions()
        
        result = {
            'timestamp': datetime.now().isoformat(),
            'safety_stock_analysis': safety_stock_reports,
            'expiry_alerts': expiry_alerts,
            'reorder_suggestions': reorder_suggestions
        }
        
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        
        print(f"[SUCCESS] 库存报告已生成: {args.output}")
        
        print(f"\n[ALERT] 效期预警:")
        for alert in expiry_alerts:
            print(f"  - {alert['name']}: 剩余 {alert['days_left']} 天 ({alert['alert_level']})")
        
        print(f"\n[REORDER] 补货建议:")
        for suggestion in reorder_suggestions:
            print(f"  - {suggestion['name']}: 建议补货 {suggestion['reorder_quantity']} {manager.inventory[suggestion['item_id']]['unit']}")
        
        return 0
        
    except Exception as e:
        print(f"[ERROR] 生成失败: {str(e)}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
