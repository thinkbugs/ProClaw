---
name: warehouse-management
description: 仓储智能化管理能力，包含入库出库、FIFO管理、效期预警、库存盘点；当用户需要优化库存管理、减少损耗、确保食材新鲜时使用
author: ProClaw
author_url: https://www.ProClaw.top
dependency:
  python:
    - numpy==1.26.2
---

# 仓储管理Skill

## 任务目标
- 本Skill用于：仓储库存的智能化管理
- 能力包含：入库出库、FIFO管理、效期预警、库存盘点、损耗控制
- 触发条件：库存管理、效期检查、盘点需求、损耗控制

## 操作步骤

### 标准流程

#### 1. 入库管理
- 采购到货验收
- 批次信息录入
- 库位分配
- 质量检查

#### 2. 出库管理
- 先进先出（FIFO）
- 批次追溯
- 出库记录
- 库存更新

#### 3. 效期管理
- 效期标签
- 临期预警
- 临期优先使用
- 过期处理

#### 4. 库存盘点
- 每日小盘点
- 每周中盘点
- 每月大盘点
- 差异分析

## 资源索引

### 必要脚本
- [scripts/inventory_manager.py](scripts/inventory_manager.py) - 库存管理与效期监控引擎，支持安全库存计算、效期预警、补货建议，输出库存报告与预警信息

### 领域参考
- [references/storage_standards.md](references/storage_standards.md) - 储存标准
- [references/fifo_guide.md](references/fifo_guide.md) - FIFO操作指南

## 顶级玩家实战要点

### 1. 先进先出铁律
- 所有食材严格执行FIFO
- 新货放后面，旧货用前面
- 标注入库日期

### 2. 效期管理闭环
- 入库即标注效期
- 临期提前3天预警
- 临期优先使用或处理

### 3. 盘点常态化
- 不等月底再盘点
- 每日抽查，每周中盘
- 及时发现问题
