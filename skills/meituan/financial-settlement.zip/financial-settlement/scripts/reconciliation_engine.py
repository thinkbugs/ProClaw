#!/usr/bin/env python3
"""
自动对账与利润分析引擎
收入对账、成本对账、利润计算

使用方式:
    python reconciliation_engine.py --output reconciliation_report.json
"""

import argparse
import json
import sys
from datetime import datetime, timedelta
from typing import Dict, List
import numpy as np


class ReconciliationEngine:
    """对账引擎"""
    
    def __init__(self):
        self.revenue_records = []
        self.cost_records = []
    
    def add_revenue(self, revenue_data: Dict):
        """
        添加收入记录
        
        参数:
            revenue_data: {
                'date': '2024-01-15',
                'channel': 'meituan',  # meituan/eleme/dine_in
                'orders': 50,
                'gross_revenue': 5800,
                'commission': 1160,
                'net_revenue': 4640,
                'status': 'settled'  # settled/pending/dispute
            }
        """
        self.revenue_records.append(revenue_data)
    
    def add_cost(self, cost_data: Dict):
        """
        添加成本记录
        
        参数:
            cost_data: {
                'date': '2024-01-15',
                'category': 'raw_material',  # raw_material/labor/rent/utility/other
                'description': '食材采购',
                'amount': 2200,
                'status': 'paid'
            }
        """
        self.cost_records.append(cost_data)
    
    def reconcile_revenue(self, date_range: Dict = None) -> Dict:
        """
        收入对账
        
        参数:
            date_range: {'start': '2024-01-01', 'end': '2024-01-31'}
        """
        # 筛选日期范围
        records = self.revenue_records
        if date_range:
            records = [r for r in records 
                      if date_range['start'] <= r['date'] <= date_range['end']]
        
        # 按渠道汇总
        by_channel = {}
        for record in records:
            channel = record['channel']
            if channel not in by_channel:
                by_channel[channel] = {
                    'orders': 0,
                    'gross_revenue': 0,
                    'commission': 0,
                    'net_revenue': 0,
                    'settled': 0,
                    'pending': 0
                }
            
            by_channel[channel]['orders'] += record['orders']
            by_channel[channel]['gross_revenue'] += record['gross_revenue']
            by_channel[channel]['commission'] += record['commission']
            by_channel[channel]['net_revenue'] += record['net_revenue']
            
            if record['status'] == 'settled':
                by_channel[channel]['settled'] += record['net_revenue']
            else:
                by_channel[channel]['pending'] += record['net_revenue']
        
        # 计算总计
        totals = {
            'total_orders': sum(c['orders'] for c in by_channel.values()),
            'total_gross': sum(c['gross_revenue'] for c in by_channel.values()),
            'total_commission': sum(c['commission'] for c in by_channel.values()),
            'total_net': sum(c['net_revenue'] for c in by_channel.values()),
            'total_settled': sum(c['settled'] for c in by_channel.values()),
            'total_pending': sum(c['pending'] for c in by_channel.values())
        }
        
        return {
            'by_channel': by_channel,
            'totals': totals,
            'discrepancies': self._find_discrepancies(records)
        }
    
    def _find_discrepancies(self, records: List[Dict]) -> List[Dict]:
        """发现对账差异"""
        discrepancies = []
        
        for record in records:
            # 检查计算是否正确
            expected_net = record['gross_revenue'] - record['commission']
            if abs(expected_net - record['net_revenue']) > 0.01:
                discrepancies.append({
                    'date': record['date'],
                    'channel': record['channel'],
                    'type': 'calculation_error',
                    'expected': expected_net,
                    'actual': record['net_revenue'],
                    'difference': round(expected_net - record['net_revenue'], 2)
                })
        
        return discrepancies
    
    def reconcile_costs(self, date_range: Dict = None) -> Dict:
        """成本对账"""
        records = self.cost_records
        if date_range:
            records = [r for r in records 
                      if date_range['start'] <= r['date'] <= date_range['end']]
        
        # 按类别汇总
        by_category = {}
        for record in records:
            category = record['category']
            if category not in by_category:
                by_category[category] = {
                    'total': 0,
                    'paid': 0,
                    'pending': 0
                }
            
            by_category[category]['total'] += record['amount']
            if record['status'] == 'paid':
                by_category[category]['paid'] += record['amount']
            else:
                by_category[category]['pending'] += record['amount']
        
        # 计算总计
        totals = {
            'total_cost': sum(c['total'] for c in by_category.values()),
            'total_paid': sum(c['paid'] for c in by_category.values()),
            'total_pending': sum(c['pending'] for c in by_category.values())
        }
        
        return {
            'by_category': by_category,
            'totals': totals
        }
    
    def calculate_profit(self, date_range: Dict = None) -> Dict:
        """计算利润"""
        revenue = self.reconcile_revenue(date_range)
        costs = self.reconcile_costs(date_range)
        
        gross_revenue = revenue['totals']['total_gross']
        net_revenue = revenue['totals']['total_net']
        total_cost = costs['totals']['total_cost']
        
        gross_profit = net_revenue - total_cost
        gross_margin = (gross_profit / net_revenue * 100) if net_revenue > 0 else 0
        
        # 计算各渠道毛利率
        channel_margins = {}
        for channel, data in revenue['by_channel'].items():
            # 假设成本按收入比例分摊
            channel_cost = total_cost * (data['net_revenue'] / net_revenue) if net_revenue > 0 else 0
            channel_profit = data['net_revenue'] - channel_cost
            channel_margins[channel] = {
                'revenue': data['net_revenue'],
                'estimated_cost': round(channel_cost, 2),
                'profit': round(channel_profit, 2),
                'margin': round(channel_profit / data['net_revenue'] * 100, 1) if data['net_revenue'] > 0 else 0
            }
        
        return {
            'revenue_summary': revenue['totals'],
            'cost_summary': costs['totals'],
            'profit': {
                'gross_profit': round(gross_profit, 2),
                'gross_margin': f"{round(gross_margin, 1)}%",
                'channel_breakdown': channel_margins
            }
        }
    
    def generate_financial_report(self, date_range: Dict = None) -> Dict:
        """生成财务报表"""
        profit_analysis = self.calculate_profit(date_range)
        
        return {
            'generated_at': datetime.now().isoformat(),
            'period': date_range or 'all',
            'income_statement': {
                'gross_revenue': profit_analysis['revenue_summary']['total_gross'],
                'commission': profit_analysis['revenue_summary']['total_commission'],
                'net_revenue': profit_analysis['revenue_summary']['total_net'],
                'cost_of_goods': profit_analysis['cost_summary'].get('by_category', {}).get('raw_material', {}).get('total', 0),
                'gross_profit': profit_analysis['profit']['gross_profit'],
                'operating_expenses': profit_analysis['cost_summary']['total_cost'] - profit_analysis['cost_summary'].get('by_category', {}).get('raw_material', {}).get('total', 0),
                'net_profit': profit_analysis['profit']['gross_profit']
            },
            'key_metrics': {
                'average_order_value': round(profit_analysis['revenue_summary']['total_gross'] / profit_analysis['revenue_summary']['total_orders'], 2) if profit_analysis['revenue_summary']['total_orders'] > 0 else 0,
                'commission_rate': round(profit_analysis['revenue_summary']['total_commission'] / profit_analysis['revenue_summary']['total_gross'] * 100, 1) if profit_analysis['revenue_summary']['total_gross'] > 0 else 0,
                'cost_ratio': round(profit_analysis['cost_summary']['total_cost'] / profit_analysis['revenue_summary']['total_net'] * 100, 1) if profit_analysis['revenue_summary']['total_net'] > 0 else 0,
                'gross_margin': profit_analysis['profit']['gross_margin']
            },
            'recommendations': self._generate_recommendations(profit_analysis)
        }
    
    def _generate_recommendations(self, analysis: Dict) -> List[str]:
        """生成财务建议"""
        recommendations = []
        
        margin_str = analysis['profit']['gross_margin']
        margin = float(margin_str.replace('%', '')) if isinstance(margin_str, str) else float(margin_str)
        
        if margin < 20:
            recommendations.append("毛利率过低，需优化成本结构或调整定价策略")
        elif margin > 40:
            recommendations.append("毛利率健康，可考虑促销提升客流量")
        
        # 分析各渠道表现
        for channel, data in analysis['profit']['channel_breakdown'].items():
            channel_margin = data.get('margin', 0)
            if channel_margin:
                margin_val = float(str(channel_margin).replace('%', '')) if isinstance(channel_margin, str) else float(channel_margin)
                if margin_val < 15:
                    recommendations.append(f"{channel} 渠道毛利率偏低，建议优化运营策略")
        
        return recommendations


def main():
    parser = argparse.ArgumentParser(description='对账工具')
    parser.add_argument('--output', type=str, default='reconciliation_report.json', help='输出文件')
    
    args = parser.parse_args()
    
    engine = ReconciliationEngine()
    
    # 添加示例数据
    engine.add_revenue({
        'date': '2024-01-15',
        'channel': 'meituan',
        'orders': 30,
        'gross_revenue': 3500,
        'commission': 700,
        'net_revenue': 2800,
        'status': 'settled'
    })
    
    engine.add_revenue({
        'date': '2024-01-15',
        'channel': 'dine_in',
        'orders': 20,
        'gross_revenue': 2300,
        'commission': 0,
        'net_revenue': 2300,
        'status': 'settled'
    })
    
    engine.add_cost({
        'date': '2024-01-15',
        'category': 'raw_material',
        'description': '食材采购',
        'amount': 1800,
        'status': 'paid'
    })
    
    engine.add_cost({
        'date': '2024-01-15',
        'category': 'labor',
        'description': '员工工资',
        'amount': 800,
        'status': 'paid'
    })
    
    try:
        report = engine.generate_financial_report()
        
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        
        print(f"[SUCCESS] 对账报告已生成: {args.output}")
        
        print(f"\n[INCOME STATEMENT] 损益表:")
        print(f"  - 毛收入: ¥{report['income_statement']['gross_revenue']}")
        print(f"  - 佣金: ¥{report['income_statement']['commission']}")
        print(f"  - 净收入: ¥{report['income_statement']['net_revenue']}")
        print(f"  - 成本: ¥{report['income_statement']['cost_of_goods']}")
        print(f"  - 毛利: ¥{report['income_statement']['gross_profit']}")
        
        print(f"\n[KEY METRICS] 关键指标:")
        for metric, value in report['key_metrics'].items():
            print(f"  - {metric}: {value}")
        
        return 0
        
    except Exception as e:
        print(f"[ERROR] 对账失败: {str(e)}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
