---
name: financial-settlement
description: 餐饮财务核算能力，包含对账管理、成本利润核算、发票处理、税务合规；当用户需要进行财务对账、利润分析、合规管理时使用
author: ProClaw
author_url: https://www.ProClaw.top
dependency:
  python:
    - numpy==1.26.2
---

# 财务核算Skill

## 任务目标
- 本Skill用于：餐饮门店的财务管理
- 能力包含：对账管理、成本利润核算、发票处理、税务合规、资金管理
- 触发条件：财务对账、利润分析、成本核算、合规检查

## 操作步骤

### 标准流程

#### 1. 日结算
- 营业收入核对
- 支付渠道对账
- 现金盘点
- 日结报表

#### 2. 成本核算
- 食材成本核算
- 人力成本核算
- 其他成本核算
- 成本分析报告

#### 3. 利润分析
- 毛利润计算
- 净利润计算
- 利润率分析
- 趋势分析

#### 4. 发票管理
- 开票处理
- 发票核验
- 进项管理
- 税务申报

## 资源索引

### 必要脚本
- [scripts/reconciliation_engine.py](scripts/reconciliation_engine.py) - 自动对账与利润分析引擎，支持多渠道收入对账、成本核算、利润计算，输出财务报表与经营建议

### 领域参考
- [references/settlement_sop.md](references/settlement_sop.md) - 结算SOP
- [references/tax_compliance.md](references/tax_compliance.md) - 税务合规指南

## 顶级玩家实战要点

### 1. 日清日结
- 每日营业收入当日结清
- 现金、银行卡、外卖平台分别核对
- 发现差异立即查明

### 2. 成本精准核算
- 每日成本核算
- 标准成本vs实际成本对比
- 及时发现成本异常

### 3. 合规经营
- 所有收入如实入账
- 发票管理规范
- 税务申报及时
