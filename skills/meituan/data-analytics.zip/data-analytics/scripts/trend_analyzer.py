#!/usr/bin/env python3
"""
餐饮门店趋势分析与预测引擎
基于时间序列分析进行趋势识别和销量预测

使用方式:
    python trend_analyzer.py --input data.csv --period week
    python trend_analyzer.py --mode forecast --days 7
"""

import argparse
import json
import sys
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import numpy as np


class TrendAnalyzer:
    """餐饮门店趋势分析与预测引擎"""
    
    def __init__(self):
        self.seasonal_patterns = {
            'weekday': {
                0: 0.95,  # 周一
                1: 0.92,  # 周二
                2: 0.93,  # 周三
                3: 0.96,  # 周四
                4: 1.10,  # 周五
                5: 1.35,  # 周六
                6: 1.25   # 周日
            }
        }
    
    def calculate_moving_average(self, values: List[float], window: int = 7) -> List[float]:
        """
        计算移动平均
        """
        if len(values) < window:
            return values
        
        ma = []
        for i in range(len(values)):
            if i < window - 1:
                ma.append(np.mean(values[:i+1]))
            else:
                ma.append(np.mean(values[i-window+1:i+1]))
        
        return [round(v, 2) for v in ma]
    
    def calculate_trend(self, values: List[float]) -> Dict:
        """
        计算趋势(使用numpy实现线性回归)
        """
        if len(values) < 3:
            return {
                'direction': 'unknown',
                'slope': 0,
                'r_squared': 0
            }
        
        x = np.arange(len(values))
        y = np.array(values)
        
        # 线性回归(numpy实现)
        # y = slope * x + intercept
        n = len(x)
        sum_x = np.sum(x)
        sum_y = np.sum(y)
        sum_xy = np.sum(x * y)
        sum_x2 = np.sum(x * x)
        sum_y2 = np.sum(y * y)
        
        # 计算斜率和截距
        slope = (n * sum_xy - sum_x * sum_y) / (n * sum_x2 - sum_x * sum_x)
        intercept = (sum_y - slope * sum_x) / n
        
        # 计算R值
        numerator = n * sum_xy - sum_x * sum_y
        denominator = np.sqrt((n * sum_x2 - sum_x * sum_x) * (n * sum_y2 - sum_y * sum_y))
        r_value = numerator / denominator if denominator != 0 else 0
        
        # 判断趋势方向
        if slope > 0.5:
            direction = 'rising'
        elif slope < -0.5:
            direction = 'declining'
        else:
            direction = 'stable'
        
        return {
            'direction': direction,
            'slope': round(slope, 2),
            'r_squared': round(r_value ** 2, 2),
            'trend_strength': 'strong' if abs(r_value) > 0.7 else 'moderate' if abs(r_value) > 0.4 else 'weak'
        }
    
    def calculate_seasonality(self, data: List[Dict]) -> Dict:
        """
        计算季节性规律
        """
        if not data:
            return {}
        
        # 按星期聚合
        weekday_data = {i: [] for i in range(7)}
        
        for record in data:
            date = record.get('date', '')
            value = record.get('value', 0)
            try:
                weekday = datetime.strptime(date, '%Y-%m-%d').weekday()
                weekday_data[weekday].append(value)
            except:
                continue
        
        # 计算各星期平均值
        weekday_avg = {}
        for day, values in weekday_data.items():
            if values:
                weekday_avg[day] = round(np.mean(values), 2)
        
        # 识别高峰和低谷
        if weekday_avg:
            max_day = max(weekday_avg, key=weekday_avg.get)
            min_day = min(weekday_avg, key=weekday_avg.get)
            
            return {
                'weekday_pattern': weekday_avg,
                'peak_day': ['周一','周二','周三','周四','周五','周六','周日'][max_day],
                'trough_day': ['周一','周二','周三','周四','周五','周六','周日'][min_day],
                'peak_ratio': round(weekday_avg[max_day] / np.mean(list(weekday_avg.values())), 2)
            }
        
        return {}
    
    def calculate_growth_metrics(self, data: List[Dict]) -> Dict:
        """
        计算增长指标
        """
        if len(data) < 7:
            return {}
        
        # 提取值序列
        values = [d.get('value', 0) for d in data]
        
        # 环比增长
        wow_growth = []
        for i in range(1, len(values)):
            if values[i-1] > 0:
                growth = (values[i] - values[i-1]) / values[i-1] * 100
                wow_growth.append(round(growth, 2))
        
        # 同比增长(需要至少7天前的数据)
        yoy_growth = []
        if len(values) >= 14:
            for i in range(7, len(values)):
                if values[i-7] > 0:
                    growth = (values[i] - values[i-7]) / values[i-7] * 100
                    yoy_growth.append(round(growth, 2))
        
        return {
            'avg_wow_growth': round(np.mean(wow_growth), 2) if wow_growth else 0,
            'avg_yoy_growth': round(np.mean(yoy_growth), 2) if yoy_growth else 0,
            'growth_volatility': round(np.std(wow_growth), 2) if wow_growth else 0,
            'positive_growth_days': len([g for g in wow_growth if g > 0]),
            'negative_growth_days': len([g for g in wow_growth if g < 0])
        }
    
    def forecast_sales(self, historical_data: List[Dict], forecast_days: int = 7) -> List[Dict]:
        """
        销量预测(简单加权移动平均 + 季节性调整)
        """
        if len(historical_data) < 7:
            return []
        
        # 提取历史值
        values = [d.get('value', 0) for d in historical_data]
        
        # 计算基准值(最近7天加权平均)
        weights = [0.05, 0.08, 0.10, 0.12, 0.15, 0.20, 0.30]
        base_value = sum(v * w for v, w in zip(values[-7:], weights))
        
        # 预测未来N天
        forecasts = []
        last_date = historical_data[-1].get('date', datetime.now().strftime('%Y-%m-%d'))
        
        try:
            last_dt = datetime.strptime(last_date, '%Y-%m-%d')
        except:
            last_dt = datetime.now()
        
        for i in range(1, forecast_days + 1):
            forecast_date = (last_dt + timedelta(days=i)).strftime('%Y-%m-%d')
            weekday = (last_dt + timedelta(days=i)).weekday()
            
            # 应用季节性因子
            seasonal_factor = self.seasonal_patterns['weekday'].get(weekday, 1.0)
            forecast_value = base_value * seasonal_factor
            
            forecasts.append({
                'date': forecast_date,
                'weekday': ['周一','周二','周三','周四','周五','周六','周日'][weekday],
                'forecast_value': round(forecast_value, 2),
                'confidence': round(0.85 - 0.05 * i, 2),  # 置信度随天数递减
                'seasonal_factor': seasonal_factor
            })
        
        return forecasts
    
    def generate_trend_report(self, data: List[Dict], period: str = 'week') -> Dict:
        """
        生成趋势分析报告
        """
        if not data:
            raise ValueError("数据为空，无法分析")
        
        # 提取核心指标
        values = [d.get('value', 0) for d in data]
        dates = [d.get('date', '') for d in data]
        
        # 计算移动平均
        ma_7 = self.calculate_moving_average(values, 7)
        
        # 计算趋势
        trend = self.calculate_trend(values)
        
        # 计算季节性
        seasonality = self.calculate_seasonality(data)
        
        # 计算增长指标
        growth = self.calculate_growth_metrics(data)
        
        # 生成预测
        forecast = self.forecast_sales(data, forecast_days=7)
        
        # 统计摘要
        summary = {
            'period': period,
            'start_date': dates[0] if dates else '',
            'end_date': dates[-1] if dates else '',
            'total_days': len(data),
            'total_value': round(sum(values), 2),
            'avg_value': round(np.mean(values), 2),
            'max_value': round(max(values), 2),
            'min_value': round(min(values), 2),
            'std_dev': round(np.std(values), 2)
        }
        
        # 趋势洞察
        insights = self._generate_insights(trend, seasonality, growth, summary)
        
        return {
            'timestamp': datetime.now().isoformat(),
            'summary': summary,
            'trend': trend,
            'seasonality': seasonality,
            'growth': growth,
            'moving_average': ma_7[-7:] if len(ma_7) >= 7 else ma_7,
            'forecast': forecast,
            'insights': insights
        }
    
    def _generate_insights(self, trend: Dict, seasonality: Dict, 
                          growth: Dict, summary: Dict) -> List[str]:
        """
        生成趋势洞察
        """
        insights = []
        
        # 趋势洞察
        if trend['direction'] == 'rising':
            insights.append(f"整体呈上升趋势，日均增长约{trend['slope']}元")
        elif trend['direction'] == 'declining':
            insights.append(f"整体呈下降趋势，日均下降约{abs(trend['slope'])}元")
        else:
            insights.append("整体保持稳定，无明显趋势")
        
        # 季节性洞察
        if seasonality.get('peak_day'):
            insights.append(
                f"周度规律：{seasonality['peak_day']}为客流高峰，"
                f"{seasonality['trough_day']}为低谷"
            )
        
        # 增长洞察
        if growth.get('avg_wow_growth'):
            if growth['avg_wow_growth'] > 5:
                insights.append(f"环比增长{growth['avg_wow_growth']}%，增长势头良好")
            elif growth['avg_wow_growth'] < -5:
                insights.append(f"环比下降{abs(growth['avg_wow_growth'])}%，需关注原因")
        
        # 波动洞察
        if summary['std_dev'] > summary['avg_value'] * 0.3:
            insights.append("日间波动较大，建议分析波动原因并优化运营策略")
        
        return insights


def main():
    parser = argparse.ArgumentParser(description='餐饮门店趋势分析工具')
    parser.add_argument('--input', type=str, help='输入数据文件 (CSV/JSON)')
    parser.add_argument('--output', type=str, default='trend_report.json', help='输出文件名')
    parser.add_argument('--period', type=str, default='week', 
                       choices=['day', 'week', 'month'], help='分析周期')
    parser.add_argument('--mode', type=str, default='analysis', 
                       choices=['analysis', 'forecast'], help='运行模式')
    parser.add_argument('--days', type=int, default=7, help='预测天数')
    
    args = parser.parse_args()
    
    analyzer = TrendAnalyzer()
    
    # 示例数据(最近14天)
    base_date = datetime.now() - timedelta(days=14)
    sample_data = []
    
    np.random.seed(42)
    for i in range(14):
        date = (base_date + timedelta(days=i)).strftime('%Y-%m-%d')
        weekday = (base_date + timedelta(days=i)).weekday()
        
        # 模拟真实数据:周末客流更高
        base_value = 15000
        seasonal_factor = [0.9, 0.85, 0.88, 0.92, 1.1, 1.4, 1.3][weekday]
        value = base_value * seasonal_factor * (1 + np.random.uniform(-0.15, 0.15))
        
        sample_data.append({
            'date': date,
            'value': round(value, 2)
        })
    
    try:
        if args.mode == 'forecast':
            # 预测模式
            forecast = analyzer.forecast_sales(sample_data, args.days)
            report = {
                'timestamp': datetime.now().isoformat(),
                'forecast_days': args.days,
                'forecast': forecast
            }
        else:
            # 分析模式
            report = analyzer.generate_trend_report(sample_data, args.period)
        
        # 输出结果
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        
        print(f"[SUCCESS] 趋势分析报告已生成: {args.output}")
        print(f"\n[INFO] 核心洞察:")
        for insight in report.get('insights', []):
            print(f"  - {insight}")
        
        if args.mode == 'forecast':
            print(f"\n[FORECAST] 未来{args.days}天预测:")
            for fc in report['forecast'][:3]:
                print(f"  - {fc['date']}({fc['weekday']}): ¥{fc['forecast_value']}")
        
        return 0
        
    except Exception as e:
        print(f"[ERROR] 趋势分析失败: {str(e)}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
