#!/usr/bin/env python3
"""
餐饮门店异常检测引擎
基于统计学方法和机器学习算法识别经营异常

使用方式:
    python anomaly_detector.py --input report.json --threshold 2.0
    python anomaly_detector.py --mode realtime --alert
"""

import argparse
import json
import sys
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import numpy as np


class AnomalyDetector:
    """餐饮门店异常检测引擎"""
    
    def __init__(self, threshold: float = 2.0):
        """
        初始化异常检测器
        
        参数:
            threshold: Z-score阈值，超过此值判定为异常
        """
        self.threshold = threshold
        self.anomaly_rules = self._load_anomaly_rules()
    
    def _load_anomaly_rules(self) -> Dict:
        """加载异常判定规则"""
        return {
            'revenue': {
                'min': 5000,  # 最低日营业额
                'max': 100000,  # 最高日营业额
                'change_threshold': 30,  # 单日波动阈值(%)
                'description': '营业额异常'
            },
            'turnover_rate': {
                'min': 0.5,
                'max': 8.0,
                'change_threshold': 40,
                'description': '翻台率异常'
            },
            'avg_ticket': {
                'min': 30,
                'max': 300,
                'change_threshold': 25,
                'description': '客单价异常'
            },
            'gross_margin': {
                'min': 40,
                'max': 80,
                'change_threshold': 15,
                'description': '毛利率异常'
            },
            'food_cost_ratio': {
                'min': 20,
                'max': 45,
                'change_threshold': 20,
                'description': '食材成本占比异常'
            },
            'conversion_rate': {
                'min': 0.5,
                'max': 15,
                'change_threshold': 50,
                'description': '转化率异常'
            }
        }
    
    def detect_by_threshold(self, value: float, rule: Dict) -> Tuple[bool, str]:
        """
        基于阈值判定异常
        """
        if value < rule['min']:
            return True, f"低于下限 {rule['min']}"
        if value > rule['max']:
            return True, f"超过上限 {rule['max']}"
        return False, "正常范围"
    
    def detect_by_zscore(self, values: List[float], current: float) -> Tuple[bool, float, str]:
        """
        基于Z-score判定异常
        """
        if len(values) < 3:
            return False, 0.0, "数据量不足"
        
        mean = np.mean(values)
        std = np.std(values)
        
        if std == 0:
            return False, 0.0, "无波动"
        
        z_score = (current - mean) / std
        
        is_anomaly = abs(z_score) > self.threshold
        
        direction = "显著上升" if z_score > 0 else "显著下降"
        
        return is_anomaly, round(z_score, 2), direction
    
    def detect_by_change_rate(self, current: float, previous: float, 
                               threshold: float) -> Tuple[bool, float]:
        """
        基于变化率判定异常
        """
        if previous == 0:
            return False, 0.0
        
        change_rate = abs((current - previous) / previous * 100)
        is_anomaly = change_rate > threshold
        
        return is_anomaly, round(change_rate, 2)
    
    def detect_revenue_anomaly(self, data: Dict, history: Optional[List[float]] = None) -> Dict:
        """
        检测营业额异常
        """
        revenue = data.get('revenue', {}).get('total', 0)
        rule = self.anomaly_rules['revenue']
        
        anomalies = []
        
        # 1. 阈值检测
        is_anomaly, reason = self.detect_by_threshold(revenue, rule)
        if is_anomaly:
            anomalies.append({
                'type': 'threshold',
                'severity': 'high',
                'metric': 'revenue',
                'value': revenue,
                'reason': f"营业额{reason}",
                'recommendation': "检查数据准确性，排查营业异常原因"
            })
        
        # 2. Z-score检测(需要历史数据)
        if history and len(history) >= 3:
            is_anomaly, z_score, direction = self.detect_by_zscore(history, revenue)
            if is_anomaly:
                anomalies.append({
                    'type': 'zscore',
                    'severity': 'medium' if abs(z_score) < 3 else 'high',
                    'metric': 'revenue',
                    'value': revenue,
                    'z_score': z_score,
                    'reason': f"营业额{direction}(Z-score: {z_score})",
                    'recommendation': "分析客流、转化、客单价变化，定位根因"
                })
        
        return {
            'metric': 'revenue',
            'value': revenue,
            'is_anomaly': len(anomalies) > 0,
            'anomalies': anomalies
        }
    
    def detect_efficiency_anomaly(self, data: Dict) -> Dict:
        """
        检测效率指标异常
        """
        efficiency = data.get('efficiency', {})
        anomalies = []
        
        # 翻台率
        turnover = efficiency.get('turnover_rate', 0)
        rule = self.anomaly_rules['turnover_rate']
        is_anomaly, reason = self.detect_by_threshold(turnover, rule)
        if is_anomaly:
            anomalies.append({
                'type': 'threshold',
                'severity': 'medium',
                'metric': 'turnover_rate',
                'value': turnover,
                'reason': f"翻台率{reason}",
                'recommendation': "优化前厅服务流程，缩短翻台时间"
            })
        
        # 客单价
        avg_ticket = efficiency.get('avg_ticket', 0)
        rule = self.anomaly_rules['avg_ticket']
        is_anomaly, reason = self.detect_by_threshold(avg_ticket, rule)
        if is_anomaly:
            anomalies.append({
                'type': 'threshold',
                'severity': 'medium',
                'metric': 'avg_ticket',
                'value': avg_ticket,
                'reason': f"客单价{reason}",
                'recommendation': "检查菜单定价、套餐设计、推销话术"
            })
        
        return {
            'category': 'efficiency',
            'is_anomaly': len(anomalies) > 0,
            'anomalies': anomalies
        }
    
    def detect_profitability_anomaly(self, data: Dict) -> Dict:
        """
        检测盈利能力异常
        """
        profitability = data.get('profitability', {})
        cost_structure = data.get('cost_structure', {})
        anomalies = []
        
        # 毛利率
        gross_margin = profitability.get('gross_margin', 0)
        rule = self.anomaly_rules['gross_margin']
        is_anomaly, reason = self.detect_by_threshold(gross_margin, rule)
        if is_anomaly:
            anomalies.append({
                'type': 'threshold',
                'severity': 'high',
                'metric': 'gross_margin',
                'value': gross_margin,
                'reason': f"毛利率{reason}",
                'recommendation': "审查食材成本、损耗率、定价策略"
            })
        
        # 食材成本占比
        food_cost_ratio = cost_structure.get('food_cost_ratio', 0)
        rule = self.anomaly_rules['food_cost_ratio']
        is_anomaly, reason = self.detect_by_threshold(food_cost_ratio, rule)
        if is_anomaly:
            anomalies.append({
                'type': 'threshold',
                'severity': 'high',
                'metric': 'food_cost_ratio',
                'value': food_cost_ratio,
                'reason': f"食材成本占比{reason}",
                'recommendation': "检查采购价格、食材损耗、出品标准化"
            })
        
        return {
            'category': 'profitability',
            'is_anomaly': len(anomalies) > 0,
            'anomalies': anomalies
        }
    
    def detect_platform_anomaly(self, data: Dict) -> Dict:
        """
        检测平台指标异常
        """
        platform = data.get('platform', {})
        anomalies = []
        
        # 转化率
        conversion_rate = platform.get('conversion_rate', 0)
        rule = self.anomaly_rules['conversion_rate']
        is_anomaly, reason = self.detect_by_threshold(conversion_rate, rule)
        if is_anomaly:
            anomalies.append({
                'type': 'threshold',
                'severity': 'medium',
                'metric': 'conversion_rate',
                'value': conversion_rate,
                'reason': f"转化率{reason}",
                'recommendation': "优化店铺装修、菜单设计、活动力度"
            })
        
        # 评分
        avg_rating = platform.get('avg_rating', 0)
        if avg_rating < 4.0 and avg_rating > 0:
            anomalies.append({
                'type': 'threshold',
                'severity': 'high',
                'metric': 'avg_rating',
                'value': avg_rating,
                'reason': f"评分过低({avg_rating})",
                'recommendation': "分析差评原因，改进产品质量和服务水平"
            })
        
        return {
            'category': 'platform',
            'is_anomaly': len(anomalies) > 0,
            'anomalies': anomalies
        }
    
    def generate_anomaly_report(self, data: Dict, history: Optional[List[Dict]] = None) -> Dict:
        """
        生成综合异常报告
        """
        all_anomalies = []
        
        # 各维度检测
        revenue_result = self.detect_revenue_anomaly(data, 
            [h['revenue']['total'] for h in history] if history else None)
        if revenue_result['is_anomaly']:
            all_anomalies.extend(revenue_result['anomalies'])
        
        efficiency_result = self.detect_efficiency_anomaly(data)
        if efficiency_result['is_anomaly']:
            all_anomalies.extend(efficiency_result['anomalies'])
        
        profitability_result = self.detect_profitability_anomaly(data)
        if profitability_result['is_anomaly']:
            all_anomalies.extend(profitability_result['anomalies'])
        
        platform_result = self.detect_platform_anomaly(data)
        if platform_result['is_anomaly']:
            all_anomalies.extend(platform_result['anomalies'])
        
        # 按严重程度排序
        severity_order = {'high': 0, 'medium': 1, 'low': 2}
        all_anomalies.sort(key=lambda x: severity_order.get(x['severity'], 3))
        
        return {
            'timestamp': datetime.now().isoformat(),
            'date': data.get('date', ''),
            'total_anomalies': len(all_anomalies),
            'high_severity': len([a for a in all_anomalies if a['severity'] == 'high']),
            'medium_severity': len([a for a in all_anomalies if a['severity'] == 'medium']),
            'anomalies': all_anomalies,
            'recommendations': self._generate_recommendations(all_anomalies)
        }
    
    def _generate_recommendations(self, anomalies: List[Dict]) -> List[str]:
        """
        生成优化建议
        """
        recommendations = []
        for anomaly in anomalies:
            if 'recommendation' in anomaly:
                recommendations.append(f"[{anomaly['metric']}] {anomaly['recommendation']}")
        return list(set(recommendations))


def main():
    parser = argparse.ArgumentParser(description='餐饮门店异常检测工具')
    parser.add_argument('--input', type=str, help='输入数据文件 (JSON)')
    parser.add_argument('--output', type=str, default='anomaly_report.json', help='输出文件名')
    parser.add_argument('--threshold', type=float, default=2.0, help='Z-score阈值')
    parser.add_argument('--mode', type=str, default='batch', choices=['batch', 'realtime'], 
                       help='检测模式')
    parser.add_argument('--alert', action='store_true', help='触发告警')
    
    args = parser.parse_args()
    
    detector = AnomalyDetector(threshold=args.threshold)
    
    # 示例数据
    sample_data = {
        'date': datetime.now().strftime('%Y-%m-%d'),
        'revenue': {'total': 15000},
        'efficiency': {
            'turnover_rate': 2.8,
            'avg_ticket': 71.4
        },
        'profitability': {
            'gross_margin': 70.0
        },
        'cost_structure': {
            'food_cost_ratio': 30.0
        },
        'platform': {
            'conversion_rate': 1.7,
            'avg_rating': 4.8
        }
    }
    
    try:
        report = detector.generate_anomaly_report(sample_data)
        
        # 输出结果
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        
        print(f"[SUCCESS] 异常检测报告已生成: {args.output}")
        
        if report['total_anomalies'] > 0:
            print(f"\n[WARNING] 发现 {report['total_anomalies']} 个异常:")
            for anomaly in report['anomalies']:
                print(f"  - [{anomaly['severity'].upper()}] {anomaly['metric']}: {anomaly['reason']}")
            
            if args.alert:
                print("\n[ALERT] 已触发告警通知")
        else:
            print(f"[INFO] 未检测到异常")
        
        return 0
        
    except Exception as e:
        print(f"[ERROR] 异常检测失败: {str(e)}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
