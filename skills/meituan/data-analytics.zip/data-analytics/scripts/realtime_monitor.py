#!/usr/bin/env python3
"""
实时监控引擎
实时数据采集、监控告警、异常检测

使用方式:
    python realtime_monitor.py --interval 60 --output monitoring_report.json
"""

import argparse
import json
import sys
from datetime import datetime, timedelta
from typing import Dict, List
import numpy as np


class RealtimeMonitor:
    """实时监控引擎"""
    
    def __init__(self):
        self.metrics = {}
        self.thresholds = {
            'revenue_per_hour': {'warning': 500, 'critical': 300},
            'orders_per_hour': {'warning': 10, 'critical': 5},
            'avg_order_value': {'warning': 60, 'critical': 40},
            'cancel_rate': {'warning': 0.05, 'critical': 0.10},
            'wait_time': {'warning': 15, 'critical': 30}
        }
        self.history = []
        self.anomalies = []
    
    def collect_metrics(self, metrics_data: Dict) -> Dict:
        """
        采集实时指标
        
        参数:
            metrics_data: {
                'timestamp': '2024-01-15 12:00:00',
                'revenue_per_hour': 850,
                'orders_per_hour': 18,
                'avg_order_value': 94,
                'cancel_rate': 0.02,
                'wait_time': 8,
                'table_occupancy': 0.85,
                'kitchen_load': 0.72
            }
        """
        timestamp = metrics_data.get('timestamp', datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        
        # 存储历史数据
        self.history.append({
            'timestamp': timestamp,
            **metrics_data
        })
        
        # 保留最近60个数据点（假设每分钟采集一次）
        if len(self.history) > 60:
            self.history = self.history[-60:]
        
        # 检测异常
        anomalies = self._detect_anomalies(metrics_data)
        
        # 生成状态
        status = self._evaluate_status(metrics_data)
        
        return {
            'timestamp': timestamp,
            'metrics': metrics_data,
            'status': status,
            'anomalies': anomalies
        }
    
    def _detect_anomalies(self, metrics: Dict) -> List[Dict]:
        """检测异常"""
        anomalies = []
        
        for metric_name, thresholds in self.thresholds.items():
            if metric_name not in metrics:
                continue
            
            value = metrics[metric_name]
            
            # 判断是否异常
            if metric_name == 'cancel_rate':
                # 越低越好
                if value >= thresholds['critical']:
                    anomalies.append({
                        'metric': metric_name,
                        'value': value,
                        'level': 'critical',
                        'message': f"{metric_name} 达到临界值 {value} (阈值 {thresholds['critical']})"
                    })
                elif value >= thresholds['warning']:
                    anomalies.append({
                        'metric': metric_name,
                        'value': value,
                        'level': 'warning',
                        'message': f"{metric_name} 超出预警线 {value} (阈值 {thresholds['warning']})"
                    })
            else:
                # 越高越好（如收入、订单量）
                if value <= thresholds['critical']:
                    anomalies.append({
                        'metric': metric_name,
                        'value': value,
                        'level': 'critical',
                        'message': f"{metric_name} 低于临界值 {value} (阈值 {thresholds['critical']})"
                    })
                elif value <= thresholds['warning']:
                    anomalies.append({
                        'metric': metric_name,
                        'value': value,
                        'level': 'warning',
                        'message': f"{metric_name} 低于预警线 {value} (阈值 {thresholds['warning']})"
                    })
        
        if anomalies:
            self.anomalies.extend(anomalies)
        
        return anomalies
    
    def _evaluate_status(self, metrics: Dict) -> str:
        """评估整体状态"""
        critical_count = sum(1 for a in self._detect_anomalies(metrics) if a['level'] == 'critical')
        warning_count = sum(1 for a in self._detect_anomalies(metrics) if a['level'] == 'warning')
        
        if critical_count > 0:
            return 'critical'
        elif warning_count > 0:
            return 'warning'
        else:
            return 'normal'
    
    def generate_trend_analysis(self) -> Dict:
        """生成趋势分析"""
        if len(self.history) < 2:
            return {'message': '数据不足，无法分析趋势'}
        
        recent = self.history[-5:]  # 最近5个数据点
        
        trends = {}
        for metric in ['revenue_per_hour', 'orders_per_hour', 'avg_order_value']:
            if metric in recent[0]:
                values = [r[metric] for r in recent if metric in r]
                if len(values) >= 2:
                    # 计算趋势
                    trend = (values[-1] - values[0]) / values[0] * 100 if values[0] > 0 else 0
                    trends[metric] = {
                        'current': values[-1],
                        'previous': values[0],
                        'change_percent': round(trend, 1),
                        'direction': 'up' if trend > 0 else 'down' if trend < 0 else 'stable'
                    }
        
        return {
            'timestamp': datetime.now().isoformat(),
            'period': 'last_5_minutes',
            'trends': trends
        }
    
    def generate_alert_report(self) -> Dict:
        """生成告警报告"""
        # 按严重程度分组
        critical_alerts = [a for a in self.anomalies if a['level'] == 'critical']
        warning_alerts = [a for a in self.anomalies if a['level'] == 'warning']
        
        return {
            'timestamp': datetime.now().isoformat(),
            'summary': {
                'total_alerts': len(self.anomalies),
                'critical_count': len(critical_alerts),
                'warning_count': len(warning_alerts)
            },
            'critical_alerts': critical_alerts[-10:],  # 最近10个
            'warning_alerts': warning_alerts[-10:],
            'recommendations': self._generate_recommendations(critical_alerts, warning_alerts)
        }
    
    def _generate_recommendations(self, critical: List, warning: List) -> List[str]:
        """生成处理建议"""
        recommendations = []
        
        for alert in critical:
            if alert['metric'] == 'revenue_per_hour':
                recommendations.append("收入偏低：建议加大推广力度、推出限时优惠")
            elif alert['metric'] == 'orders_per_hour':
                recommendations.append("订单量不足：检查外卖平台曝光、优化门店排名")
            elif alert['metric'] == 'cancel_rate':
                recommendations.append("退单率过高：检查出餐质量、优化订单处理流程")
        
        return recommendations[:5]


class IndustryBenchmark:
    """行业对标引擎"""
    
    def __init__(self):
        self.benchmarks = {
            'revenue_per_hour': {
                'excellent': 1000,
                'good': 700,
                'average': 500,
                'poor': 300
            },
            'avg_order_value': {
                'excellent': 100,
                'good': 80,
                'average': 60,
                'poor': 40
            },
            'table_turnover': {
                'excellent': 4.0,
                'good': 3.0,
                'average': 2.5,
                'poor': 2.0
            },
            'gross_margin': {
                'excellent': 0.70,
                'good': 0.65,
                'average': 0.60,
                'poor': 0.55
            }
        }
    
    def compare_to_benchmark(self, metrics: Dict) -> Dict:
        """对比行业基准"""
        comparison = {}
        
        for metric_name, value in metrics.items():
            if metric_name not in self.benchmarks:
                continue
            
            benchmark = self.benchmarks[metric_name]
            
            # 判断等级
            if value >= benchmark['excellent']:
                level = 'excellent'
            elif value >= benchmark['good']:
                level = 'good'
            elif value >= benchmark['average']:
                level = 'average'
            else:
                level = 'poor'
            
            # 计算差距
            gap_to_excellent = round((value - benchmark['excellent']) / benchmark['excellent'] * 100, 1)
            
            comparison[metric_name] = {
                'current_value': value,
                'excellent': benchmark['excellent'],
                'good': benchmark['good'],
                'average': benchmark['average'],
                'current_level': level,
                'gap_to_excellent_percent': gap_to_excellent,
                'percentile': self._estimate_percentile(value, benchmark)
            }
        
        return comparison
    
    def _estimate_percentile(self, value: float, benchmark: Dict) -> int:
        """估算百分位排名"""
        if value >= benchmark['excellent']:
            return 90
        elif value >= benchmark['good']:
            return 75
        elif value >= benchmark['average']:
            return 50
        else:
            return 25
    
    def generate_benchmark_report(self, metrics: Dict) -> Dict:
        """生成对标报告"""
        comparison = self.compare_to_benchmark(metrics)
        
        # 计算综合得分
        scores = []
        for metric_name, data in comparison.items():
            level_scores = {'excellent': 100, 'good': 80, 'average': 60, 'poor': 40}
            scores.append(level_scores[data['current_level']])
        
        overall_score = np.mean(scores) if scores else 0
        
        return {
            'timestamp': datetime.now().isoformat(),
            'overall_score': round(overall_score, 1),
            'ranking': self._get_ranking(overall_score),
            'metrics_comparison': comparison,
            'improvement_priorities': self._prioritize_improvements(comparison)
        }
    
    def _get_ranking(self, score: float) -> str:
        """获取排名等级"""
        if score >= 90:
            return '行业前10%'
        elif score >= 80:
            return '行业前25%'
        elif score >= 60:
            return '行业中游'
        else:
            return '行业后50%'
    
    def _prioritize_improvements(self, comparison: Dict) -> List[Dict]:
        """优先改进项"""
        improvements = []
        
        for metric_name, data in comparison.items():
            if data['current_level'] in ['poor', 'average']:
                improvements.append({
                    'metric': metric_name,
                    'current': data['current_value'],
                    'target': data['good'],
                    'gap': data['gap_to_excellent_percent'],
                    'priority': 'high' if data['current_level'] == 'poor' else 'medium'
                })
        
        return sorted(improvements, key=lambda x: x['gap'])


def main():
    parser = argparse.ArgumentParser(description='实时监控工具')
    parser.add_argument('--interval', type=int, default=60, help='监控间隔（秒）')
    parser.add_argument('--output', type=str, default='monitoring_report.json', help='输出文件')
    
    args = parser.parse_args()
    
    monitor = RealtimeMonitor()
    benchmark = IndustryBenchmark()
    
    # 模拟采集实时数据
    sample_metrics = {
        'revenue_per_hour': 850,
        'orders_per_hour': 18,
        'avg_order_value': 94,
        'cancel_rate': 0.02,
        'wait_time': 8,
        'table_occupancy': 0.85,
        'kitchen_load': 0.72
    }
    
    try:
        # 采集指标
        monitoring_result = monitor.collect_metrics(sample_metrics)
        
        # 趋势分析
        trend_analysis = monitor.generate_trend_analysis()
        
        # 行业对标
        benchmark_report = benchmark.generate_benchmark_report(sample_metrics)
        
        # 告警报告
        alert_report = monitor.generate_alert_report()
        
        result = {
            'timestamp': datetime.now().isoformat(),
            'monitoring': monitoring_result,
            'trend_analysis': trend_analysis,
            'industry_benchmark': benchmark_report,
            'alerts': alert_report
        }
        
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        
        print(f"[SUCCESS] 实时监控报告已生成: {args.output}")
        
        print(f"\n[STATUS] 系统状态: {monitoring_result['status'].upper()}")
        print(f"\n[BENCHMARK] 行业排名: {benchmark_report['ranking']}")
        print(f"  - 综合得分: {benchmark_report['overall_score']}/100")
        
        if monitoring_result['anomalies']:
            print(f"\n[ALERTS] 异常告警 ({len(monitoring_result['anomalies'])} 个):")
            for alert in monitoring_result['anomalies'][:3]:
                print(f"  - [{alert['level'].upper()}] {alert['message']}")
        
        return 0
        
    except Exception as e:
        print(f"[ERROR] 监控失败: {str(e)}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
