#!/usr/bin/env python3
"""
餐饮门店KPI计算引擎
支持多维度指标计算、同比环比分析、趋势识别

使用方式:
    python kpi_calculator.py --date 2024-01-15 --output report.json
    python kpi_calculator.py --start 2024-01-01 --end 2024-01-07 --output weekly.json
"""

import argparse
import json
import sys
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import pandas as pd
import numpy as np


class KPIcalculator:
    """餐饮门店KPI计算引擎"""
    
    def __init__(self):
        self.required_fields = [
            'date', 'revenue', 'order_count', 'guest_count', 
            'table_count', 'food_cost', 'labor_cost', 'other_cost'
        ]
    
    def validate_data(self, data: Dict) -> Tuple[bool, str]:
        """验证数据完整性"""
        missing_fields = [f for f in self.required_fields if f not in data]
        if missing_fields:
            return False, f"缺少必要字段: {', '.join(missing_fields)}"
        
        if data.get('revenue', 0) <= 0:
            return False, "营业额必须大于0"
        
        return True, "数据验证通过"
    
    def calculate_turnover_rate(self, order_count: int, table_count: int, 
                                 business_hours: float = 12.0) -> float:
        """
        计算翻台率
        公式: 翻台率 = 用餐桌数 / (餐桌总数 × 营业时长)
        
        参数:
            order_count: 用餐桌数/订单数
            table_count: 餐桌总数
            business_hours: 营业时长(小时)
        """
        if table_count <= 0 or business_hours <= 0:
            return 0.0
        return round(order_count / (table_count * business_hours), 2)
    
    def calculate_avg_ticket(self, revenue: float, guest_count: int) -> float:
        """
        计算客单价
        公式: 客单价 = 营业额 / 用餐人数
        """
        if guest_count <= 0:
            return 0.0
        return round(revenue / guest_count, 2)
    
    def calculate_gross_margin(self, revenue: float, food_cost: float) -> float:
        """
        计算毛利率
        公式: 毛利率 = (营业额 - 食材成本) / 营业额
        """
        if revenue <= 0:
            return 0.0
        return round((revenue - food_cost) / revenue * 100, 2)
    
    def calculate_net_profit_margin(self, revenue: float, total_cost: float) -> float:
        """
        计算净利率
        公式: 净利率 = (营业额 - 总成本) / 营业额
        """
        if revenue <= 0:
            return 0.0
        return round((revenue - total_cost) / revenue * 100, 2)
    
    def calculate_cost_structure(self, revenue: float, food_cost: float, 
                                  labor_cost: float, other_cost: float) -> Dict:
        """
        计算成本结构
        返回各项成本占比
        """
        if revenue <= 0:
            return {
                'food_cost_ratio': 0,
                'labor_cost_ratio': 0,
                'other_cost_ratio': 0,
                'total_cost_ratio': 0
            }
        
        return {
            'food_cost_ratio': round(food_cost / revenue * 100, 2),
            'labor_cost_ratio': round(labor_cost / revenue * 100, 2),
            'other_cost_ratio': round(other_cost / revenue * 100, 2),
            'total_cost_ratio': round((food_cost + labor_cost + other_cost) / revenue * 100, 2)
        }
    
    def calculate_per_table_revenue(self, revenue: float, order_count: int) -> float:
        """
        计算桌均消费
        公式: 桌均消费 = 营业额 / 用餐桌数
        """
        if order_count <= 0:
            return 0.0
        return round(revenue / order_count, 2)
    
    def calculate_per_guest_dishes(self, dish_count: int, guest_count: int) -> float:
        """
        计算人均菜品数
        """
        if guest_count <= 0:
            return 0.0
        return round(dish_count / guest_count, 2)
    
    def calculate_conversion_rate(self, impression: int, order_count: int) -> float:
        """
        计算转化率(美团平台)
        公式: 转化率 = 订单数 / 曝光量
        """
        if impression <= 0:
            return 0.0
        return round(order_count / impression * 100, 2)
    
    def calculate_repeat_rate(self, repeat_guests: int, total_guests: int) -> float:
        """
        计算复购率
        公式: 复购率 = 复购顾客数 / 总顾客数
        """
        if total_guests <= 0:
            return 0.0
        return round(repeat_guests / total_guests * 100, 2)
    
    def calculate_growth_rate(self, current: float, previous: float) -> float:
        """
        计算增长率
        公式: 增长率 = (当前值 - 上期值) / 上期值
        """
        if previous <= 0:
            return 0.0
        return round((current - previous) / previous * 100, 2)
    
    def generate_daily_report(self, data: Dict) -> Dict:
        """
        生成日报
        """
        # 验证数据
        is_valid, message = self.validate_data(data)
        if not is_valid:
            raise ValueError(message)
        
        # 计算核心KPI
        total_cost = data['food_cost'] + data['labor_cost'] + data['other_cost']
        
        report = {
            'date': data['date'],
            'timestamp': datetime.now().isoformat(),
            'revenue': {
                'total': data['revenue'],
                'food': data.get('food_revenue', data['revenue'] * 0.7),
                'beverage': data.get('beverage_revenue', data['revenue'] * 0.3)
            },
            'traffic': {
                'order_count': data['order_count'],
                'guest_count': data['guest_count'],
                'table_count': data.get('table_count', 20),
                'avg_guest_per_table': round(data['guest_count'] / max(data['order_count'], 1), 2)
            },
            'efficiency': {
                'turnover_rate': self.calculate_turnover_rate(
                    data['order_count'], 
                    data.get('table_count', 20),
                    data.get('business_hours', 12.0)
                ),
                'avg_ticket': self.calculate_avg_ticket(data['revenue'], data['guest_count']),
                'per_table_revenue': self.calculate_per_table_revenue(data['revenue'], data['order_count'])
            },
            'profitability': {
                'gross_margin': self.calculate_gross_margin(data['revenue'], data['food_cost']),
                'net_margin': self.calculate_net_profit_margin(data['revenue'], total_cost),
                'gross_profit': round(data['revenue'] - data['food_cost'], 2),
                'net_profit': round(data['revenue'] - total_cost, 2)
            },
            'cost_structure': self.calculate_cost_structure(
                data['revenue'], 
                data['food_cost'], 
                data['labor_cost'], 
                data['other_cost']
            ),
            'platform': {
                'impression': data.get('impression', 0),
                'click': data.get('click', 0),
                'conversion_rate': self.calculate_conversion_rate(
                    data.get('impression', 0), 
                    data['order_count']
                ) if data.get('impression', 0) > 0 else 0,
                'review_count': data.get('review_count', 0),
                'avg_rating': data.get('avg_rating', 0)
            }
        }
        
        return report
    
    def generate_comparison_report(self, current: Dict, previous: Dict) -> Dict:
        """
        生成对比报告(同比/环比)
        """
        current_report = self.generate_daily_report(current)
        previous_report = self.generate_daily_report(previous)
        
        comparison = {
            'current_period': current['date'],
            'previous_period': previous['date'],
            'revenue_growth': self.calculate_growth_rate(
                current['revenue'], 
                previous['revenue']
            ),
            'order_growth': self.calculate_growth_rate(
                current['order_count'], 
                previous['order_count']
            ),
            'guest_growth': self.calculate_growth_rate(
                current['guest_count'], 
                previous['guest_count']
            ),
            'avg_ticket_change': round(
                current_report['efficiency']['avg_ticket'] - 
                previous_report['efficiency']['avg_ticket'], 
                2
            ),
            'margin_change': round(
                current_report['profitability']['gross_margin'] - 
                previous_report['profitability']['gross_margin'], 
                2
            ),
            'turnover_change': round(
                current_report['efficiency']['turnover_rate'] - 
                previous_report['efficiency']['turnover_rate'], 
                2
            )
        }
        
        return {
            'current': current_report,
            'previous': previous_report,
            'comparison': comparison
        }


def main():
    parser = argparse.ArgumentParser(description='餐饮门店KPI计算工具')
    parser.add_argument('--date', type=str, help='分析日期 (YYYY-MM-DD)')
    parser.add_argument('--start', type=str, help='开始日期 (周报模式)')
    parser.add_argument('--end', type=str, help='结束日期 (周报模式)')
    parser.add_argument('--input', type=str, help='输入数据文件 (JSON)')
    parser.add_argument('--output', type=str, default='report.json', help='输出文件名')
    parser.add_argument('--compare', type=str, help='对比数据文件 (用于同比/环比)')
    
    args = parser.parse_args()
    
    calculator = KPIcalculator()
    
    # 示例数据(实际使用时从文件读取或API获取)
    sample_data = {
        'date': args.date or datetime.now().strftime('%Y-%m-%d'),
        'revenue': 15000,
        'order_count': 85,
        'guest_count': 210,
        'table_count': 25,
        'food_cost': 4500,
        'labor_cost': 2500,
        'other_cost': 1500,
        'business_hours': 12.0,
        'impression': 5000,
        'click': 450,
        'review_count': 12,
        'avg_rating': 4.8
    }
    
    try:
        # 生成报告
        if args.compare:
            # 对比模式
            previous_data = sample_data.copy()
            previous_data['revenue'] = 13500
            previous_data['date'] = args.compare
            
            report = calculator.generate_comparison_report(sample_data, previous_data)
        else:
            # 单日报告
            report = calculator.generate_daily_report(sample_data)
        
        # 输出结果
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        
        print(f"[SUCCESS] 报告已生成: {args.output}")
        print(f"[INFO] 核心指标:")
        print(f"  - 营业额: ¥{report['revenue']['total']}")
        print(f"  - 翻台率: {report['efficiency']['turnover_rate']}")
        print(f"  - 客单价: ¥{report['efficiency']['avg_ticket']}")
        print(f"  - 毛利率: {report['profitability']['gross_margin']}%")
        
        return 0
        
    except Exception as e:
        print(f"[ERROR] 报告生成失败: {str(e)}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
