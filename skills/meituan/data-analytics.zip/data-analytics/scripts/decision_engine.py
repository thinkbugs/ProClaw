#!/usr/bin/env python3
"""
智能决策推荐引擎
基于数据自动推荐优化方案

使用方式:
    python decision_engine.py --output decision_report.json
"""

import argparse
import json
import sys
from datetime import datetime
from typing import Dict, List
import numpy as np


class DecisionEngine:
    """智能决策引擎"""
    
    def __init__(self):
        # 决策规则库
        self.decision_rules = {
            # 收入类决策
            'low_revenue': {
                'condition': 'revenue_growth < 0 or revenue_per_day < benchmark',
                'diagnosis': [
                    '客流不足',
                    '客单价偏低',
                    '外卖订单减少',
                    '复购率下降'
                ],
                'solutions': [
                    {
                        'action': '推出限时优惠活动',
                        'expected_impact': '提升15-25%营收',
                        'cost': '中等',
                        'timeline': '即时生效'
                    },
                    {
                        'action': '优化外卖平台排名',
                        'expected_impact': '提升10-20%外卖订单',
                        'cost': '低',
                        'timeline': '1-2周'
                    },
                    {
                        'action': '会员专属优惠',
                        'expected_impact': '提升复购率10-15%',
                        'cost': '低',
                        'timeline': '即时生效'
                    }
                ]
            },
            
            # 成本类决策
            'high_cost': {
                'condition': 'cost_rate > 0.70 or gross_margin < 0.35',
                'diagnosis': [
                    '食材成本过高',
                    '人力效率低',
                    '浪费严重',
                    '定价不合理'
                ],
                'solutions': [
                    {
                        'action': '优化采购渠道，集中采购',
                        'expected_impact': '降低食材成本5-10%',
                        'cost': '低',
                        'timeline': '2-4周'
                    },
                    {
                        'action': '优化排班，提升人效',
                        'expected_impact': '降低人力成本8-12%',
                        'cost': '低',
                        'timeline': '1-2周'
                    },
                    {
                        'action': '建立标准配方，减少浪费',
                        'expected_impact': '降低食材浪费10-15%',
                        'cost': '低',
                        'timeline': '2-3周'
                    }
                ]
            },
            
            # 效率类决策
            'low_efficiency': {
                'condition': 'table_turnover < benchmark or wait_time > 15',
                'diagnosis': [
                    '服务流程不顺畅',
                    '出餐速度慢',
                    '座位安排不合理',
                    '高峰期人力不足'
                ],
                'solutions': [
                    {
                        'action': '优化服务流程SOP',
                        'expected_impact': '提升翻台率20-30%',
                        'cost': '低',
                        'timeline': '1-2周'
                    },
                    {
                        'action': '后厨动线优化',
                        'expected_impact': '提升出餐速度30%',
                        'cost': '中等',
                        'timeline': '2-4周'
                    },
                    {
                        'action': '引入智能化点餐系统',
                        'expected_impact': '提升点餐效率50%',
                        'cost': '中高',
                        'timeline': '1-2月'
                    }
                ]
            },
            
            # 质量类决策
            'quality_issue': {
                'condition': 'customer_satisfaction < 4.0 or complaint_rate > 0.02',
                'diagnosis': [
                    '菜品口味不稳定',
                    '服务态度问题',
                    '上菜速度慢',
                    '环境卫生问题'
                ],
                'solutions': [
                    {
                        'action': '标准化菜品SOP，定期培训',
                        'expected_impact': '提升菜品满意度0.3-0.5分',
                        'cost': '低',
                        'timeline': '2-4周'
                    },
                    {
                        'action': '服务人员培训与激励',
                        'expected_impact': '提升服务满意度0.2-0.4分',
                        'cost': '低',
                        'timeline': '1-2周'
                    },
                    {
                        'action': '建立顾客反馈闭环机制',
                        'expected_impact': '降低投诉率50%',
                        'cost': '低',
                        'timeline': '即时生效'
                    }
                ]
            }
        }
        
        # 决策模型
        self.decision_models = {
            'pricing': self._pricing_model,
            'promotion': self._promotion_model,
            'staffing': self._staffing_model,
            'inventory': self._inventory_model
        }
    
    def analyze_and_recommend(self, metrics: Dict) -> Dict:
        """分析并推荐决策"""
        recommendations = []
        
        # 检查各维度
        if metrics.get('revenue_growth', 0) < 0 or metrics.get('revenue_per_day', 0) < metrics.get('benchmark_revenue', 5000):
            recommendations.append(self._generate_recommendation('low_revenue', metrics))
        
        if metrics.get('cost_rate', 0) > 0.70 or metrics.get('gross_margin', 0) < 0.35:
            recommendations.append(self._generate_recommendation('high_cost', metrics))
        
        if metrics.get('table_turnover', 0) < metrics.get('benchmark_turnover', 2.5):
            recommendations.append(self._generate_recommendation('low_efficiency', metrics))
        
        if metrics.get('customer_satisfaction', 5) < 4.0 or metrics.get('complaint_rate', 0) > 0.02:
            recommendations.append(self._generate_recommendation('quality_issue', metrics))
        
        # 计算优先级
        for rec in recommendations:
            rec['priority_score'] = self._calculate_priority(rec, metrics)
        
        # 按优先级排序
        recommendations.sort(key=lambda x: x['priority_score'], reverse=True)
        
        return {
            'timestamp': datetime.now().isoformat(),
            'total_recommendations': len(recommendations),
            'recommendations': recommendations,
            'top_priority': recommendations[0] if recommendations else None
        }
    
    def _generate_recommendation(self, issue_type: str, metrics: Dict) -> Dict:
        """生成推荐"""
        rule = self.decision_rules[issue_type]
        
        return {
            'issue_type': issue_type,
            'diagnosis': rule['diagnosis'],
            'solutions': rule['solutions'],
            'current_metrics': {
                k: v for k, v in metrics.items()
                if k in ['revenue_growth', 'cost_rate', 'gross_margin', 'table_turnover', 'customer_satisfaction']
            }
        }
    
    def _calculate_priority(self, recommendation: Dict, metrics: Dict) -> float:
        """计算优先级得分"""
        score = 0
        
        # 根据问题类型加权
        weights = {
            'low_revenue': 30,
            'high_cost': 25,
            'low_efficiency': 20,
            'quality_issue': 25
        }
        
        score += weights.get(recommendation['issue_type'], 10)
        
        # 根据指标偏离程度加权
        if recommendation['issue_type'] == 'low_revenue':
            score += abs(metrics.get('revenue_growth', 0)) * 10
        elif recommendation['issue_type'] == 'high_cost':
            score += (metrics.get('cost_rate', 0) - 0.65) * 100
        
        return score
    
    def _pricing_model(self, data: Dict) -> Dict:
        """定价决策模型"""
        # 基于需求弹性定价
        current_price = data.get('current_price', 0)
        demand_elasticity = data.get('demand_elasticity', -1.5)
        
        if demand_elasticity < -1:  # 弹性需求
            recommended_price = current_price * 0.95  # 降价5%
            expected_demand_increase = abs(demand_elasticity) * 5
        else:  # 非弹性需求
            recommended_price = current_price * 1.05  # 涨价5%
            expected_demand_increase = 0
        
        return {
            'model': 'pricing',
            'current_price': current_price,
            'recommended_price': round(recommended_price, 2),
            'expected_demand_change': f"{expected_demand_increase}%"
        }
    
    def _promotion_model(self, data: Dict) -> Dict:
        """促销决策模型"""
        # 基于历史数据推荐促销方案
        current_revenue = data.get('current_revenue', 0)
        target_revenue = data.get('target_revenue', current_revenue * 1.2)
        
        gap = target_revenue - current_revenue
        
        # 推荐促销类型
        if gap / current_revenue < 0.1:
            promo_type = '小优惠（满减10-20元）'
            expected_roi = 3.5
        elif gap / current_revenue < 0.2:
            promo_type = '中等优惠（满减30-50元）'
            expected_roi = 2.8
        else:
            promo_type = '大额优惠（满减50-100元）'
            expected_roi = 2.2
        
        return {
            'model': 'promotion',
            'revenue_gap': round(gap, 2),
            'recommended_promotion': promo_type,
            'expected_roi': expected_roi
        }
    
    def _staffing_model(self, data: Dict) -> Dict:
        """人力决策模型"""
        # 基于客流预测人力需求
        peak_hours = data.get('peak_hours', [11, 12, 13, 18, 19, 20])
        current_staff = data.get('current_staff', 5)
        avg_customers_per_staff = data.get('avg_customers_per_staff', 15)
        
        expected_peak_customers = data.get('expected_peak_customers', 100)
        
        recommended_staff = max(current_staff, int(expected_peak_customers / avg_customers_per_staff))
        
        return {
            'model': 'staffing',
            'current_staff': current_staff,
            'recommended_staff': recommended_staff,
            'peak_hours': peak_hours,
            'staff_adjustment': f"+{recommended_staff - current_staff}" if recommended_staff > current_staff else "维持"
        }
    
    def _inventory_model(self, data: Dict) -> Dict:
        """库存决策模型"""
        # 基于销量预测库存需求
        daily_sales = data.get('daily_sales', {})
        lead_time = data.get('lead_time', 2)
        safety_factor = data.get('safety_factor', 1.5)
        
        reorder_suggestions = {}
        
        for item, sales in daily_sales.items():
            reorder_point = sales * lead_time * safety_factor
            reorder_suggestions[item] = {
                'daily_sales': sales,
                'reorder_point': round(reorder_point, 1),
                'suggested_order': round(sales * 7, 1)  # 一周用量
            }
        
        return {
            'model': 'inventory',
            'reorder_suggestions': reorder_suggestions
        }
    
    def run_decision_model(self, model_name: str, data: Dict) -> Dict:
        """运行决策模型"""
        if model_name not in self.decision_models:
            return {'error': f'未找到决策模型: {model_name}'}
        
        return self.decision_models[model_name](data)
    
    def generate_action_plan(self, recommendations: List[Dict]) -> List[Dict]:
        """生成行动计划"""
        action_plan = []
        
        for i, rec in enumerate(recommendations[:5], 1):  # 取前5个推荐
            for j, solution in enumerate(rec.get('solutions', [])[:2], 1):  # 每个推荐取前2个方案
                action_plan.append({
                    'id': f"A{i}.{j}",
                    'issue': rec['issue_type'],
                    'action': solution['action'],
                    'expected_impact': solution['expected_impact'],
                    'cost': solution['cost'],
                    'timeline': solution['timeline'],
                    'priority': '高' if i == 1 else '中' if i <= 3 else '低',
                    'deadline': self._calculate_deadline(solution['timeline']),
                    'owner': '待指派',
                    'status': 'pending'
                })
        
        return action_plan
    
    def _calculate_deadline(self, timeline: str) -> str:
        """计算截止日期"""
        from datetime import timedelta
        
        days_map = {
            '即时生效': 1,
            '1-2周': 14,
            '2-3周': 21,
            '2-4周': 28,
            '1-2月': 60
        }
        
        days = days_map.get(timeline, 14)
        
        return (datetime.now() + timedelta(days=days)).strftime('%Y-%m-%d')


def main():
    parser = argparse.ArgumentParser(description='智能决策引擎')
    parser.add_argument('--output', type=str, default='decision_report.json', help='输出文件')
    
    args = parser.parse_args()
    
    engine = DecisionEngine()
    
    # 示例门店数据
    sample_metrics = {
        'revenue_growth': -5,  # 负增长
        'revenue_per_day': 4500,
        'benchmark_revenue': 6000,
        'cost_rate': 0.72,
        'gross_margin': 0.28,
        'table_turnover': 2.0,
        'benchmark_turnover': 2.5,
        'customer_satisfaction': 4.2,
        'complaint_rate': 0.01
    }
    
    try:
        # 分析并推荐
        recommendations = engine.analyze_and_recommend(sample_metrics)
        
        # 生成行动计划
        action_plan = engine.generate_action_plan(recommendations['recommendations'])
        
        # 运行决策模型示例
        pricing_model = engine.run_decision_model('pricing', {
            'current_price': 38,
            'demand_elasticity': -1.2
        })
        
        promotion_model = engine.run_decision_model('promotion', {
            'current_revenue': 4500,
            'target_revenue': 6000
        })
        
        result = {
            'timestamp': datetime.now().isoformat(),
            'recommendations': recommendations,
            'action_plan': action_plan,
            'decision_models': {
                'pricing': pricing_model,
                'promotion': promotion_model
            }
        }
        
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        
        print(f"[SUCCESS] 决策报告已生成: {args.output}")
        
        print(f"\n[RECOMMENDATIONS] 智能推荐 ({recommendations['total_recommendations']}个):")
        for rec in recommendations['recommendations'][:3]:
            print(f"  - [{rec['issue_type']}] 诊断: {', '.join(rec['diagnosis'][:2])}")
        
        print(f"\n[TOP PRIORITY] 最高优先级:")
        if recommendations['top_priority']:
            top = recommendations['top_priority']
            print(f"  - 问题: {top['issue_type']}")
            print(f"  - 首选方案: {top['solutions'][0]['action']}")
            print(f"  - 预期效果: {top['solutions'][0]['expected_impact']}")
        
        print(f"\n[ACTION PLAN] 行动计划:")
        for action in action_plan[:3]:
            print(f"  - [{action['priority']}] {action['action']} (截止: {action['deadline']})")
        
        return 0
        
    except Exception as e:
        print(f"[ERROR] 分析失败: {str(e)}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
