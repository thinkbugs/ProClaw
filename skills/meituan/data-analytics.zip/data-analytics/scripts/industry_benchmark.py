#!/usr/bin/env python3
"""
行业基准数据库引擎
餐饮行业各维度基准数据、对标分析

使用方式:
    python industry_benchmark.py --category fast_food --output benchmark_report.json
"""

import argparse
import json
import sys
from datetime import datetime
from typing import Dict, List
import numpy as np


class IndustryBenchmark:
    """行业基准数据库"""
    
    def __init__(self):
        # 餐饮行业基准数据（综合行业报告和标杆企业数据）
        self.benchmarks = {
            # 快餐业态
            'fast_food': {
                'name': '快餐',
                'metrics': {
                    'gross_margin': {
                        'excellent': 0.70, 'good': 0.65, 'average': 0.60, 'poor': 0.55,
                        'description': '毛利率'
                    },
                    'food_cost_rate': {
                        'excellent': 0.28, 'good': 0.32, 'average': 0.35, 'poor': 0.40,
                        'description': '食材成本率'
                    },
                    'labor_cost_rate': {
                        'excellent': 0.18, 'good': 0.22, 'average': 0.25, 'poor': 0.30,
                        'description': '人力成本率'
                    },
                    'table_turnover': {
                        'excellent': 4.5, 'good': 3.5, 'average': 2.5, 'poor': 2.0,
                        'description': '翻台率（次/天）'
                    },
                    'avg_order_value': {
                        'excellent': 35, 'good': 28, 'average': 22, 'poor': 18,
                        'description': '客单价（元）'
                    },
                    'customer_satisfaction': {
                        'excellent': 4.8, 'good': 4.5, 'average': 4.2, 'poor': 3.8,
                        'description': '顾客满意度（1-5分）'
                    },
                    'daily_revenue_per_seat': {
                        'excellent': 150, 'good': 120, 'average': 90, 'poor': 60,
                        'description': '座位日均营收（元）'
                    }
                }
            },
            # 正餐业态
            'casual_dining': {
                'name': '正餐',
                'metrics': {
                    'gross_margin': {
                        'excellent': 0.68, 'good': 0.63, 'average': 0.58, 'poor': 0.52,
                        'description': '毛利率'
                    },
                    'food_cost_rate': {
                        'excellent': 0.30, 'good': 0.34, 'average': 0.38, 'poor': 0.42,
                        'description': '食材成本率'
                    },
                    'labor_cost_rate': {
                        'excellent': 0.20, 'good': 0.24, 'average': 0.28, 'poor': 0.32,
                        'description': '人力成本率'
                    },
                    'table_turnover': {
                        'excellent': 2.5, 'good': 2.0, 'average': 1.5, 'poor': 1.2,
                        'description': '翻台率（次/天）'
                    },
                    'avg_order_value': {
                        'excellent': 120, 'good': 90, 'average': 70, 'poor': 50,
                        'description': '客单价（元）'
                    },
                    'customer_satisfaction': {
                        'excellent': 4.7, 'good': 4.4, 'average': 4.1, 'poor': 3.7,
                        'description': '顾客满意度（1-5分）'
                    },
                    'daily_revenue_per_seat': {
                        'excellent': 200, 'good': 160, 'average': 120, 'poor': 80,
                        'description': '座位日均营收（元）'
                    }
                }
            },
            # 外卖专营
            'delivery_only': {
                'name': '外卖专营',
                'metrics': {
                    'gross_margin': {
                        'excellent': 0.45, 'good': 0.40, 'average': 0.35, 'poor': 0.30,
                        'description': '毛利率（扣除平台佣金后）'
                    },
                    'food_cost_rate': {
                        'excellent': 0.32, 'good': 0.36, 'average': 0.40, 'poor': 0.45,
                        'description': '食材成本率'
                    },
                    'labor_cost_rate': {
                        'excellent': 0.15, 'good': 0.18, 'average': 0.22, 'poor': 0.26,
                        'description': '人力成本率'
                    },
                    'orders_per_day': {
                        'excellent': 300, 'good': 200, 'average': 150, 'poor': 100,
                        'description': '日均订单量'
                    },
                    'avg_order_value': {
                        'excellent': 40, 'good': 32, 'average': 26, 'poor': 20,
                        'description': '客单价（元）'
                    },
                    'delivery_time': {
                        'excellent': 20, 'good': 25, 'average': 30, 'poor': 40,
                        'description': '平均配送时长（分钟）'
                    },
                    'order_accuracy': {
                        'excellent': 0.99, 'good': 0.97, 'average': 0.95, 'poor': 0.92,
                        'description': '订单准确率'
                    }
                }
            }
        }
        
        # 行业标杆案例
        self.benchmark_cases = {
            'mcdonalds': {
                'name': '麦当劳',
                'category': 'fast_food',
                'key_metrics': {
                    'gross_margin': 0.72,
                    'table_turnover': 5.2,
                    'customer_satisfaction': 4.7,
                    'daily_revenue_per_seat': 180
                },
                'best_practices': [
                    '标准化SOP，确保全球品质一致',
                    '高效点餐系统，减少等待时间',
                    '精准预测销量，优化库存管理',
                    '员工多技能培训，提升人效'
                ]
            },
            'haidilao': {
                'name': '海底捞',
                'category': 'casual_dining',
                'key_metrics': {
                    'gross_margin': 0.65,
                    'table_turnover': 3.8,
                    'customer_satisfaction': 4.9,
                    'daily_revenue_per_seat': 280
                },
                'best_practices': [
                    '极致服务体验，形成口碑传播',
                    '排队等候区增值服务',
                    '员工授权机制，快速响应需求',
                    '数据驱动运营，精细化管理'
                ]
            },
            'saliya': {
                'name': '萨莉亚',
                'category': 'casual_dining',
                'key_metrics': {
                    'gross_margin': 0.68,
                    'food_cost_rate': 0.30,
                    'avg_order_value': 35,
                    'table_turnover': 4.5
                },
                'best_practices': [
                    '极致成本控制，性价比之王',
                    '中央厨房+半成品，降低人力成本',
                    '精简SKU，提高采购议价能力',
                    '高效翻台，薄利多销'
                ]
            }
        }
    
    def get_benchmark(self, category: str) -> Dict:
        """获取行业基准"""
        if category not in self.benchmarks:
            return {'error': f'未找到业态 {category}'}
        
        return {
            'category': category,
            'name': self.benchmarks[category]['name'],
            'metrics': self.benchmarks[category]['metrics'],
            'timestamp': datetime.now().isoformat()
        }
    
    def compare_to_benchmark(self, category: str, store_metrics: Dict) -> Dict:
        """对比行业基准"""
        if category not in self.benchmarks:
            return {'error': f'未找到业态 {category}'}
        
        benchmark = self.benchmarks[category]['metrics']
        comparison = {}
        
        for metric_name, value in store_metrics.items():
            if metric_name not in benchmark:
                continue
            
            benchmark_data = benchmark[metric_name]
            
            # 判断等级
            if value >= benchmark_data['excellent']:
                level = 'excellent'
            elif value >= benchmark_data['good']:
                level = 'good'
            elif value >= benchmark_data['average']:
                level = 'average'
            else:
                level = 'poor'
            
            # 计算差距
            gap_to_excellent = round((value - benchmark_data['excellent']) / benchmark_data['excellent'] * 100, 1)
            gap_to_average = round((value - benchmark_data['average']) / benchmark_data['average'] * 100, 1)
            
            comparison[metric_name] = {
                'description': benchmark_data['description'],
                'current_value': value,
                'benchmark': {
                    'excellent': benchmark_data['excellent'],
                    'good': benchmark_data['good'],
                    'average': benchmark_data['average'],
                    'poor': benchmark_data['poor']
                },
                'level': level,
                'gap_to_excellent_percent': gap_to_excellent,
                'gap_to_average_percent': gap_to_average,
                'percentile': self._estimate_percentile(level)
            }
        
        # 计算综合得分
        scores = {
            'excellent': 100,
            'good': 80,
            'average': 60,
            'poor': 40
        }
        total_score = np.mean([scores[c['level']] for c in comparison.values()]) if comparison else 0
        
        return {
            'category': category,
            'category_name': self.benchmarks[category]['name'],
            'overall_score': round(total_score, 1),
            'ranking': self._get_ranking(total_score),
            'comparison': comparison,
            'timestamp': datetime.now().isoformat()
        }
    
    def _estimate_percentile(self, level: str) -> int:
        """估算百分位排名"""
        percentiles = {
            'excellent': 90,
            'good': 75,
            'average': 50,
            'poor': 25
        }
        return percentiles.get(level, 50)
    
    def _get_ranking(self, score: float) -> str:
        """获取排名等级"""
        if score >= 90:
            return '行业前10%'
        elif score >= 80:
            return '行业前25%'
        elif score >= 60:
            return '行业中游'
        else:
            return '行业后50%'
    
    def get_best_practices(self, category: str = None, metric: str = None) -> List[Dict]:
        """获取最佳实践"""
        practices = []
        
        for case_id, case in self.benchmark_cases.items():
            if category and case['category'] != category:
                continue
            
            practice = {
                'company': case['name'],
                'category': case['category'],
                'key_metrics': case['key_metrics'],
                'best_practices': case['best_practices']
            }
            
            practices.append(practice)
        
        return practices
    
    def generate_improvement_roadmap(self, category: str, current_metrics: Dict) -> Dict:
        """生成改进路线图"""
        comparison = self.compare_to_benchmark(category, current_metrics)
        
        if 'error' in comparison:
            return comparison
        
        # 识别改进优先级
        improvements = []
        
        for metric_name, data in comparison['comparison'].items():
            if data['level'] in ['poor', 'average']:
                improvements.append({
                    'metric': metric_name,
                    'description': data['description'],
                    'current': data['current_value'],
                    'target': data['benchmark']['good'],
                    'gap': data['gap_to_average_percent'],
                    'priority': 'high' if data['level'] == 'poor' else 'medium',
                    'actions': self._get_improvement_actions(metric_name)
                })
        
        # 按优先级排序
        improvements.sort(key=lambda x: (x['priority'], -abs(x['gap'])))
        
        return {
            'category': category,
            'current_score': comparison['overall_score'],
            'target_score': 80,
            'improvements': improvements,
            'timeline': '3-6个月',
            'expected_roi': '15-30%'
        }
    
    def _get_improvement_actions(self, metric: str) -> List[str]:
        """获取改进建议"""
        actions = {
            'gross_margin': ['优化菜品结构，提高高毛利菜品占比', '降低食材成本', '减少浪费'],
            'food_cost_rate': ['优化采购渠道', '减少食材浪费', '精准预测销量'],
            'labor_cost_rate': ['优化排班', '提升人效', '引入智能化设备'],
            'table_turnover': ['优化服务流程', '缩短用餐时间', '提高出餐速度'],
            'avg_order_value': ['菜品组合推荐', '套餐设计', '加购引导'],
            'customer_satisfaction': ['提升服务质量', '优化菜品口味', '改善用餐环境']
        }
        return actions.get(metric, ['持续优化'])


def main():
    parser = argparse.ArgumentParser(description='行业基准工具')
    parser.add_argument('--category', type=str, default='casual_dining',
                       choices=['fast_food', 'casual_dining', 'delivery_only'],
                       help='业态类型')
    parser.add_argument('--output', type=str, default='benchmark_report.json', help='输出文件')
    
    args = parser.parse_args()
    
    benchmark = IndustryBenchmark()
    
    # 示例门店数据
    sample_metrics = {
        'gross_margin': 0.62,
        'food_cost_rate': 0.35,
        'labor_cost_rate': 0.24,
        'table_turnover': 2.2,
        'avg_order_value': 75,
        'customer_satisfaction': 4.3
    }
    
    try:
        # 获取基准
        benchmark_data = benchmark.get_benchmark(args.category)
        
        # 对比分析
        comparison = benchmark.compare_to_benchmark(args.category, sample_metrics)
        
        # 最佳实践
        practices = benchmark.get_best_practices(args.category)
        
        # 改进路线图
        roadmap = benchmark.generate_improvement_roadmap(args.category, sample_metrics)
        
        result = {
            'timestamp': datetime.now().isoformat(),
            'benchmark_data': benchmark_data,
            'comparison_analysis': comparison,
            'best_practices': practices,
            'improvement_roadmap': roadmap
        }
        
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        
        print(f"[SUCCESS] 行业基准报告已生成: {args.output}")
        
        print(f"\n[INDUSTRY BENCHMARK] {benchmark_data['name']}行业基准:")
        print(f"  - 综合得分: {comparison['overall_score']}/100")
        print(f"  - 行业排名: {comparison['ranking']}")
        
        print(f"\n[COMPARISON] 关键指标对比:")
        for metric, data in list(comparison['comparison'].items())[:3]:
            print(f"  - {data['description']}: {data['current_value']} ({data['level']})")
        
        print(f"\n[BEST PRACTICES] 标杆案例:")
        for practice in practices[:2]:
            print(f"  - {practice['company']}: {', '.join(practice['best_practices'][:2])}")
        
        return 0
        
    except Exception as e:
        print(f"[ERROR] 分析失败: {str(e)}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
