---
name: data-analytics
description: 餐饮门店全链路数据分析能力，包含KPI监控、异常检测、归因分析、趋势预测；当用户需要进行经营分析、业绩诊断、数据洞察或生成分析报告时使用
author: ProClaw
author_url: https://www.ProClaw.top
dependency:
  python:
    - numpy==1.26.2
---

# 餐饮门店数据分析Skill

## 任务目标
- 本Skill用于：餐饮门店经营数据的深度分析与洞察挖掘
- 能力包含：KPI监控、异常检测、趋势分析、归因诊断、预测建模
- 触发条件：经营分析需求、业绩诊断、异常排查、决策支持

## 前置准备
- 依赖说明：scripts脚本所需的依赖包及版本
  ```
  numpy==1.26.2
  ```

## 操作步骤

### 标准流程

#### 1. 数据接入与清洗
- 调用 `scripts/kpi_calculator.py` 进行数据标准化处理
- 智能体根据 `references/kpi_definitions.md` 验证数据完整性
- 输出清洗后的数据摘要

#### 2. KPI计算与监控
- 执行核心指标计算：
  - 翻台率 = 用餐桌数 / (餐桌数 × 营业时长)
  - 客单价 = 营业额 / 用餐人数
  - 毛利率 = (营业额 - 食材成本) / 营业额
  - 转化率 = 成交订单数 / 曝光量
- 生成KPI仪表盘报告

#### 3. 异常检测
- 调用 `scripts/anomaly_detector.py` 进行智能异常识别
- 检测维度：
  - 销售额异常（突增/突降）
  - 转化率异常
  - 成本异常
  - 顾客评价异常
- 输出异常清单与可能原因

#### 4. 趋势分析与预测
- 调用 `scripts/trend_analyzer.py` 进行时序分析
- 分析内容：
  - 同比环比分析
  - 季节性规律识别
  - 未来7天销量预测
- 输出趋势洞察报告

#### 5. 归因诊断
- 智能体基于多维数据进行根因分析
- 分析框架：
  - 内部因素（产品、服务、运营）
  - 外部因素（天气、节假日、竞争）
  - 平台因素（流量、活动、评价）
- 输出归因分析报告与优化建议

### 可选分支

#### 分支A：专项诊断
- 当KPI出现显著波动时，触发深度诊断
- 聚焦异常指标，穿透分析至具体菜品、时段、客群

#### 分支B：竞品对标
- 当需要市场定位分析时，执行竞品对比
- 分析维度：价格带、爆款菜品、营销策略、评价分布

#### 分支C：预测建模
- 当需要长期规划时，构建预测模型
- 应用场景：销量预测、库存规划、人力排班

## 资源索引

### 必要脚本
- [scripts/kpi_calculator.py](scripts/kpi_calculator.py) - 核心KPI计算引擎，支持翻台率、客单价、毛利率等关键指标计算
- [scripts/anomaly_detector.py](scripts/anomaly_detector.py) - 异常检测算法，智能识别销售、转化、成本异常
- [scripts/trend_analyzer.py](scripts/trend_analyzer.py) - 趋势分析与预测，支持同比环比分析、季节性识别、销量预测
- [scripts/realtime_monitor.py](scripts/realtime_monitor.py) - 实时监控引擎，支持实时数据采集、监控告警、异常检测、行业对标
- [scripts/industry_benchmark.py](scripts/industry_benchmark.py) - 行业基准数据库，包含快餐/正餐/外卖业态基准数据、标杆案例、改进路线图
- [scripts/decision_engine.py](scripts/decision_engine.py) - 智能决策推荐引擎，基于数据自动推荐优化方案、生成行动计划
- [scripts/automation_engine.py](scripts/automation_engine.py) - 自动化执行引擎，支持定时任务、自动化工作流、智能触发

### 领域参考
- [references/kpi_definitions.md](references/kpi_definitions.md) - KPI指标定义与计算公式
- [references/analysis_templates.md](references/analysis_templates.md) - 分析报告模板库
- [references/anomaly_rules.md](references/anomaly_rules.md) - 异常判定规则

### 输出资产
- KPI监控日报/周报/月报
- 异常预警通知
- 经营分析报告
- 优化建议清单

## 注意事项

### 数据质量要求
- 确保数据完整性：缺失率<5%
- 确保数据准确性：异常值需人工复核
- 确保数据时效性：建议每日更新

### 分析深度控制
- 基础分析：指标监控与趋势描述
- 深度分析：归因诊断与根因挖掘
- 预测分析：建模与情景模拟

### 与其他Agent协作
- 发现成本异常 → 触发成本管控Agent
- 发现运营异常 → 触发美团运营Agent
- 发现食安风险 → 触发食安风控Agent

## 使用示例

### 示例1：日常经营分析
```bash
# 计算昨日KPI
python scripts/kpi_calculator.py --date 2024-01-15 --output daily_report.json

# 检测异常
python scripts/anomaly_detector.py --input daily_report.json --threshold 2.0

# 智能体解读报告并给出建议
```

### 示例2：周度业绩诊断
```bash
# 生成周报
python scripts/kpi_calculator.py --start 2024-01-08 --end 2024-01-14 --output weekly_report.json

# 趋势分析
python scripts/trend_analyzer.py --input weekly_report.json --period week

# 智能体进行归因分析
```

### 示例3：异常预警
```bash
# 实时监控
python scripts/anomaly_detector.py --mode realtime --alert

# 输出异常事件并触发预警
```

## 顶级玩家实战要点

### 1. 数据驱动决策
- 不凭感觉，用数据说话
- 建立指标基线，识别异常波动
- 从数据中发现隐性规律

### 2. 多维交叉分析
- 不要孤立看单个指标
- 建立指标关联网络（如客单价与翻台率的平衡）
- 从多维视角识别机会点

### 3. 根因穿透
- 发现问题只是第一步
- 穿透至根因：为什么发生？
- 提出可执行的改进方案

### 4. 预测性运营
- 从事后分析转向事前预测
- 基于预测优化资源配置
- 提前识别风险与机会
