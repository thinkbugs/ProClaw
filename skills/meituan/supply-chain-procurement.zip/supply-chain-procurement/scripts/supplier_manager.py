#!/usr/bin/env python3
"""
供应商管理与风险预警引擎
供应商评估、风险管理、智能采购建议

使用方式:
    python supplier_manager.py --output supplier_report.json
"""

import argparse
import json
import sys
from datetime import datetime, timedelta
from typing import Dict, List
import numpy as np


class SupplierManager:
    """供应商管理引擎"""
    
    def __init__(self):
        self.suppliers = {}
        self.evaluation_criteria = {
            'quality': 0.30,    # 质量权重
            'price': 0.25,      # 价格权重
            'delivery': 0.20,   # 交付权重
            'service': 0.15,    # 服务权重
            'stability': 0.10   # 稳定性权重
        }
    
    def add_supplier(self, supplier_data: Dict):
        """
        添加供应商
        
        参数:
            supplier_data: {
                'supplier_id': 'S001',
                'name': '优质食材供应商',
                'category': '肉类',
                'contact': '张经理',
                'phone': '138****1234',
                'address': '北京市朝阳区...',
                'evaluation': {
                    'quality': 4.5,      # 1-5分
                    'price': 4.0,
                    'delivery': 4.8,
                    'service': 4.2,
                    'stability': 4.6
                },
                'products': ['鸡胸肉', '牛肉', '猪肉'],
                'monthly_volume': 50000,
                'payment_terms': '月结30天',
                'lead_time': 1,  # 交货周期（天）
                'status': 'active'
            }
        """
        self.suppliers[supplier_data['supplier_id']] = supplier_data
    
    def evaluate_supplier(self, supplier_id: str) -> Dict:
        """评估供应商"""
        if supplier_id not in self.suppliers:
            return {}
        
        supplier = self.suppliers[supplier_id]
        evaluation = supplier.get('evaluation', {})
        
        # 计算综合得分
        total_score = 0
        for criterion, weight in self.evaluation_criteria.items():
            score = evaluation.get(criterion, 0)
            total_score += score * weight
        
        # 确定等级
        if total_score >= 4.5:
            grade = 'A'
            status = '优选供应商'
        elif total_score >= 4.0:
            grade = 'B'
            status = '合格供应商'
        elif total_score >= 3.5:
            grade = 'C'
            status = '观察供应商'
        else:
            grade = 'D'
            status = '淘汰候选'
        
        return {
            'supplier_id': supplier_id,
            'name': supplier['name'],
            'category': supplier['category'],
            'total_score': round(total_score, 2),
            'grade': grade,
            'status': status,
            'evaluation_detail': evaluation,
            'improvement_areas': self._identify_improvements(evaluation)
        }
    
    def _identify_improvements(self, evaluation: Dict) -> List[str]:
        """识别改进点"""
        improvements = []
        
        for criterion, score in evaluation.items():
            if score < 4.0:
                improvements.append(f"{criterion}评分偏低({score}分)，需改进")
        
        return improvements
    
    def compare_suppliers(self, category: str = None) -> List[Dict]:
        """对比供应商"""
        comparison = []
        
        for supplier_id, supplier in self.suppliers.items():
            if category and supplier['category'] != category:
                continue
            
            eval_result = self.evaluate_supplier(supplier_id)
            comparison.append({
                **eval_result,
                'monthly_volume': supplier.get('monthly_volume', 0),
                'lead_time': supplier.get('lead_time', 0)
            })
        
        # 按得分排序
        return sorted(comparison, key=lambda x: x['total_score'], reverse=True)
    
    def generate_sourcing_recommendation(self, product: str, quantity: float) -> Dict:
        """生成采购建议"""
        # 查找能提供该产品的供应商
        available_suppliers = []
        
        for supplier_id, supplier in self.suppliers.items():
            if product in supplier.get('products', []):
                eval_result = self.evaluate_supplier(supplier_id)
                available_suppliers.append({
                    'supplier_id': supplier_id,
                    'name': supplier['name'],
                    'score': eval_result['total_score'],
                    'grade': eval_result['grade'],
                    'lead_time': supplier.get('lead_time', 0)
                })
        
        # 按得分排序
        available_suppliers.sort(key=lambda x: x['score'], reverse=True)
        
        # 推荐最优供应商
        if available_suppliers:
            best = available_suppliers[0]
            recommendation = {
                'product': product,
                'quantity': quantity,
                'recommended_supplier': best,
                'alternatives': available_suppliers[1:3],
                'reason': f"综合评分最高({best['score']}分)，等级{best['grade']}"
            }
        else:
            recommendation = {
                'product': product,
                'quantity': quantity,
                'recommended_supplier': None,
                'message': '未找到合适的供应商'
            }
        
        return recommendation


class RiskAlerter:
    """风险预警引擎"""
    
    def __init__(self):
        self.risk_thresholds = {
            'supplier_concentration': {
                'warning': 0.30,
                'critical': 0.50,
                'description': '单一供应商采购占比过高'
            },
            'lead_time_risk': {
                'warning': 3,
                'critical': 5,
                'description': '交货周期过长'
            },
            'quality_drop': {
                'warning': 4.0,
                'critical': 3.5,
                'description': '质量评分下降'
            }
        }
    
    def analyze_supply_risk(self, suppliers: Dict, procurement_data: Dict = None) -> List[Dict]:
        """分析供应链风险"""
        risks = []
        
        # 1. 供应商集中度风险
        if procurement_data:
            for supplier_id, volume in procurement_data.items():
                concentration = volume / sum(procurement_data.values())
                if concentration >= self.risk_thresholds['supplier_concentration']['critical']:
                    risks.append({
                        'type': 'supplier_concentration',
                        'level': 'critical',
                        'supplier_id': supplier_id,
                        'message': f"供应商 {supplier_id} 采购占比 {concentration*100:.1f}%，过度集中风险高",
                        'recommendation': '开发备选供应商，分散采购风险'
                    })
                elif concentration >= self.risk_thresholds['supplier_concentration']['warning']:
                    risks.append({
                        'type': 'supplier_concentration',
                        'level': 'warning',
                        'supplier_id': supplier_id,
                        'message': f"供应商 {supplier_id} 采购占比 {concentration*100:.1f}%，建议分散",
                        'recommendation': '考虑引入新供应商'
                    })
        
        # 2. 交货周期风险
        for supplier_id, supplier in suppliers.items():
            lead_time = supplier.get('lead_time', 0)
            if lead_time >= self.risk_thresholds['lead_time_risk']['critical']:
                risks.append({
                    'type': 'lead_time_risk',
                    'level': 'critical',
                    'supplier_id': supplier_id,
                    'message': f"供应商 {supplier['name']} 交货周期 {lead_time}天，风险高",
                    'recommendation': '建立安全库存或更换供应商'
                })
        
        # 3. 质量风险
        for supplier_id, supplier in suppliers.items():
            quality_score = supplier.get('evaluation', {}).get('quality', 5)
            if quality_score <= self.risk_thresholds['quality_drop']['critical']:
                risks.append({
                    'type': 'quality_drop',
                    'level': 'critical',
                    'supplier_id': supplier_id,
                    'message': f"供应商 {supplier['name']} 质量评分 {quality_score}，不合格",
                    'recommendation': '立即整改或更换供应商'
                })
            elif quality_score <= self.risk_thresholds['quality_drop']['warning']:
                risks.append({
                    'type': 'quality_drop',
                    'level': 'warning',
                    'supplier_id': supplier_id,
                    'message': f"供应商 {supplier['name']} 质量评分 {quality_score}，需关注",
                    'recommendation': '加强质量监督'
                })
        
        return risks
    
    def generate_risk_report(self, risks: List[Dict]) -> Dict:
        """生成风险报告"""
        critical_risks = [r for r in risks if r['level'] == 'critical']
        warning_risks = [r for r in risks if r['level'] == 'warning']
        
        return {
            'timestamp': datetime.now().isoformat(),
            'summary': {
                'total_risks': len(risks),
                'critical_count': len(critical_risks),
                'warning_count': len(warning_risks)
            },
            'critical_risks': critical_risks,
            'warning_risks': warning_risks,
            'risk_score': self._calculate_risk_score(critical_risks, warning_risks),
            'mitigation_actions': self._generate_mitigation_actions(risks)
        }
    
    def _calculate_risk_score(self, critical: List, warning: List) -> int:
        """计算风险得分（0-100，越高越危险）"""
        score = len(critical) * 30 + len(warning) * 10
        return min(score, 100)
    
    def _generate_mitigation_actions(self, risks: List[Dict]) -> List[Dict]:
        """生成风险缓解行动"""
        actions = []
        
        for risk in risks:
            actions.append({
                'risk_type': risk['type'],
                'action': risk['recommendation'],
                'priority': risk['level'],
                'deadline': (datetime.now() + timedelta(days=7)).strftime('%Y-%m-%d')
            })
        
        return actions


def main():
    parser = argparse.ArgumentParser(description='供应商管理工具')
    parser.add_argument('--output', type=str, default='supplier_report.json', help='输出文件')
    
    args = parser.parse_args()
    
    manager = SupplierManager()
    alerter = RiskAlerter()
    
    # 添加示例供应商
    manager.add_supplier({
        'supplier_id': 'S001',
        'name': '优质食材供应商',
        'category': '肉类',
        'contact': '张经理',
        'phone': '138****1234',
        'evaluation': {
            'quality': 4.5,
            'price': 4.0,
            'delivery': 4.8,
            'service': 4.2,
            'stability': 4.6
        },
        'products': ['鸡胸肉', '牛肉', '猪肉'],
        'monthly_volume': 50000,
        'lead_time': 1,
        'status': 'active'
    })
    
    manager.add_supplier({
        'supplier_id': 'S002',
        'name': '蔬菜直供基地',
        'category': '蔬菜',
        'contact': '李经理',
        'phone': '139****5678',
        'evaluation': {
            'quality': 4.2,
            'price': 4.5,
            'delivery': 4.0,
            'service': 3.8,
            'stability': 4.0
        },
        'products': ['土豆', '白菜', '西红柿'],
        'monthly_volume': 30000,
        'lead_time': 2,
        'status': 'active'
    })
    
    try:
        # 供应商评估
        evaluations = [manager.evaluate_supplier(sid) for sid in manager.suppliers.keys()]
        
        # 供应商对比
        comparison = manager.compare_suppliers()
        
        # 采购建议
        sourcing = manager.generate_sourcing_recommendation('鸡胸肉', 100)
        
        # 风险分析
        procurement_data = {'S001': 50000, 'S002': 30000}
        risks = alerter.analyze_supply_risk(manager.suppliers, procurement_data)
        risk_report = alerter.generate_risk_report(risks)
        
        result = {
            'timestamp': datetime.now().isoformat(),
            'supplier_evaluations': evaluations,
            'supplier_comparison': comparison,
            'sourcing_recommendation': sourcing,
            'risk_analysis': risk_report
        }
        
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        
        print(f"[SUCCESS] 供应商报告已生成: {args.output}")
        
        print(f"\n[SUPPLIER EVALUATION] 供应商评估:")
        for eval_result in evaluations:
            print(f"  - {eval_result['name']}: {eval_result['grade']}级 ({eval_result['total_score']}分)")
        
        print(f"\n[RISK ANALYSIS] 风险分析:")
        print(f"  - 风险得分: {risk_report['risk_score']}/100")
        print(f"  - 关键风险: {risk_report['summary']['critical_count']} 个")
        print(f"  - 预警风险: {risk_report['summary']['warning_count']} 个")
        
        if risk_report['critical_risks']:
            print(f"\n[CRITICAL RISKS]:")
            for risk in risk_report['critical_risks']:
                print(f"  - {risk['message']}")
        
        return 0
        
    except Exception as e:
        print(f"[ERROR] 分析失败: {str(e)}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
