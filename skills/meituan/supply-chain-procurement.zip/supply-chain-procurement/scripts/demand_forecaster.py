#!/usr/bin/env python3
"""
需求预测引擎
基于历史数据进行销量预测

使用方式:
    python demand_forecaster.py --days 7 --output forecast.json
"""

import argparse
import json
import sys
from datetime import datetime, timedelta
from typing import Dict, List
import numpy as np


class DemandForecaster:
    """需求预测引擎"""
    
    def __init__(self):
        self.weekday_factors = {
            0: 0.90,  # 周一
            1: 0.85,  # 周二
            2: 0.88,  # 周三
            3: 0.92,  # 周四
            4: 1.10,  # 周五
            5: 1.35,  # 周六
            6: 1.25   # 周日
        }
        
        self.weather_factors = {
            'sunny': 1.10,
            'cloudy': 1.00,
            'rainy': 0.85,
            'snowy': 0.75,
            'hot': 0.90,
            'cold': 0.95
        }
        
        self.holiday_factors = {
            'normal': 1.00,
            'holiday': 1.40,
            'festival': 1.60
        }
    
    def forecast_simple(self, historical_sales: List[float], 
                        forecast_days: int = 7) -> List[Dict]:
        """
        简单预测（加权移动平均）
        
        参数:
            historical_sales: 过去N天的销量
            forecast_days: 预测天数
        """
        if len(historical_sales) < 7:
            raise ValueError("至少需要7天历史数据")
        
        # 计算加权平均（最近7天）
        weights = [0.05, 0.08, 0.10, 0.12, 0.15, 0.20, 0.30]
        base_value = sum(s * w for s, w in zip(historical_sales[-7:], weights))
        
        # 生成预测
        forecasts = []
        last_date = datetime.now()
        
        for i in range(1, forecast_days + 1):
            forecast_date = (last_date + timedelta(days=i)).strftime('%Y-%m-%d')
            weekday = (last_date + timedelta(days=i)).weekday()
            
            # 应用星期因子
            weekday_factor = self.weekday_factors[weekday]
            
            # 预测值
            forecast_value = base_value * weekday_factor
            
            forecasts.append({
                'date': forecast_date,
                'weekday': ['周一','周二','周三','周四','周五','周六','周日'][weekday],
                'forecast': round(forecast_value, 0),
                'weekday_factor': weekday_factor,
                'confidence': max(0.70, 0.90 - 0.03 * i)  # 置信度递减
            })
        
        return forecasts
    
    def forecast_with_factors(self, base_sales: float,
                               weekday: int,
                               weather: str = 'cloudy',
                               holiday_type: str = 'normal',
                               activity_factor: float = 1.0) -> Dict:
        """
        带因子的预测
        """
        # 基础值
        forecast = base_sales
        
        # 应用各因子
        forecast *= self.weekday_factors.get(weekday, 1.0)
        forecast *= self.weather_factors.get(weather, 1.0)
        forecast *= self.holiday_factors.get(holiday_type, 1.0)
        forecast *= activity_factor
        
        return {
            'base_sales': base_sales,
            'weekday_factor': self.weekday_factors.get(weekday, 1.0),
            'weather_factor': self.weather_factors.get(weather, 1.0),
            'holiday_factor': self.holiday_factors.get(holiday_type, 1.0),
            'activity_factor': activity_factor,
            'forecast': round(forecast, 0)
        }
    
    def generate_purchase_plan(self, forecasts: List[Dict],
                                ingredient_usage: Dict[str, float]) -> Dict:
        """
        生成采购计划
        
        参数:
            forecasts: 预测销量
            ingredient_usage: {
                '鸡肉': 0.15,  # 每份菜品用鸡肉0.15kg
                '蔬菜': 0.20,
                ...
            }
        """
        total_forecast = sum(f['forecast'] for f in forecasts)
        
        purchase_plan = []
        for ingredient, usage_per_dish in ingredient_usage.items():
            # 理论用量
            theoretical_usage = total_forecast * usage_per_dish
            
            # 安全库存（增加10%）
            safe_usage = theoretical_usage * 1.10
            
            purchase_plan.append({
                'ingredient': ingredient,
                'theoretical_usage': round(theoretical_usage, 2),
                'safe_purchase': round(safe_usage, 2),
                'unit': 'kg'
            })
        
        return {
            'total_forecast_sales': total_forecast,
            'purchase_plan': purchase_plan,
            'forecast_period': f"{forecasts[0]['date']} 至 {forecasts[-1]['date']}"
        }


def main():
    parser = argparse.ArgumentParser(description='需求预测工具')
    parser.add_argument('--days', type=int, default=7, help='预测天数')
    parser.add_argument('--output', type=str, default='forecast.json', help='输出文件')
    
    args = parser.parse_args()
    
    forecaster = DemandForecaster()
    
    # 示例历史数据（过去14天）
    historical_sales = [
        120, 115, 118, 125, 145, 180, 165,
        122, 110, 115, 130, 150, 185, 170
    ]
    
    try:
        # 预测
        forecasts = forecaster.forecast_simple(historical_sales, args.days)
        
        # 采购计划
        ingredient_usage = {
            '鸡肉': 0.15,
            '蔬菜': 0.20,
            '大米': 0.10
        }
        purchase_plan = forecaster.generate_purchase_plan(forecasts, ingredient_usage)
        
        result = {
            'timestamp': datetime.now().isoformat(),
            'forecasts': forecasts,
            'purchase_plan': purchase_plan
        }
        
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        
        print(f"[SUCCESS] 预测报告已生成: {args.output}")
        print(f"\n[INFO] 预测概况:")
        print(f"  - 预测周期: {forecasts[0]['date']} 至 {forecasts[-1]['date']}")
        print(f"  - 预测总销量: {sum(f['forecast'] for f in forecasts)} 份")
        
        print(f"\n[FORECAST] 未来3天预测:")
        for fc in forecasts[:3]:
            print(f"  - {fc['date']}({fc['weekday']}): {fc['forecast']} 份 (置信度: {fc['confidence']:.0%})")
        
        return 0
        
    except Exception as e:
        print(f"[ERROR] 预测失败: {str(e)}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
