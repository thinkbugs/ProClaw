---
name: supply-chain-procurement
description: 餐饮供应链智能管理能力，包含需求预测、智能补货、供应商评估、库存优化；当用户需要进行采购决策、库存管理、供应商管理或成本优化时使用
author: ProClaw
author_url: https://www.ProClaw.top
dependency:
  python:
    - numpy==1.26.2
---

# 采购供应链管理Skill

## 任务目标
- 本Skill用于：餐饮门店供应链的智能化管理
- 能力包含：需求预测、智能补货、供应商评估、库存优化、成本控制
- 触发条件：采购决策、库存预警、供应商评估、成本优化

## 前置准备
- 依赖说明：scripts脚本所需的依赖包及版本
  ```
  numpy==1.26.2
  ```

## 操作步骤

### 标准流程

#### 1. 需求预测
- 调用 `scripts/demand_forecaster.py` 进行销量预测
- 预测维度：
  - **历史数据**：过去30天销量
  - **时间因素**：星期、月份、节假日
  - **外部因素**：天气、活动、竞品
  - **趋势因素**：增长趋势、季节性
- 输出未来7天需求预测

**预测模型**：
```
需求预测 = 历史均值 × 星期系数 × 天气系数 × 活动系数 × 趋势系数

示例：
历史日均销量 = 100份
星期系数(周六) = 1.3
天气系数(晴天) = 1.1
活动系数(无活动) = 1.0
趋势系数 = 1.05

预测销量 = 100 × 1.3 × 1.1 × 1.0 × 1.05 = 150份
```

#### 2. 智能补货
- 调用 `scripts/inventory_optimizer.py` 生成采购计划
- 补货策略：
  - **定期定量**：固定周期、固定数量
  - **定期不定量**：固定周期、动态数量
  - **不定期定量**：达到阈值、固定数量
  - **动态补货**：基于预测、动态调整
- 输出采购订单

**安全库存计算**：
```
安全库存 = (最大日销量 × 最长供货期) - (平均日销量 × 平均供货期)

再订货点 = 平均日销量 × 供货期 + 安全库存

示例：
平均日销量 = 50kg
供货期 = 2天
最大日销量 = 80kg
最长供货期 = 3天

安全库存 = (80 × 3) - (50 × 2) = 140kg
再订货点 = 50 × 2 + 140 = 240kg
```

#### 3. 供应商评估
- 调用 `scripts/supplier_scorer.py` 评估供应商
- 评估维度：
  - **价格竞争力**（30%）：价格水平、价格稳定性
  - **质量稳定性**（30%）：合格率、投诉率
  - **交付可靠性**（20%）：准时率、完整性
  - **服务响应**（10%）：响应速度、问题解决
  - **合作深度**（10%）：账期、支持力度
- 输出供应商评分与选择建议

#### 4. 库存优化
- 库存管理策略：
  - **ABC分类**：A类重点管理、B类正常管理、C类简化管理
  - **FIFO原则**：先进先出，避免过期
  - **效期预警**：临期食材优先使用
- 目标：
  - 库存周转率 > 15次/月
  - 缺货率 < 2%
  - 过期损耗率 < 0.5%

### 可选分支

#### 分支A：紧急采购
- 突发缺货时的应急采购
- 备选供应商快速对接
- 成本与时效平衡

#### 分支B：集中采购优化
- 连锁门店集中采购
- 批量议价，降低成本
- 统一配送，提高效率

#### 分支C：供应商谈判
- 价格谈判策略
- 账期优化
- 合作条款升级

## 资源索引

### 必要脚本
- [scripts/demand_forecaster.py](scripts/demand_forecaster.py) - 需求预测算法
- [scripts/inventory_optimizer.py](scripts/inventory_optimizer.py) - 库存优化引擎
- [scripts/supplier_scorer.py](scripts/supplier_scorer.py) - 供应商评分模型
- [scripts/procurement_optimizer.py](scripts/procurement_optimizer.py) - 采购优化引擎，支持智能补货、成本优化、采购计划生成
- [scripts/supplier_manager.py](scripts/supplier_manager.py) - 供应商管理引擎，支持供应商评估、风险管理、智能采购建议、风险预警

### 领域参考
- [references/supplier_management.md](references/supplier_management.md) - 供应商管理SOP
- [references/inventory_policies.md](references/inventory_policies.md) - 库存管理策略
- [references/procurement_case_library.md](references/procurement_case_library.md) - 采购案例库

### 输出资产
- 需求预测报告
- 采购计划
- 供应商评估报告
- 库存优化建议

## 注意事项

### 数据准确性
- 销量数据必须准确
- 库存盘点必须及时
- 预测模型持续优化

### 供应链风险
- 建立备选供应商
- 保持安全库存
- 关注市场动态

### 成本控制
- 批量采购降低单价
- 减少紧急采购
- 优化库存周转

### 与其他Agent协作
- 发现需求异常 → 触发数据分析Agent
- 发现库存异常 → 触发成本管控Agent
- 发现供应商问题 → 触发食安风控Agent

## 使用示例

### 示例1：需求预测
```bash
# 预测未来7天需求
python scripts/demand_forecaster.py --days 7 --output forecast.json

# 智能体解读并生成采购建议
```

### 示例2：智能补货
```bash
# 生成采购计划
python scripts/inventory_optimizer.py --mode auto --output purchase_plan.json

# 智能体审核并执行
```

### 示例3：供应商评估
```bash
# 评估供应商
python scripts/supplier_scorer.py --supplier_id S001 --output score.json

# 智能体给出合作建议
```

## 顶级玩家实战要点

### 1. 需求预测三要素
- **历史数据**：建立销量数据库
- **外部因素**：天气、活动、节假日
- **动态调整**：持续优化预测模型

### 2. 库存管理黄金法则
- **不缺货**：保持安全库存
- **不积压**：提高周转率
- **不浪费**：先进先出，减少损耗

### 3. 供应商管理原则
- **货比三家**：至少3家供应商比价
- **优胜劣汰**：定期评估，动态调整
- **战略合作**：核心供应商深度合作

### 4. 成本优化策略
- **集中采购**：批量议价
- **源头直采**：减少中间环节
- **季节采购**：把握价格波动
