#!/usr/bin/env python3
"""
IoT设备管理与机器人协同引擎
设备监控、数据采集、机器人调度

使用方式:
    python iot_device_manager.py --output iot_report.json
"""

import argparse
import json
import sys
from datetime import datetime, timedelta
from typing import Dict, List
import numpy as np


class IoTDeviceManager:
    """IoT设备管理引擎"""
    
    def __init__(self):
        self.devices = {}
        self.device_types = {
            'smart_scale': {'name': '智能电子秤', 'data_type': 'weight'},
            'smart_fridge': {'name': '智能冰箱', 'data_type': 'temperature'},
            'smart_cooker': {'name': '智能炉灶', 'data_type': 'power'},
            'smart_oven': {'name': '智能烤箱', 'data_type': 'temperature'},
            'robot_cook': {'name': '炒菜机器人', 'data_type': 'status'},
            'robot_delivery': {'name': '送餐机器人', 'data_type': 'location'}
        }
    
    def register_device(self, device_data: Dict):
        """
        注册设备
        
        参数:
            device_data: {
                'device_id': 'D001',
                'type': 'smart_scale',
                'name': '1号电子秤',
                'location': '备菜区',
                'status': 'online',
                'last_data': {'weight': 2.5, 'unit': 'kg'},
                'last_update': '2024-01-15 12:00:00'
            }
        """
        self.devices[device_data['device_id']] = device_data
    
    def collect_device_data(self, device_id: str, data: Dict) -> Dict:
        """采集设备数据"""
        if device_id not in self.devices:
            return {'error': '设备未注册'}
        
        device = self.devices[device_id]
        
        # 更新设备数据
        device['last_data'] = data
        device['last_update'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        return {
            'device_id': device_id,
            'device_name': device['name'],
            'device_type': device['type'],
            'data': data,
            'timestamp': device['last_update']
        }
    
    def get_device_status(self) -> Dict:
        """获取设备状态"""
        status_by_type = {}
        
        for device_id, device in self.devices.items():
            device_type = device['type']
            
            if device_type not in status_by_type:
                status_by_type[device_type] = {
                    'total': 0,
                    'online': 0,
                    'offline': 0,
                    'warning': 0
                }
            
            status_by_type[device_type]['total'] += 1
            
            if device['status'] == 'online':
                status_by_type[device_type]['online'] += 1
            elif device['status'] == 'offline':
                status_by_type[device_type]['offline'] += 1
            else:
                status_by_type[device_type]['warning'] += 1
        
        return {
            'timestamp': datetime.now().isoformat(),
            'total_devices': len(self.devices),
            'online_devices': sum(s['online'] for s in status_by_type.values()),
            'offline_devices': sum(s['offline'] for s in status_by_type.values()),
            'by_type': status_by_type
        }
    
    def analyze_device_usage(self) -> Dict:
        """分析设备使用率"""
        usage_analysis = {}
        
        for device_id, device in self.devices.items():
            device_type = device['type']
            
            if device_type not in usage_analysis:
                usage_analysis[device_type] = {
                    'count': 0,
                    'avg_usage': 0,
                    'peak_usage': 0
                }
            
            usage_analysis[device_type]['count'] += 1
            
            # 模拟使用率数据
            last_data = device.get('last_data', {})
            if 'power' in last_data:
                usage = last_data['power'] / 100  # 假设最大功率为100
                usage_analysis[device_type]['avg_usage'] += usage
                usage_analysis[device_type]['peak_usage'] = max(
                    usage_analysis[device_type]['peak_usage'], usage
                )
        
        # 计算平均使用率
        for device_type in usage_analysis:
            count = usage_analysis[device_type]['count']
            if count > 0:
                usage_analysis[device_type]['avg_usage'] = round(
                    usage_analysis[device_type]['avg_usage'] / count * 100, 1
                )
        
        return {
            'timestamp': datetime.now().isoformat(),
            'usage_by_type': usage_analysis
        }


class RobotCoordinator:
    """机器人协同引擎"""
    
    def __init__(self):
        self.robots = {}
        self.tasks = []
    
    def register_robot(self, robot_data: Dict):
        """
        注册机器人
        
        参数:
            robot_data: {
                'robot_id': 'R001',
                'name': '1号炒菜机器人',
                'type': 'robot_cook',
                'location': '后厨A区',
                'status': 'idle',  # idle/working/error
                'current_task': None,
                'battery': 85,
                'capabilities': ['炒菜', '煮汤', '蒸煮']
            }
        """
        self.robots[robot_data['robot_id']] = robot_data
    
    def assign_task(self, task_data: Dict) -> Dict:
        """
        分配任务
        
        参数:
            task_data: {
                'task_id': 'T001',
                'type': 'cook',
                'dish': '宫保鸡丁',
                'priority': 1,
                'order_id': 'O001'
            }
        """
        # 查找空闲且有能力执行该任务的机器人
        available_robots = [
            r for r in self.robots.values()
            if r['status'] == 'idle' and r['battery'] > 30
        ]
        
        if not available_robots:
            return {
                'success': False,
                'message': '无可用机器人'
            }
        
        # 选择电量最高的机器人
        selected_robot = max(available_robots, key=lambda x: x['battery'])
        
        # 分配任务
        selected_robot['status'] = 'working'
        selected_robot['current_task'] = task_data
        
        self.tasks.append({
            **task_data,
            'assigned_robot': selected_robot['robot_id'],
            'assigned_at': datetime.now().isoformat(),
            'status': 'assigned'
        })
        
        return {
            'success': True,
            'task_id': task_data['task_id'],
            'assigned_robot': selected_robot['robot_id'],
            'robot_name': selected_robot['name'],
            'estimated_time': '5-8分钟'
        }
    
    def get_robot_status(self) -> Dict:
        """获取机器人状态"""
        status_summary = {
            'total': len(self.robots),
            'idle': 0,
            'working': 0,
            'error': 0
        }
        
        robot_details = []
        
        for robot_id, robot in self.robots.items():
            status_summary[robot['status']] += 1
            
            robot_details.append({
                'robot_id': robot_id,
                'name': robot['name'],
                'type': robot['type'],
                'status': robot['status'],
                'battery': robot['battery'],
                'current_task': robot.get('current_task', {}).get('dish') if robot.get('current_task') else None
            })
        
        return {
            'timestamp': datetime.now().isoformat(),
            'summary': status_summary,
            'robots': robot_details
        }
    
    def optimize_robot_scheduling(self, pending_tasks: List[Dict]) -> Dict:
        """优化机器人调度"""
        # 按优先级排序
        sorted_tasks = sorted(pending_tasks, key=lambda x: x.get('priority', 1))
        
        # 分配计划
        schedule = []
        
        for task in sorted_tasks:
            # 查找空闲机器人
            idle_robots = [r for r in self.robots.values() if r['status'] == 'idle']
            
            if idle_robots:
                robot = idle_robots[0]
                schedule.append({
                    'task_id': task['task_id'],
                    'task_name': task.get('dish', task['type']),
                    'assigned_robot': robot['robot_id'],
                    'robot_name': robot['name'],
                    'priority': task.get('priority', 1)
                })
        
        return {
            'timestamp': datetime.now().isoformat(),
            'pending_tasks': len(pending_tasks),
            'scheduled_tasks': len(schedule),
            'schedule': schedule
        }


def main():
    parser = argparse.ArgumentParser(description='IoT设备管理工具')
    parser.add_argument('--output', type=str, default='iot_report.json', help='输出文件')
    
    args = parser.parse_args()
    
    device_manager = IoTDeviceManager()
    robot_coordinator = RobotCoordinator()
    
    # 注册示例设备
    device_manager.register_device({
        'device_id': 'D001',
        'type': 'smart_scale',
        'name': '1号电子秤',
        'location': '备菜区',
        'status': 'online',
        'last_data': {'weight': 2.5, 'unit': 'kg'},
        'last_update': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    })
    
    device_manager.register_device({
        'device_id': 'D002',
        'type': 'smart_fridge',
        'name': '1号智能冰箱',
        'location': '储藏区',
        'status': 'online',
        'last_data': {'temperature': 4, 'unit': '°C'},
        'last_update': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    })
    
    # 注册示例机器人
    robot_coordinator.register_robot({
        'robot_id': 'R001',
        'name': '1号炒菜机器人',
        'type': 'robot_cook',
        'location': '后厨A区',
        'status': 'idle',
        'current_task': None,
        'battery': 85,
        'capabilities': ['炒菜', '煮汤', '蒸煮']
    })
    
    robot_coordinator.register_robot({
        'robot_id': 'R002',
        'name': '1号送餐机器人',
        'type': 'robot_delivery',
        'location': '前厅',
        'status': 'working',
        'current_task': {'task_id': 'T001', 'dish': '水煮鱼'},
        'battery': 72,
        'capabilities': ['送餐', '回收餐具']
    })
    
    try:
        # 设备状态
        device_status = device_manager.get_device_status()
        
        # 设备使用分析
        device_usage = device_manager.analyze_device_usage()
        
        # 机器人状态
        robot_status = robot_coordinator.get_robot_status()
        
        # 分配任务
        task_assignment = robot_coordinator.assign_task({
            'task_id': 'T002',
            'type': 'cook',
            'dish': '宫保鸡丁',
            'priority': 1,
            'order_id': 'O002'
        })
        
        # 优化调度
        pending_tasks = [
            {'task_id': 'T003', 'type': 'cook', 'dish': '炒饭', 'priority': 2},
            {'task_id': 'T004', 'type': 'cook', 'dish': '蛋花汤', 'priority': 1}
        ]
        scheduling = robot_coordinator.optimize_robot_scheduling(pending_tasks)
        
        result = {
            'timestamp': datetime.now().isoformat(),
            'device_status': device_status,
            'device_usage': device_usage,
            'robot_status': robot_status,
            'task_assignment': task_assignment,
            'scheduling_optimization': scheduling
        }
        
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        
        print(f"[SUCCESS] IoT设备报告已生成: {args.output}")
        
        print(f"\n[DEVICE STATUS] 设备状态:")
        print(f"  - 总设备数: {device_status['total_devices']}")
        print(f"  - 在线设备: {device_status['online_devices']}")
        print(f"  - 离线设备: {device_status['offline_devices']}")
        
        print(f"\n[ROBOT STATUS] 机器人状态:")
        print(f"  - 总数: {robot_status['summary']['total']}")
        print(f"  - 空闲: {robot_status['summary']['idle']}")
        print(f"  - 工作中: {robot_status['summary']['working']}")
        
        if task_assignment['success']:
            print(f"\n[TASK ASSIGNED] 任务分配成功:")
            print(f"  - 任务: {task_assignment['task_id']}")
            print(f"  - 分配给: {task_assignment['robot_name']}")
        
        return 0
        
    except Exception as e:
        print(f"[ERROR] 分析失败: {str(e)}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
