#!/usr/bin/env python3
"""
生产调度引擎
KDS智能排程、任务分配、时间优化

使用方式:
    python production_scheduler.py --orders orders.json --output schedule.json
"""

import argparse
import json
import sys
from datetime import datetime, timedelta
from typing import Dict, List
import numpy as np


class ProductionScheduler:
    """生产调度引擎"""
    
    def __init__(self):
        self.workstations = {
            'stove': {
                'name': '炒灶',
                'capacity': 3,  # 同时可处理订单数
                'dishes': ['炒菜', '炒饭', '炒面']
            },
            'fryer': {
                'name': '炸锅',
                'capacity': 2,
                'dishes': ['炸鸡', '炸薯条', '炸串']
            },
            'steamer': {
                'name': '蒸箱',
                'capacity': 2,
                'dishes': ['蒸菜', '蒸蛋', '蒸汤']
            },
            'grill': {
                'name': '烤炉',
                'capacity': 1,
                'dishes': ['烤串', '烤鱼']
            }
        }
        
        self.dish_cooking_time = {
            '宫保鸡丁': {'workstation': 'stove', 'time': 5},
            '炸鸡': {'workstation': 'fryer', 'time': 8},
            '蛋花汤': {'workstation': 'steamer', 'time': 3},
            '炒饭': {'workstation': 'stove', 'time': 4},
            '清蒸鱼': {'workstation': 'steamer', 'time': 10},
            '烤鱼': {'workstation': 'grill', 'time': 15}
        }
    
    def schedule_orders(self, orders: List[Dict]) -> Dict:
        """
        订单排程
        
        参数:
            orders: [
                {
                    'order_id': 'A001',
                    'type': 'dine_in',  # dine_in/takeout
                    'priority': 1,  # 1=普通, 2=催单, 3=外卖
                    'dishes': ['宫保鸡丁', '蛋花汤']
                }
            ]
        """
        # 按优先级排序
        sorted_orders = sorted(orders, key=lambda x: x['priority'], reverse=True)
        
        # 初始化工位任务队列
        workstation_tasks = {ws: [] for ws in self.workstations}
        
        # 时间线
        timeline = []
        current_time = 0
        
        # 分配任务
        for order in sorted_orders:
            order_tasks = []
            
            for dish in order['dishes']:
                if dish not in self.dish_cooking_time:
                    continue
                
                dish_info = self.dish_cooking_time[dish]
                workstation = dish_info['workstation']
                cook_time = dish_info['time']
                
                # 找到最早可用时间
                ws_tasks = workstation_tasks[workstation]
                if ws_tasks:
                    earliest_start = max(t['end_time'] for t in ws_tasks)
                else:
                    earliest_start = current_time
                
                # 创建任务
                task = {
                    'order_id': order['order_id'],
                    'dish': dish,
                    'workstation': workstation,
                    'workstation_name': self.workstations[workstation]['name'],
                    'start_time': earliest_start,
                    'end_time': earliest_start + cook_time,
                    'duration': cook_time
                }
                
                ws_tasks.append(task)
                order_tasks.append(task)
                timeline.append(task)
            
            # 更新订单完成时间
            if order_tasks:
                order['completion_time'] = max(t['end_time'] for t in order_tasks)
        
        # 计算指标
        total_time = max(t['end_time'] for t in timeline) if timeline else 0
        avg_wait_time = sum(o.get('completion_time', 0) for o in sorted_orders) / len(sorted_orders)
        
        return {
            'timestamp': datetime.now().isoformat(),
            'total_orders': len(orders),
            'total_time_minutes': total_time,
            'avg_wait_time_minutes': round(avg_wait_time, 1),
            'timeline': sorted(timeline, key=lambda x: x['start_time']),
            'workstation_utilization': self._calculate_utilization(workstation_tasks, total_time)
        }
    
    def _calculate_utilization(self, workstation_tasks: Dict, total_time: int) -> Dict:
        """计算工位利用率"""
        utilization = {}
        
        for ws, tasks in workstation_tasks.items():
            if not tasks:
                utilization[ws] = {
                    'name': self.workstations[ws]['name'],
                    'busy_time': 0,
                    'utilization_rate': 0
                }
                continue
            
            busy_time = sum(t['duration'] for t in tasks)
            utilization[ws] = {
                'name': self.workstations[ws]['name'],
                'busy_time': busy_time,
                'utilization_rate': round(busy_time / total_time * 100, 1) if total_time > 0 else 0
            }
        
        return utilization
    
    def optimize_sequence(self, orders: List[Dict]) -> List[Dict]:
        """优化订单顺序"""
        # 简单优化：外卖和催单优先
        priority_orders = [o for o in orders if o.get('priority', 1) >= 2]
        normal_orders = [o for o in orders if o.get('priority', 1) < 2]
        
        return priority_orders + normal_orders


def main():
    parser = argparse.ArgumentParser(description='生产调度工具')
    parser.add_argument('--output', type=str, default='schedule.json', help='输出文件')
    
    args = parser.parse_args()
    
    scheduler = ProductionScheduler()
    
    # 示例订单
    sample_orders = [
        {
            'order_id': 'A001',
            'type': 'dine_in',
            'priority': 1,
            'dishes': ['宫保鸡丁', '蛋花汤']
        },
        {
            'order_id': 'A002',
            'type': 'takeout',
            'priority': 3,
            'dishes': ['炸鸡', '炒饭']
        },
        {
            'order_id': 'A003',
            'type': 'dine_in',
            'priority': 2,
            'dishes': ['清蒸鱼']
        }
    ]
    
    try:
        schedule = scheduler.schedule_orders(sample_orders)
        
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(schedule, f, ensure_ascii=False, indent=2)
        
        print(f"[SUCCESS] 调度计划已生成: {args.output}")
        print(f"\n[INFO] 核心指标:")
        print(f"  - 总订单数: {schedule['total_orders']}")
        print(f"  - 总用时: {schedule['total_time_minutes']} 分钟")
        print(f"  - 平均等待: {schedule['avg_wait_time_minutes']} 分钟")
        
        print(f"\n[TIMELINE] 任务时间线:")
        for task in schedule['timeline'][:5]:
            print(f"  - {task['start_time']}-{task['end_time']}min: {task['dish']} @ {task['workstation_name']}")
        
        return 0
        
    except Exception as e:
        print(f"[ERROR] 调度失败: {str(e)}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
