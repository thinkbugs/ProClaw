---
name: kitchen-production
description: 后厨生产智能化调度能力，包含KDS排程、设备监控、出餐管理、工序优化；当用户需要优化后厨效率、缩短出餐时间、提升翻台率时使用
author: ProClaw
author_url: https://www.ProClaw.top
dependency:
  python:
    - numpy==1.26.2
---

# 后厨生产调度Skill

## 任务目标
- 本Skill用于：后厨生产流程的智能化管理
- 能力包含：KDS排程、设备监控、出餐管理、工序优化、品质管控
- 触发条件：生产调度、出餐优化、设备管理、品质提升

## 前置准备
- 依赖说明：scripts脚本所需的依赖包及版本
  ```
  numpy==1.26.2
  ```

## 操作步骤

### 标准流程

#### 1. 订单接收与拆分
- 智能体接收多渠道订单（堂食+外卖）
- 订单智能拆分：
  - 按工位拆分（炒灶、炸锅、蒸箱）
  - 按工序拆分（备料、烹饪、装盘）
  - 按优先级排序（催单优先、外卖优先）
- 输出订单任务清单

#### 2. KDS智能排程
- 调用 `scripts/production_scheduler.py` 进行生产调度
- 排程策略：
  - **FIFO原则**：先下单先制作
  - **优先级调度**：催单、外卖、VIP优先
  - **工位均衡**：避免某工位过载
  - **时间优化**：缩短总等待时间
- 输出生产任务分配表

**排程算法示例**：
```
订单队列：
订单A：宫保鸡丁(炒灶,5min) + 蛋花汤(蒸箱,3min)
订单B：炸鸡(炸锅,8min) + 炒饭(炒灶,4min)
订单C：清蒸鱼(蒸箱,10min)

排程结果：
时间  炒灶      炸锅     蒸箱
0min  订单A    订单B    订单C
5min  订单B    -       订单A(汤)
9min  -       -       -

总等待时间优化：从27min降至15min
```

#### 3. 设备监控
- 调用 `scripts/equipment_monitor.py` 监控设备状态
- 监控内容：
  - **设备状态**：运行中、空闲、故障
  - **温度监控**：油温、水温、烤箱温度
  - **能耗监控**：功率、用电量
  - **维护提醒**：保养周期、故障预警
- 输出设备运行报告

#### 4. 出餐进度管理
- 实时跟踪每道菜的制作进度
- 进度状态：
  - 待制作 → 制作中 → 待出餐 → 已出餐
- 异常预警：
  - 超时预警：制作时间超过标准
  - 积压预警：订单堆积过多
  - 设备故障：影响出餐进度
- 输出出餐进度看板

#### 5. 品质管控
- 出品标准化检查：
  - 份量检查：是否符合标准
  - 温度检查：是否达到出餐温度
  - 外观检查：是否符合呈现标准
- 不合格品退回重做
- 输出品控报告

### 可选分支

#### 分支A：高峰期应对
- 订单量突增时的应对策略
- 启动应急预案：
  - 简化菜品选择
  - 延长出餐时间预估
  - 增加人手支援

#### 分支B：设备故障处理
- 设备故障时的应急方案
- 备用设备启用
- 订单调整与顾客沟通

#### 分支C：新品引入
- 新菜品的生产流程设计
- 标准作业指导书制定
- 员工培训计划

## 资源索引

### 必要脚本
- [scripts/production_scheduler.py](scripts/production_scheduler.py) - 生产调度算法
- [scripts/equipment_monitor.py](scripts/equipment_monitor.py) - 设备监控引擎
- [scripts/quality_inspector.py](scripts/quality_inspector.py) - 品质检查工具
- [scripts/iot_device_manager.py](scripts/iot_device_manager.py) - IoT设备管理与机器人协同引擎，支持设备监控、数据采集、机器人调度、自动化协同

### 领域参考
- [references/production_sop.md](references/production_sop.md) - 生产作业标准
- [references/equipment_specs.md](references/equipment_specs.md) - 设备技术规格
- [references/kds_integration.md](references/kds_integration.md) - KDS系统对接指南

### 输出资产
- 生产任务分配表
- 设备运行报告
- 出餐进度看板
- 品控检查报告

## 注意事项

### 生产效率
- 目标出餐时间：快餐<5min，正餐<15min
- 订单准确率：>99%
- 设备利用率：>80%

### 品质保证
- 严格执行标准化作业
- 不合格的坚决退回
- 持续改进出品质量

### 安全管理
- 设备操作规范
- 食品安全规范
- 消防安全规范

### 与其他Agent协作
- 发现订单异常 → 触发订单处理Agent
- 发现设备故障 → 触发仓储管理Agent
- 发现品质问题 → 触发菜品研发Agent

## 使用示例

### 示例1：生产调度
```bash
# 生成生产任务
python scripts/production_scheduler.py --orders orders.json --output schedule.json

# 智能体分配任务到各工位
```

### 示例2：设备监控
```bash
# 监控设备状态
python scripts/equipment_monitor.py --interval 60 --output equipment_status.json

# 智能体识别异常并预警
```

### 示例3：品质检查
```bash
# 执行品质检查
python scripts/quality_inspector.py --batch B001 --output qc_report.json

# 智能体给出改进建议
```

## 顶级玩家实战要点

### 1. 生产效率三要素
- **人员**：技能熟练、分工明确
- **设备**：状态良好、配置合理
- **流程**：优化顺畅、减少等待

### 2. KDS排程黄金法则
- **并行制作**：不同工位同时开工
- **优先级管理**：催单、外卖、VIP优先
- **时间预估**：准确告知顾客等待时间

### 3. 出餐速度优化
- **备料前置**：提前准备常用食材
- **工序优化**：减少不必要的等待
- **设备联动**：多设备协同工作

### 4. 品质管控要点
- **标准化**：每道菜有标准SOP
- **检查**：出品前必须检查
- **改进**：发现问题立即整改
