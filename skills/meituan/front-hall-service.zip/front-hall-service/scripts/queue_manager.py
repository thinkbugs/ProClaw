#!/usr/bin/env python3
"""
排队管理与推荐引擎
智能排队、等待时间预估、菜品推荐

使用方式:
    python queue_manager.py --output queue_status.json
"""

import argparse
import json
import sys
from datetime import datetime, timedelta
from typing import Dict, List
import numpy as np


class QueueManager:
    """排队管理引擎"""
    
    def __init__(self):
        self.table_types = {
            'small': {'seats': 2, 'count': 10, 'avg_dining_time': 45},
            'medium': {'seats': 4, 'count': 8, 'avg_dining_time': 60},
            'large': {'seats': 6, 'count': 5, 'avg_dining_time': 75},
            'vip': {'seats': 8, 'count': 2, 'avg_dining_time': 90}
        }
        
        self.queue = []
        self.current_number = 0
    
    def generate_queue_number(self, party_size: int, is_member: bool = False) -> Dict:
        """
        生成排队号
        
        参数:
            party_size: 用餐人数
            is_member: 是否会员
        """
        # 确定桌型
        if party_size <= 2:
            table_type = 'small'
        elif party_size <= 4:
            table_type = 'medium'
        elif party_size <= 6:
            table_type = 'large'
        else:
            table_type = 'vip'
        
        # 生成号码
        self.current_number += 1
        queue_number = f"{table_type[0].upper()}{self.current_number:03d}"
        
        # 计算预估等待时间
        wait_estimate = self._estimate_wait_time(table_type)
        
        # 创建排队记录
        queue_entry = {
            'queue_number': queue_number,
            'party_size': party_size,
            'table_type': table_type,
            'is_member': is_member,
            'check_in_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'estimated_wait_minutes': wait_estimate,
            'status': 'waiting'
        }
        
        # 会员优先
        if is_member:
            self.queue.insert(0, queue_entry)
        else:
            self.queue.append(queue_entry)
        
        return queue_entry
    
    def _estimate_wait_time(self, table_type: str) -> int:
        """预估等待时间"""
        # 简化算法：当前排队数 × 平均用餐时间
        type_queue = [q for q in self.queue if q['table_type'] == table_type]
        avg_time = self.table_types[table_type]['avg_dining_time']
        
        # 考虑桌数
        table_count = self.table_types[table_type]['count']
        
        wait_time = len(type_queue) * avg_time / table_count
        
        return int(wait_time)
    
    def get_queue_status(self) -> Dict:
        """获取排队状态"""
        status_by_type = {}
        
        for table_type in self.table_types.keys():
            type_queue = [q for q in self.queue if q['table_type'] == table_type]
            status_by_type[table_type] = {
                'waiting_count': len(type_queue),
                'estimated_wait': self._estimate_wait_time(table_type)
            }
        
        return {
            'timestamp': datetime.now().isoformat(),
            'total_waiting': len(self.queue),
            'by_table_type': status_by_type,
            'queue': self.queue
        }
    
    def call_number(self, queue_number: str) -> Dict:
        """叫号"""
        for i, entry in enumerate(self.queue):
            if entry['queue_number'] == queue_number:
                entry['status'] = 'called'
                entry['called_time'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                
                # 从队列移除
                called_entry = self.queue.pop(i)
                
                return {
                    'success': True,
                    'message': f"请 {queue_number} 号顾客入座",
                    'entry': called_entry
                }
        
        return {
            'success': False,
            'message': f"未找到 {queue_number} 号"
        }


class RecommendationEngine:
    """菜品推荐引擎"""
    
    def __init__(self):
        self.dishes = [
            {'id': 'D001', 'name': '宫保鸡丁', 'category': '热菜', 'price': 38, 'rating': 4.8, 'sales': 150, 'margin': 0.65},
            {'id': 'D002', 'name': '水煮鱼', 'category': '热菜', 'price': 68, 'rating': 4.7, 'sales': 120, 'margin': 0.60},
            {'id': 'D003', 'name': '蛋花汤', 'category': '汤品', 'price': 12, 'rating': 4.5, 'sales': 200, 'margin': 0.75},
            {'id': 'D004', 'name': '炒饭', 'category': '主食', 'price': 18, 'rating': 4.6, 'sales': 180, 'margin': 0.70}
        ]
    
    def recommend(self, context: Dict) -> List[Dict]:
        """
        智能推荐
        
        参数:
            context: {
                'party_size': 2,
                'is_member': True,
                'history': ['宫保鸡丁'],
                'time': 'lunch'
            }
        """
        recommendations = []
        
        # 1. 爆款推荐（高销量）
        hot_dishes = sorted(self.dishes, key=lambda x: x['sales'], reverse=True)[:3]
        
        # 2. 高毛利推荐
        high_margin = sorted(self.dishes, key=lambda x: x['margin'], reverse=True)[:3]
        
        # 3. 搭配推荐
        # 如果点了主菜，推荐汤品和主食
        if 'history' in context:
            has_main_dish = any(d['category'] == '热菜' for d in self.dishes if d['name'] in context['history'])
            if has_main_dish:
                soup_and_staple = [d for d in self.dishes if d['category'] in ['汤品', '主食']]
                recommendations.extend(soup_and_staple[:2])
        
        # 合并推荐
        all_recommended = hot_dishes + high_margin
        unique_recommended = {d['id']: d for d in all_recommended}.values()
        
        return {
            'hot_dishes': hot_dishes,
            'high_margin': high_margin,
            'pairing_recommendations': recommendations[:2],
            'all_recommendations': list(unique_recommended)[:5]
        }


def main():
    parser = argparse.ArgumentParser(description='排队管理工具')
    parser.add_argument('--output', type=str, default='queue_status.json', help='输出文件')
    
    args = parser.parse_args()
    
    queue_mgr = QueueManager()
    recommender = RecommendationEngine()
    
    try:
        # 模拟排队
        queue_mgr.generate_queue_number(2, is_member=False)
        queue_mgr.generate_queue_number(4, is_member=True)
        queue_mgr.generate_queue_number(3, is_member=False)
        
        # 获取状态
        status = queue_mgr.get_queue_status()
        
        # 生成推荐
        recommendations = recommender.recommend({
            'party_size': 2,
            'is_member': True,
            'history': ['宫保鸡丁'],
            'time': 'lunch'
        })
        
        result = {
            'queue_status': status,
            'recommendations': recommendations
        }
        
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        
        print(f"[SUCCESS] 排队状态已生成: {args.output}")
        print(f"\n[INFO] 排队概况:")
        print(f"  - 当前等待: {status['total_waiting']} 桌")
        print(f"  - 小桌等待: {status['by_table_type']['small']['waiting_count']} 桌")
        
        print(f"\n[RECOMMENDATION] 推荐菜品:")
        for dish in recommendations['hot_dishes'][:3]:
            print(f"  - {dish['name']} (¥{dish['price']}, 销量{dish['sales']})")
        
        return 0
        
    except Exception as e:
        print(f"[ERROR] 生成失败: {str(e)}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
