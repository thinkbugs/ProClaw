---
name: front-hall-service
description: 前厅智能化服务能力，包含智能迎宾、排队管理、点餐引导、满意度调查；当用户需要优化前厅服务效率、提升顾客体验时使用
author: ProClaw
author_url: https://www.ProClaw.top
dependency:
  python:
    - numpy==1.26.2
---

# 前厅服务Skill

## 任务目标
- 本Skill用于：前厅服务的智能化管理
- 能力包含：智能迎宾、排队管理、点餐引导、咨询应答、满意度调查
- 触发条件：服务优化、排队管理、顾客咨询、体验提升

## 操作步骤

### 标准流程

#### 1. 智能迎宾
- 顾客到店识别
- 排队取号引导
- 会员身份识别
- 个性化推荐

#### 2. 排队管理
- 智能排队算法
- 等待时间预估
- 座位分配优化
- 过号处理

#### 3. 点餐引导
- 扫码点餐引导
- 菜品推荐
- 口味备注
- 优惠活动介绍

#### 4. 满意度调查
- 餐后评价收集
- 问题反馈处理
- 持续改进

## 资源索引

### 必要脚本
- [scripts/queue_manager.py](scripts/queue_manager.py) - 排队管理与推荐引擎，支持智能排队、等待时间预估、菜品推荐，输出排队状态与推荐菜品

### 领域参考
- [references/service_sop.md](references/service_sop.md) - 服务SOP
- [references/queue_algorithm.md](references/queue_algorithm.md) - 排队算法

## 顶级玩家实战要点

### 1. 等待时间优化
- 准确预估等待时间
- 提供等位服务
- 减少顾客焦虑

### 2. 个性化服务
- 记住老顾客偏好
- 生日/纪念日关怀
- VIP专属服务

### 3. 服务效率
- 前厅人力优化
- 服务流程标准化
- 响应速度提升
