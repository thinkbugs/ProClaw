#!/usr/bin/env python3
"""
配方计算与成本卡生成引擎
标准化配方、成本核算、毛利率计算

使用方式:
    python recipe_calculator.py --dish-id D001 --output cost_card.json
"""

import argparse
import json
import sys
from datetime import datetime
from typing import Dict, List
import numpy as np


class RecipeCalculator:
    """配方计算引擎"""
    
    def __init__(self):
        self.ingredients = {
            'chicken_breast': {'name': '鸡胸肉', 'unit': 'kg', 'price': 25.0},
            'peanut': {'name': '花生', 'unit': 'kg', 'price': 12.0},
            'chili': {'name': '干辣椒', 'unit': 'kg', 'price': 30.0},
            'scallion': {'name': '葱', 'unit': 'kg', 'price': 6.0},
            'ginger': {'name': '姜', 'unit': 'kg', 'price': 8.0},
            'garlic': {'name': '蒜', 'unit': 'kg', 'price': 10.0},
            'soy_sauce': {'name': '酱油', 'unit': 'L', 'price': 15.0},
            'cooking_oil': {'name': '食用油', 'unit': 'L', 'price': 12.0}
        }
        
        self.recipes = {}
    
    def add_recipe(self, dish_id: str, dish_name: str, portion_size: int, 
                   ingredients: List[Dict], selling_price: float):
        """
        添加配方
        
        参数:
            dish_id: 菜品ID
            dish_name: 菜品名称
            portion_size: 份量（人份）
            ingredients: [
                {'ingredient_id': 'chicken_breast', 'quantity': 0.3},
                ...
            ]
            selling_price: 售价
        """
        self.recipes[dish_id] = {
            'dish_id': dish_id,
            'dish_name': dish_name,
            'portion_size': portion_size,
            'ingredients': ingredients,
            'selling_price': selling_price
        }
    
    def calculate_cost(self, dish_id: str) -> Dict:
        """计算成本"""
        if dish_id not in self.recipes:
            return {}
        
        recipe = self.recipes[dish_id]
        ingredient_costs = []
        total_cost = 0
        
        for item in recipe['ingredients']:
            ing_id = item['ingredient_id']
            qty = item['quantity']
            
            if ing_id not in self.ingredients:
                continue
            
            ing_info = self.ingredients[ing_id]
            cost = qty * ing_info['price']
            total_cost += cost
            
            ingredient_costs.append({
                'ingredient_id': ing_id,
                'name': ing_info['name'],
                'quantity': qty,
                'unit': ing_info['unit'],
                'unit_price': ing_info['price'],
                'total_cost': round(cost, 2)
            })
        
        selling_price = recipe['selling_price']
        gross_profit = selling_price - total_cost
        gross_margin = (gross_profit / selling_price) * 100 if selling_price > 0 else 0
        
        return {
            'dish_id': dish_id,
            'dish_name': recipe['dish_name'],
            'portion_size': recipe['portion_size'],
            'selling_price': selling_price,
            'total_cost': round(total_cost, 2),
            'gross_profit': round(gross_profit, 2),
            'gross_margin': round(gross_margin, 1),
            'ingredient_breakdown': ingredient_costs
        }
    
    def generate_cost_card(self, dish_id: str) -> Dict:
        """生成成本卡"""
        cost_info = self.calculate_cost(dish_id)
        
        if not cost_info:
            return {}
        
        # 成本结构分析
        cost_structure = {
            'raw_materials': cost_info['total_cost'],
            'seasoning': 0,  # 可细分
            'packaging': 2.0,  # 外卖包装费
            'labor_cost': cost_info['total_cost'] * 0.15  # 人工成本估算
        }
        
        total_operating_cost = sum(cost_structure.values())
        
        return {
            'dish_id': dish_id,
            'dish_name': cost_info['dish_name'],
            'generated_at': datetime.now().isoformat(),
            'pricing': {
                'selling_price': cost_info['selling_price'],
                'raw_material_cost': cost_info['total_cost'],
                'gross_profit': cost_info['gross_profit'],
                'gross_margin': f"{cost_info['gross_margin']}%"
            },
            'cost_breakdown': {
                'ingredients': cost_info['ingredient_breakdown'],
                'operating_costs': cost_structure,
                'total_operating_cost': round(total_operating_cost, 2)
            },
            'profit_analysis': {
                'net_profit': round(cost_info['selling_price'] - total_operating_cost, 2),
                'net_margin': round((cost_info['selling_price'] - total_operating_cost) / cost_info['selling_price'] * 100, 1)
            },
            'recommendations': self._generate_recommendations(cost_info)
        }
    
    def _generate_recommendations(self, cost_info: Dict) -> List[str]:
        """生成优化建议"""
        recommendations = []
        
        if cost_info['gross_margin'] < 60:
            recommendations.append(f"毛利率 {cost_info['gross_margin']}% 低于行业标准(65%)，建议调整定价或优化原料")
        
        if cost_info['gross_margin'] > 75:
            recommendations.append(f"毛利率 {cost_info['gross_margin']}% 较高，可考虑降低售价提升竞争力")
        
        # 找出成本最高的原料
        if cost_info['ingredient_breakdown']:
            highest_cost_item = max(cost_info['ingredient_breakdown'], 
                                   key=lambda x: x['total_cost'])
            recommendations.append(f"主要成本项: {highest_cost_item['name']} (¥{highest_cost_item['total_cost']})，可优化采购")
        
        return recommendations
    
    def batch_calculate(self, dish_ids: List[str] = None) -> Dict:
        """批量计算成本"""
        if dish_ids is None:
            dish_ids = list(self.recipes.keys())
        
        results = []
        for dish_id in dish_ids:
            if dish_id in self.recipes:
                results.append(self.calculate_cost(dish_id))
        
        # 排序：按毛利率从低到高
        results.sort(key=lambda x: x['gross_margin'])
        
        return {
            'timestamp': datetime.now().isoformat(),
            'total_dishes': len(results),
            'average_margin': round(np.mean([r['gross_margin'] for r in results]), 1) if results else 0,
            'dishes': results
        }


def main():
    parser = argparse.ArgumentParser(description='配方计算工具')
    parser.add_argument('--dish-id', type=str, help='指定菜品ID')
    parser.add_argument('--output', type=str, default='cost_card.json', help='输出文件')
    
    args = parser.parse_args()
    
    calculator = RecipeCalculator()
    
    # 添加示例配方
    calculator.add_recipe(
        dish_id='D001',
        dish_name='宫保鸡丁',
        portion_size=1,
        ingredients=[
            {'ingredient_id': 'chicken_breast', 'quantity': 0.25},
            {'ingredient_id': 'peanut', 'quantity': 0.05},
            {'ingredient_id': 'chili', 'quantity': 0.02},
            {'ingredient_id': 'scallion', 'quantity': 0.03},
            {'ingredient_id': 'ginger', 'quantity': 0.02},
            {'ingredient_id': 'garlic', 'quantity': 0.02},
            {'ingredient_id': 'soy_sauce', 'quantity': 0.03},
            {'ingredient_id': 'cooking_oil', 'quantity': 0.05}
        ],
        selling_price=38.0
    )
    
    calculator.add_recipe(
        dish_id='D002',
        dish_name='水煮鱼',
        portion_size=1,
        ingredients=[
            {'ingredient_id': 'chicken_breast', 'quantity': 0.35},
            {'ingredient_id': 'chili', 'quantity': 0.05},
            {'ingredient_id': 'soy_sauce', 'quantity': 0.05},
            {'ingredient_id': 'cooking_oil', 'quantity': 0.1}
        ],
        selling_price=68.0
    )
    
    try:
        if args.dish_id:
            # 单菜品成本卡
            result = calculator.generate_cost_card(args.dish_id)
            print(f"[INFO] 生成菜品 {args.dish_id} 成本卡")
        else:
            # 批量计算
            result = calculator.batch_calculate()
            print(f"[INFO] 批量计算 {result['total_dishes']} 个菜品成本")
        
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        
        print(f"[SUCCESS] 成本卡已生成: {args.output}")
        
        if 'dishes' in result:
            print(f"\n[COST ANALYSIS] 成本分析:")
            print(f"  - 平均毛利率: {result['average_margin']}%")
            for dish in result['dishes'][:3]:
                print(f"  - {dish['dish_name']}: 毛利率 {dish['gross_margin']}%")
        else:
            print(f"\n[COST CARD] 成本卡详情:")
            print(f"  - 售价: ¥{result['pricing']['selling_price']}")
            print(f"  - 成本: ¥{result['pricing']['raw_material_cost']}")
            print(f"  - 毛利: ¥{result['pricing']['gross_profit']}")
            print(f"  - 毛利率: {result['pricing']['gross_margin']}")
        
        return 0
        
    except Exception as e:
        print(f"[ERROR] 计算失败: {str(e)}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
