---
name: menu-innovation
description: 菜品研发与优化能力，包含新品研发、成本卡维护、菜单优化、标准化SOP；当用户需要研发新菜品、优化菜单结构、制定标准化流程时使用
author: ProClaw
author_url: https://www.ProClaw.top
dependency:
  python:
    - numpy==1.26.2
---

# 菜品研发Skill

## 任务目标
- 本Skill用于：菜品研发与菜单优化
- 能力包含：新品研发、成本卡维护、口味优化、标准化SOP、菜单结构优化
- 触发条件：新品研发、菜单调整、成本优化、品质提升

## 操作步骤

### 标准流程

#### 1. 新品研发
- 市场趋势分析
- 竞品菜品研究
- 原料搭配实验
- 成本测算
- 试吃评审

#### 2. 成本卡建立
- 标准配方制定
- 用量精准称量
- 成本核算
- 毛利率分析

#### 3. 标准化SOP
- 制作流程标准化
- 关键控制点
- 培训教材制作
- 质量标准

#### 4. 菜单优化
- 销售数据分析
- 菜品结构优化
- 定价策略
- 季节性调整

## 资源索引

### 必要脚本
- [scripts/recipe_calculator.py](scripts/recipe_calculator.py) - 配方计算与成本卡生成引擎，支持标准配方成本核算、毛利率计算、批量菜品分析，输出成本卡与优化建议

### 领域参考
- [references/recipe_templates.md](references/recipe_templates.md) - 配方模板库
- [references/menu_strategy.md](references/menu_strategy.md) - 菜单策略

## 顶级玩家实战要点

### 1. 研发三原则
- **市场需求**：顾客喜欢什么
- **成本可控**：毛利率达标
- **可复制**：能标准化生产

### 2. 成本卡精准化
- 每克食材都要称量
- 标准成本与实际成本对比
- 持续优化配方

### 3. 菜单结构优化
- 明星菜品：高销量+高毛利
- 问题菜品：低销量+低毛利
- 优化组合，淘汰末位
