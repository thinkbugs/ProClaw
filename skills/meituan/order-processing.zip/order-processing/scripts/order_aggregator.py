#!/usr/bin/env python3
"""
订单聚合与智能合并引擎
多渠道订单接入、订单合并、异常处理

使用方式:
    python order_aggregator.py --channels meituan,eleme --output orders.json
"""

import argparse
import json
import sys
from datetime import datetime
from typing import Dict, List
import numpy as np


class OrderAggregator:
    """订单聚合引擎"""
    
    def __init__(self):
        self.channels = {
            'meituan': {'name': '美团外卖', 'commission_rate': 0.20},
            'eleme': {'name': '饿了么', 'commission_rate': 0.18},
            'dine_in': {'name': '堂食', 'commission_rate': 0}
        }
    
    def aggregate_orders(self, channel_orders: Dict[str, List]) -> Dict:
        """
        聚合多渠道订单
        
        参数:
            channel_orders: {
                'meituan': [order1, order2, ...],
                'eleme': [order3, ...],
                'dine_in': [order4, ...]
            }
        """
        all_orders = []
        
        for channel, orders in channel_orders.items():
            if channel not in self.channels:
                continue
            
            channel_info = self.channels[channel]
            
            for order in orders:
                # 标准化订单格式
                standardized = {
                    'order_id': order.get('order_id', ''),
                    'channel': channel,
                    'channel_name': channel_info['name'],
                    'order_time': order.get('order_time', ''),
                    'customer_name': order.get('customer_name', ''),
                    'table_number': order.get('table_number', ''),
                    'dishes': order.get('dishes', []),
                    'total_amount': order.get('total_amount', 0),
                    'commission': round(order.get('total_amount', 0) * channel_info['commission_rate'], 2),
                    'remark': order.get('remark', ''),
                    'priority': order.get('priority', 1),  # 1=普通, 2=催单, 3=外卖
                    'status': 'pending'
                }
                
                all_orders.append(standardized)
        
        # 按优先级和时间排序
        all_orders.sort(key=lambda x: (-x['priority'], x['order_time']))
        
        return {
            'timestamp': datetime.now().isoformat(),
            'total_orders': len(all_orders),
            'by_channel': {
                channel: len(orders) for channel, orders in channel_orders.items()
            },
            'orders': all_orders
        }
    
    def merge_similar_orders(self, orders: List[Dict]) -> Dict:
        """
        智能合并相似订单
        
        合并规则：
        1. 同桌订单合并
        2. 同菜品批量制作
        3. 同渠道优先处理
        """
        # 按桌号分组（堂食）
        table_groups = {}
        other_orders = []
        
        for order in orders:
            if order['channel'] == 'dine_in' and order.get('table_number'):
                table = order['table_number']
                if table not in table_groups:
                    table_groups[table] = []
                table_groups[table].append(order)
            else:
                other_orders.append(order)
        
        # 合并同桌订单
        merged_orders = []
        
        for table, table_order_list in table_groups.items():
            if len(table_order_list) == 1:
                merged_orders.append(table_order_list[0])
                continue
            
            # 合并菜品
            merged_dishes = {}
            for order in table_order_list:
                for dish in order['dishes']:
                    dish_name = dish['name']
                    if dish_name not in merged_dishes:
                        merged_dishes[dish_name] = {
                            'name': dish_name,
                            'quantity': 0,
                            'remarks': []
                        }
                    merged_dishes[dish_name]['quantity'] += dish.get('quantity', 1)
                    if dish.get('remark'):
                        merged_dishes[dish_name]['remarks'].append(dish['remark'])
            
            merged_order = {
                'order_id': f"MERGED-{table}",
                'channel': 'dine_in',
                'channel_name': '堂食',
                'table_number': table,
                'dishes': list(merged_dishes.values()),
                'total_amount': sum(o['total_amount'] for o in table_order_list),
                'merged_from': [o['order_id'] for o in table_order_list],
                'status': 'merged'
            }
            
            merged_orders.append(merged_order)
        
        # 合并外卖同菜品（批量制作）
        takeout_orders = [o for o in other_orders if o['channel'] in ['meituan', 'eleme']]
        dine_out_orders = [o for o in other_orders if o['channel'] not in ['meituan', 'eleme']]
        
        # 按菜品分组外卖订单
        dish_groups = {}
        for order in takeout_orders:
            for dish in order['dishes']:
                dish_name = dish['name']
                if dish_name not in dish_groups:
                    dish_groups[dish_name] = []
                dish_groups[dish_name].append({
                    'order_id': order['order_id'],
                    'channel': order['channel'],
                    'quantity': dish.get('quantity', 1)
                })
        
        return {
            'timestamp': datetime.now().isoformat(),
            'original_orders': len(orders),
            'merged_orders': len(merged_orders) + len(dine_out_orders),
            'merged_table_orders': len(merged_orders),
            'takeout_dish_groups': dish_groups,
            'orders': merged_orders + dine_out_orders,
            'merge_savings': {
                'reduced_tasks': len(orders) - len(merged_orders) - len(dine_out_orders),
                'efficiency_gain': f"{round((1 - (len(merged_orders) + len(dine_out_orders)) / len(orders)) * 100, 1)}%"
            }
        }


def main():
    parser = argparse.ArgumentParser(description='订单聚合工具')
    parser.add_argument('--output', type=str, default='orders.json', help='输出文件')
    
    args = parser.parse_args()
    
    aggregator = OrderAggregator()
    
    # 示例订单数据
    sample_orders = {
        'meituan': [
            {
                'order_id': 'MT001',
                'order_time': '2024-01-15 12:05:00',
                'customer_name': '张先生',
                'dishes': [
                    {'name': '宫保鸡丁', 'quantity': 1, 'price': 38},
                    {'name': '蛋花汤', 'quantity': 1, 'price': 12}
                ],
                'total_amount': 50,
                'priority': 3
            }
        ],
        'dine_in': [
            {
                'order_id': 'DT001',
                'order_time': '2024-01-15 12:10:00',
                'table_number': 'A01',
                'dishes': [
                    {'name': '宫保鸡丁', 'quantity': 1, 'price': 38}
                ],
                'total_amount': 38,
                'priority': 1
            },
            {
                'order_id': 'DT002',
                'order_time': '2024-01-15 12:12:00',
                'table_number': 'A01',
                'dishes': [
                    {'name': '炒饭', 'quantity': 1, 'price': 18}
                ],
                'total_amount': 18,
                'priority': 1
            }
        ]
    }
    
    try:
        # 聚合订单
        aggregated = aggregator.aggregate_orders(sample_orders)
        
        # 合并订单
        merged = aggregator.merge_similar_orders(aggregated['orders'])
        
        result = {
            'aggregation': aggregated,
            'merging': merged
        }
        
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        
        print(f"[SUCCESS] 订单聚合完成: {args.output}")
        print(f"\n[INFO] 聚合结果:")
        print(f"  - 原始订单: {merged['original_orders']} 个")
        print(f"  - 合并后: {merged['merged_orders']} 个")
        print(f"  - 效率提升: {merged['merge_savings']['efficiency_gain']}")
        
        return 0
        
    except Exception as e:
        print(f"[ERROR] 聚合失败: {str(e)}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
