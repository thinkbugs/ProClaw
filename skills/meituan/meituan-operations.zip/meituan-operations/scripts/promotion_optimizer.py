#!/usr/bin/env python3
"""
美团推广策略优化引擎
计算推广ROI、优化关键词出价、预算分配

使用方式:
    python promotion_optimizer.py --budget 1000 --output plan.json
"""

import argparse
import json
import sys
from datetime import datetime
from typing import Dict, List
import numpy as np


class PromotionOptimizer:
    """推广策略优化引擎"""
    
    def __init__(self):
        self.promotion_types = {
            'cpc': {
                'name': '推广通(CPC)',
                'description': '按点击付费，提升曝光',
                'avg_cpc': 1.5,  # 平均点击成本
                'avg_ctr': 3.5,  # 平均点击率
                'target_roi': 3.0
            },
            'super_group': {
                'name': '超级团购',
                'description': '团购专属曝光位',
                'avg_cost': 200,  # 单次活动成本
                'target_roi': 4.0
            },
            'keyword_bidding': {
                'name': '竞价排名',
                'description': '关键词竞价排名',
                'avg_cpc': 2.0,
                'target_roi': 3.5
            }
        }
    
    def calculate_roi(self, cost: float, revenue: float) -> float:
        """计算ROI"""
        return round(revenue / cost, 2) if cost > 0 else 0
    
    def estimate_exposure(self, budget: float, avg_cpc: float, 
                         ctr: float, conversion_rate: float,
                         avg_ticket: float) -> Dict:
        """估算推广效果"""
        # 点击数
        clicks = int(budget / avg_cpc)
        
        # 曝光数
        impressions = int(clicks / (ctr / 100))
        
        # 订单数
        orders = int(clicks * (conversion_rate / 100))
        
        # 预估收入
        revenue = orders * avg_ticket
        
        # ROI
        roi = self.calculate_roi(budget, revenue)
        
        return {
            'budget': budget,
            'impressions': impressions,
            'clicks': clicks,
            'orders': orders,
            'revenue': round(revenue, 2),
            'roi': roi,
            'cost_per_order': round(budget / orders, 2) if orders > 0 else 0
        }
    
    def optimize_budget_allocation(self, total_budget: float, 
                                    channels: List[Dict]) -> Dict:
        """
        优化预算分配
        
        参数:
            total_budget: 总预算
            channels: [
                {
                    'channel': 'cpc',
                    'min_budget': 200,
                    'max_budget': 500,
                    'priority': 1
                }
            ]
        """
        # 按优先级排序
        sorted_channels = sorted(channels, key=lambda x: x['priority'])
        
        allocations = []
        remaining_budget = total_budget
        
        for channel in sorted_channels:
            channel_type = channel['channel']
            if channel_type not in self.promotion_types:
                continue
            
            # 分配预算
            min_budget = channel.get('min_budget', 100)
            max_budget = channel.get('max_budget', total_budget * 0.5)
            
            # 根据剩余预算和限制分配
            allocated = min(max_budget, max(min_budget, remaining_budget * 0.5))
            
            if allocated < min_budget:
                continue  # 预算不足，跳过该渠道
            
            # 估算效果
            promotion_info = self.promotion_types[channel_type]
            if channel_type == 'cpc':
                estimate = self.estimate_exposure(
                    allocated,
                    promotion_info['avg_cpc'],
                    promotion_info['avg_ctr'],
                    12,  # 转化率
                    60   # 客单价
                )
            else:
                estimate = {
                    'budget': allocated,
                    'revenue': allocated * promotion_info['target_roi'],
                    'roi': promotion_info['target_roi']
                }
            
            allocations.append({
                'channel': channel_type,
                'channel_name': promotion_info['name'],
                'budget': round(allocated, 2),
                'estimate': estimate
            })
            
            remaining_budget -= allocated
        
        # 计算总体效果
        total_revenue = sum(a['estimate']['revenue'] for a in allocations)
        total_roi = self.calculate_roi(total_budget, total_revenue)
        
        return {
            'total_budget': total_budget,
            'allocations': allocations,
            'total_revenue': round(total_revenue, 2),
            'overall_roi': total_roi,
            'recommendation': '继续优化' if total_roi < 3.0 else '表现良好'
        }
    
    def suggest_keywords(self, business_type: str) -> List[Dict]:
        """推荐关键词"""
        # 简化版关键词推荐
        keyword_templates = {
            '快餐': [
                {'keyword': '附近快餐', 'relevance': 95, 'suggested_bid': 1.8},
                {'keyword': '快餐外卖', 'relevance': 90, 'suggested_bid': 1.5},
                {'keyword': '便宜快餐', 'relevance': 85, 'suggested_bid': 1.2}
            ],
            '正餐': [
                {'keyword': '附近餐厅', 'relevance': 95, 'suggested_bid': 2.0},
                {'keyword': '聚餐餐厅', 'relevance': 90, 'suggested_bid': 1.8},
                {'keyword': '特色菜', 'relevance': 85, 'suggested_bid': 1.5}
            ]
        }
        
        return keyword_templates.get(business_type, [])


def main():
    parser = argparse.ArgumentParser(description='美团推广策略优化工具')
    parser.add_argument('--budget', type=float, default=1000, help='总预算')
    parser.add_argument('--output', type=str, default='promotion_plan.json', help='输出文件')
    
    args = parser.parse_args()
    
    optimizer = PromotionOptimizer()
    
    # 示例渠道配置
    channels = [
        {'channel': 'cpc', 'min_budget': 300, 'max_budget': 600, 'priority': 1},
        {'channel': 'super_group', 'min_budget': 200, 'max_budget': 400, 'priority': 2},
        {'channel': 'keyword_bidding', 'min_budget': 100, 'max_budget': 300, 'priority': 3}
    ]
    
    try:
        plan = optimizer.optimize_budget_allocation(args.budget, channels)
        
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(plan, f, ensure_ascii=False, indent=2)
        
        print(f"[SUCCESS] 推广计划已生成: {args.output}")
        print(f"\n[INFO] 核心指标:")
        print(f"  - 总预算: ¥{plan['total_budget']}")
        print(f"  - 预估收入: ¥{plan['total_revenue']}")
        print(f"  - 预估ROI: {plan['overall_roi']}")
        
        print(f"\n[ALLOCATION] 预算分配:")
        for alloc in plan['allocations']:
            print(f"  - {alloc['channel_name']}: ¥{alloc['budget']} (ROI: {alloc['estimate']['roi']})")
        
        return 0
        
    except Exception as e:
        print(f"[ERROR] 生成失败: {str(e)}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
