#!/usr/bin/env python3
"""
美团开放平台API对接引擎
订单管理、门店管理、经营数据同步

使用方式:
    python meituan_api_client.py --action get_orders --output meituan_data.json

注意：此脚本需要OAuth授权，使用前请确保已配置美团开放平台凭证
"""

import argparse
import json
import sys
import os
from datetime import datetime, timedelta
from typing import Dict, List
import hashlib
import time

# 必须从 coze-workload-identity 导入
from coze_workload_identity import requests


class MeituanAPIClient:
    """美团开放平台API客户端"""
    
    def __init__(self):
        """
        初始化客户端
        
        凭证Key: COZE_MEITUAN_OAUTH_<skill_id>
        """
        self.skill_id = "7618908246174335028"  # 替换为实际skill_id
        self.access_token = os.getenv(f"COZE_MEITUAN_OAUTH_{self.skill_id}")
        
        # 美团开放平台API地址
        self.base_url = "https://api-open-cater.meituan.com"
        
        # API端点
        self.endpoints = {
            'get_orders': '/api/order/query',
            'get_shop_info': '/api/poi/query',
            'get_business_data': '/api/data/business',
            'update_shop_status': '/api/poi/updateStatus'
        }
    
    def _check_token(self) -> bool:
        """检查token是否有效"""
        if not self.access_token:
            print("[ERROR] 未配置美团OAuth凭证，请先完成授权")
            print("[INFO] 请在Skill配置中添加美团开放平台OAuth凭证")
            return False
        return True
    
    def _generate_signature(self, params: Dict, timestamp: int) -> str:
        """
        生成签名
        
        参数:
            params: 请求参数
            timestamp: 时间戳
        """
        # 按字典序排序参数
        sorted_params = sorted(params.items())
        param_str = '&'.join([f"{k}={v}" for k, v in sorted_params])
        
        # 拼接timestamp
        sign_str = f"{param_str}&timestamp={timestamp}"
        
        # SHA1签名
        signature = hashlib.sha1(sign_str.encode()).hexdigest()
        
        return signature
    
    def get_orders(self, start_date: str = None, end_date: str = None, 
                   page: int = 1, page_size: int = 50) -> Dict:
        """
        查询订单列表
        
        参数:
            start_date: 开始日期 (YYYY-MM-DD)
            end_date: 结束日期 (YYYY-MM-DD)
            page: 页码
            page_size: 每页数量
        """
        if not self._check_token():
            return {'error': '未授权'}
        
        # 构建请求参数
        timestamp = int(time.time())
        
        params = {
            'appAuthToken': self.access_token,
            'timestamp': timestamp,
            'startDate': start_date or (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d'),
            'endDate': end_date or datetime.now().strftime('%Y-%m-%d'),
            'pageNo': page,
            'pageSize': page_size
        }
        
        # 生成签名
        params['sign'] = self._generate_signature(params, timestamp)
        
        # 发起请求
        url = f"{self.base_url}{self.endpoints['get_orders']}"
        
        try:
            response = requests.post(url, json=params, timeout=30)
            
            if response.status_code >= 400:
                return {'error': f'HTTP错误: {response.status_code}', 'detail': response.text}
            
            data = response.json()
            
            # 检查API错误
            if data.get('code') != 0:
                return {'error': data.get('msg', 'API错误'), 'code': data.get('code')}
            
            return {
                'success': True,
                'timestamp': datetime.now().isoformat(),
                'orders': data.get('data', {}).get('orders', []),
                'total': data.get('data', {}).get('total', 0),
                'page': page,
                'page_size': page_size
            }
            
        except requests.exceptions.RequestException as e:
            return {'error': f'请求失败: {str(e)}'}
    
    def get_shop_info(self, shop_id: str = None) -> Dict:
        """
        查询门店信息
        
        参数:
            shop_id: 门店ID (不传则查询所有授权门店)
        """
        if not self._check_token():
            return {'error': '未授权'}
        
        timestamp = int(time.time())
        
        params = {
            'appAuthToken': self.access_token,
            'timestamp': timestamp
        }
        
        if shop_id:
            params['shopId'] = shop_id
        
        params['sign'] = self._generate_signature(params, timestamp)
        
        url = f"{self.base_url}{self.endpoints['get_shop_info']}"
        
        try:
            response = requests.post(url, json=params, timeout=30)
            
            if response.status_code >= 400:
                return {'error': f'HTTP错误: {response.status_code}'}
            
            data = response.json()
            
            if data.get('code') != 0:
                return {'error': data.get('msg', 'API错误')}
            
            return {
                'success': True,
                'timestamp': datetime.now().isoformat(),
                'shop_info': data.get('data', {})
            }
            
        except requests.exceptions.RequestException as e:
            return {'error': f'请求失败: {str(e)}'}
    
    def get_business_data(self, date: str = None) -> Dict:
        """
        查询经营数据
        
        参数:
            date: 查询日期 (YYYY-MM-DD)
        """
        if not self._check_token():
            return {'error': '未授权'}
        
        timestamp = int(time.time())
        
        params = {
            'appAuthToken': self.access_token,
            'timestamp': timestamp,
            'date': date or datetime.now().strftime('%Y-%m-%d')
        }
        
        params['sign'] = self._generate_signature(params, timestamp)
        
        url = f"{self.base_url}{self.endpoints['get_business_data']}"
        
        try:
            response = requests.post(url, json=params, timeout=30)
            
            if response.status_code >= 400:
                return {'error': f'HTTP错误: {response.status_code}'}
            
            data = response.json()
            
            if data.get('code') != 0:
                return {'error': data.get('msg', 'API错误')}
            
            return {
                'success': True,
                'timestamp': datetime.now().isoformat(),
                'business_data': {
                    'order_count': data.get('data', {}).get('orderCount', 0),
                    'total_revenue': data.get('data', {}).get('totalRevenue', 0),
                    'valid_order_count': data.get('data', {}).get('validOrderCount', 0),
                    'avg_order_value': data.get('data', {}).get('avgOrderValue', 0)
                }
            }
            
        except requests.exceptions.RequestException as e:
            return {'error': f'请求失败: {str(e)}'}
    
    def sync_daily_data(self) -> Dict:
        """同步当日数据"""
        if not self._check_token():
            return {'error': '未授权'}
        
        # 获取门店信息
        shop_info = self.get_shop_info()
        
        # 获取经营数据
        business_data = self.get_business_data()
        
        # 获取订单列表
        orders = self.get_orders()
        
        return {
            'timestamp': datetime.now().isoformat(),
            'shop_info': shop_info.get('shop_info', {}),
            'business_data': business_data.get('business_data', {}),
            'orders': orders.get('orders', [])
        }


def main():
    parser = argparse.ArgumentParser(description='美团API对接工具')
    parser.add_argument('--action', type=str, default='sync', 
                       choices=['get_orders', 'get_shop', 'get_business', 'sync'],
                       help='操作类型')
    parser.add_argument('--output', type=str, default='meituan_data.json', help='输出文件')
    
    args = parser.parse_args()
    
    client = MeituanAPIClient()
    
    # 模拟数据（当未配置凭证时返回模拟数据）
    mock_data = {
        'timestamp': datetime.now().isoformat(),
        'message': '模拟数据（未配置OAuth凭证）',
        'shop_info': {
            'shop_id': 'S001',
            'name': '示例餐厅',
            'address': '北京市朝阳区...',
            'status': '营业中'
        },
        'business_data': {
            'order_count': 156,
            'total_revenue': 18500.00,
            'valid_order_count': 150,
            'avg_order_value': 123.33
        },
        'orders': [
            {
                'order_id': 'MT20240115001',
                'order_time': '2024-01-15 12:05:00',
                'customer_name': '张先生',
                'total_amount': 88.00,
                'status': '已完成'
            }
        ]
    }
    
    try:
        if client._check_token():
            # 真实API调用
            if args.action == 'get_orders':
                result = client.get_orders()
            elif args.action == 'get_shop':
                result = client.get_shop_info()
            elif args.action == 'get_business':
                result = client.get_business_data()
            else:
                result = client.sync_daily_data()
        else:
            # 返回模拟数据
            result = mock_data
        
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        
        print(f"[SUCCESS] 数据已生成: {args.output}")
        
        if 'error' in result:
            print(f"\n[WARNING] {result['error']}")
            print(f"[INFO] 返回模拟数据用于测试")
        
        if 'business_data' in result:
            print(f"\n[BUSINESS DATA] 经营数据:")
            bd = result['business_data']
            print(f"  - 订单数: {bd.get('order_count', 0)}")
            print(f"  - 营业额: ¥{bd.get('total_revenue', 0):.2f}")
            print(f"  - 客单价: ¥{bd.get('avg_order_value', 0):.2f}")
        
        return 0
        
    except Exception as e:
        print(f"[ERROR] 操作失败: {str(e)}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
