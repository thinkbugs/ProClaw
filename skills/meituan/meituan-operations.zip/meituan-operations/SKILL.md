---
name: meituan-operations
description: 美团平台全链路运营能力，包含流量运营、活动设计、付费推广、评价管理；当用户需要优化美团店铺曝光转化、策划活动、投放推广或管理评价时使用
author: ProClaw
author_url: https://www.ProClaw.top
dependency:
  python:
    - numpy==1.26.2
---

# 美团平台运营Skill

## 任务目标
- 本Skill用于：美团平台的精细化运营与增长
- 能力包含：流量运营、活动设计、付费推广、评价管理、数据分析
- 触发条件：平台运营需求、活动策划、推广投放、评价处理

## 前置准备
- 依赖说明：scripts脚本所需的依赖包及版本
  ```
  numpy==1.26.2
  ```

## 操作步骤

### 标准流程

#### 1. 店铺诊断
- 智能体根据 `references/platform_rules.md` 进行店铺体检
- 诊断维度：
  - 店铺装修完整度
  - 菜单设计合理性
  - 活动参与度
  - 评分与评价
- 输出诊断报告与优化建议

#### 2. 流量运营
- 曝光优化：
  - 店铺排名优化
  - 搜索关键词优化
  - 主图优化（点击率提升）
- 转化优化：
  - 进店转化率提升
  - 下单转化率提升
  - 客单价提升

**核心公式**：
```
曝光量 = 搜索流量 + 推荐流量 + 活动流量
进店量 = 曝光量 × 进店率
订单量 = 进店量 × 转化率
GMV = 订单量 × 客单价
```

#### 3. 活动设计
- 智能体参考 `references/activity_templates.md` 设计活动
- 活动类型：
  - **满减活动**：门槛设置、档位设计
  - **折扣活动**：折扣力度、菜品选择
  - **套餐活动**：套餐组合、定价策略
  - **会员活动**：会员权益、积分规则
- 计算ROI，选择最优方案

#### 4. 付费推广
- 调用 `scripts/promotion_optimizer.py` 优化推广策略
- 推广类型：
  - **推广通**：按CPC付费，提升曝光
  - **超级团购**：团购专属曝光
  - **竞价排名**：关键词竞价
- 目标：ROI > 3.0

#### 5. 评价管理
- 调用 `scripts/review_analyzer.py` 分析评价
- 好评管理：感谢回复、引导晒图
- 差评处理：及时回复、问题整改、顾客挽回
- 目标：评分 > 4.8，好评率 > 98%

### 可选分支

#### 分支A：新店冷启动
- 30天新店扶持期优化
- 快速积累评价与销量
- 建立基础流量池

#### 分支B：老店翻新
- 店铺装修升级
- 菜单结构优化
- 活动策略调整

#### 分支C：大促活动策划
- 节日活动方案
- 资源预算分配
- 效果预估与复盘

## 资源索引

### 必要脚本
- [scripts/meituan_api_client.py](scripts/meituan_api_client.py) - 美团开放平台API对接引擎，支持订单管理、门店管理、经营数据同步（需OAuth授权）
- [scripts/promotion_optimizer.py](scripts/promotion_optimizer.py) - 推广策略优化
- [scripts/review_analyzer.py](scripts/review_analyzer.py) - 评价情感分析
- [scripts/activity_calculator.py](scripts/activity_calalyzer.py) - 活动ROI计算

### 领域参考
- [references/platform_rules.md](references/platform_rules.md) - 美团平台规则解读
- [references/activity_templates.md](references/activity_templates.md) - 活动设计案例库
- [references/promotion_strategy.md](references/promotion_strategy.md) - 付费推广策略

### 输出资产
- 店铺诊断报告
- 活动策划方案
- 推广优化建议
- 评价管理报告

## 注意事项

### 平台规则遵守
- 严格遵守美团平台规则
- 不刷单、不刷评价
- 活动价格不低于成本价

### 数据驱动决策
- 用数据验证每个决策
- A/B测试找到最优方案
- 持续优化，小步快跑

### 成本控制
- 推广ROI > 3.0
- 活动毛利率 > 50%
- 避免无效投入

### 与其他Agent协作
- 发现转化率低 → 触发菜品研发Agent优化菜单
- 发现评价问题 → 触发前厅服务Agent改进服务
- 发现成本异常 → 触发成本管控Agent控制成本

## 使用示例

### 示例1：店铺诊断
```bash
# 智能体读取店铺数据，生成诊断报告
# 分析维度：曝光、点击、转化、评价
# 输出优化建议
```

### 示例2：活动设计
```bash
# 计算活动ROI
python scripts/activity_calculator.py --activity "满30减10" --output roi.json

# 智能体解读并给出建议
```

### 示例3：评价分析
```bash
# 分析近期评价
python scripts/review_analyzer.py --days 7 --output review_report.json

# 智能体给出回复建议
```

## 顶级玩家实战要点

### 1. 流量漏斗优化
```
曝光 → 点击 → 进店 → 下单 → 复购

每个环节都有优化空间：
- 曝光：排名优化、关键词优化
- 点击：主图优化、标题优化
- 进店：活动吸引、评分提升
- 下单：菜品优化、价格策略
- 复购：会员运营、私域维护
```

### 2. 活动设计黄金法则
- **门槛设置**：比平均客单价高10-20%
- **折扣力度**：保证毛利率 > 50%
- **活动组合**：满减+折扣+会员，多维度吸引

### 3. 推广投放策略
- **测试期**：小预算测试，找到最优关键词
- **放量期**：增加预算，扩大投放
- **优化期**：调整出价，提升ROI

### 4. 评价管理SOP
- **好评**：24小时内回复，感谢+引导晒图
- **中评**：48小时内回复，道歉+改进承诺
- **差评**：2小时内回复，道歉+补偿+整改
