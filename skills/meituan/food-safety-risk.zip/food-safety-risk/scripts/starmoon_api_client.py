#!/usr/bin/env python3
"""
美团星眸API对接引擎
后厨AI巡检、食品安全预警、风险识别

使用方式:
    python starmoon_api_client.py --action inspect_kitchen --output starmoon_data.json

注意：此脚本需要OAuth授权，使用前请确保已配置美团星眸API凭证
"""

import argparse
import json
import sys
import os
from datetime import datetime, timedelta
from typing import Dict, List
import hashlib
import time

# 必须从 coze-workload-identity 导入
from coze_workload_identity import requests


class StarmoonAPIClient:
    """美团星眸API客户端"""
    
    def __init__(self):
        """
        初始化客户端
        
        凭证Key: COZE_STARMOON_OAUTH_<skill_id>
        """
        self.skill_id = "7618908246174335028"  # 替换为实际skill_id
        self.access_token = os.getenv(f"COZE_STARMOON_OAUTH_{self.skill_id}")
        
        # 星眸API地址
        self.base_url = "https://api-open-cater.meituan.com/starmoon"
        
        # 风险类型定义
        self.risk_types = {
            'no_hat': {'name': '未戴工帽', 'level': 'warning', 'score': -5},
            'garbage_overflow': {'name': '垃圾溢出', 'level': 'warning', 'score': -8},
            'violation': {'name': '违规操作', 'level': 'critical', 'score': -15},
            'smoking': {'name': '抽烟', 'level': 'critical', 'score': -20},
            'mouse': {'name': '鼠害', 'level': 'critical', 'score': -30},
            'cockroach': {'name': '蟑螂', 'level': 'critical', 'score': -25},
            'no_mask': {'name': '未戴口罩', 'level': 'warning', 'score': -5},
            'improper_storage': {'name': '食材存放不当', 'level': 'warning', 'score': -10}
        }
    
    def _check_token(self) -> bool:
        """检查token是否有效"""
        if not self.access_token:
            print("[ERROR] 未配置星眸OAuth凭证，请先完成授权")
            print("[INFO] 请在Skill配置中添加美团星眸API OAuth凭证")
            return False
        return True
    
    def inspect_kitchen(self, shop_id: str = None) -> Dict:
        """
        后厨AI巡检
        
        参数:
            shop_id: 门店ID (不传则查询所有授权门店)
        """
        if not self._check_token():
            return {'error': '未授权'}
        
        timestamp = int(time.time())
        
        params = {
            'appAuthToken': self.access_token,
            'timestamp': timestamp,
            'action': 'inspect'
        }
        
        if shop_id:
            params['shopId'] = shop_id
        
        try:
            # 真实API调用
            response = requests.post(
                f"{self.base_url}/kitchen/inspect",
                json=params,
                timeout=30
            )
            
            if response.status_code >= 400:
                return {'error': f'HTTP错误: {response.status_code}'}
            
            data = response.json()
            
            if data.get('code') != 0:
                return {'error': data.get('msg', 'API错误')}
            
            return {
                'success': True,
                'timestamp': datetime.now().isoformat(),
                'inspection_results': data.get('data', {})
            }
            
        except requests.exceptions.RequestException as e:
            return {'error': f'请求失败: {str(e)}'}
    
    def get_risk_alerts(self, shop_id: str = None, start_date: str = None, 
                        end_date: str = None) -> Dict:
        """
        获取风险预警列表
        
        参数:
            shop_id: 门店ID
            start_date: 开始日期
            end_date: 结束日期
        """
        if not self._check_token():
            return {'error': '未授权'}
        
        timestamp = int(time.time())
        
        params = {
            'appAuthToken': self.access_token,
            'timestamp': timestamp,
            'startDate': start_date or (datetime.now() - timedelta(days=7)).strftime('%Y-%m-%d'),
            'endDate': end_date or datetime.now().strftime('%Y-%m-%d')
        }
        
        if shop_id:
            params['shopId'] = shop_id
        
        try:
            response = requests.post(
                f"{self.base_url}/risk/alerts",
                json=params,
                timeout=30
            )
            
            if response.status_code >= 400:
                return {'error': f'HTTP错误: {response.status_code}'}
            
            data = response.json()
            
            if data.get('code') != 0:
                return {'error': data.get('msg', 'API错误')}
            
            return {
                'success': True,
                'timestamp': datetime.now().isoformat(),
                'alerts': data.get('data', {}).get('alerts', [])
            }
            
        except requests.exceptions.RequestException as e:
            return {'error': f'请求失败: {str(e)}'}
    
    def calculate_safety_score(self, shop_id: str = None) -> Dict:
        """
        计算食品安全评分
        
        评分规则：
        - 基础分：100分
        - 每个warning级别风险：-5到-10分
        - 每个critical级别风险：-15到-30分
        - 最低分：0分
        """
        if not self._check_token():
            return {'error': '未授权'}
        
        # 获取预警数据
        alerts_result = self.get_risk_alerts(shop_id)
        
        if 'error' in alerts_result:
            return alerts_result
        
        alerts = alerts_result.get('alerts', [])
        
        # 计算评分
        base_score = 100
        deductions = []
        
        for alert in alerts:
            risk_type = alert.get('type')
            if risk_type in self.risk_types:
                risk_info = self.risk_types[risk_type]
                deduction = abs(risk_info['score'])
                base_score += risk_info['score']
                
                deductions.append({
                    'type': risk_type,
                    'name': risk_info['name'],
                    'level': risk_info['level'],
                    'deduction': deduction,
                    'count': alert.get('count', 1)
                })
        
        # 确保分数不低于0
        final_score = max(base_score, 0)
        
        # 确定等级
        if final_score >= 90:
            grade = 'A'
            status = '优秀'
        elif final_score >= 80:
            grade = 'B'
            status = '良好'
        elif final_score >= 70:
            grade = 'C'
            status = '合格'
        elif final_score >= 60:
            grade = 'D'
            status = '待改进'
        else:
            grade = 'E'
            status = '高风险'
        
        return {
            'timestamp': datetime.now().isoformat(),
            'shop_id': shop_id,
            'safety_score': final_score,
            'grade': grade,
            'status': status,
            'deductions': deductions,
            'total_alerts': len(alerts),
            'critical_alerts': sum(1 for d in deductions if d['level'] == 'critical'),
            'warning_alerts': sum(1 for d in deductions if d['level'] == 'warning')
        }
    
    def generate_improvement_plan(self, shop_id: str = None) -> Dict:
        """生成整改计划"""
        score_result = self.calculate_safety_score(shop_id)
        
        if 'error' in score_result:
            return score_result
        
        improvements = []
        
        for deduction in score_result.get('deductions', []):
            improvement = self._get_improvement_action(deduction['type'])
            improvements.append({
                'risk_type': deduction['type'],
                'risk_name': deduction['name'],
                'level': deduction['level'],
                'action': improvement,
                'deadline': (datetime.now() + timedelta(days=3 if deduction['level'] == 'critical' else 7)).strftime('%Y-%m-%d'),
                'priority': '高' if deduction['level'] == 'critical' else '中'
            })
        
        return {
            'timestamp': datetime.now().isoformat(),
            'shop_id': shop_id,
            'current_score': score_result['safety_score'],
            'grade': score_result['grade'],
            'improvement_plan': sorted(improvements, key=lambda x: x['priority']),
            'expected_score_after_improvement': min(score_result['safety_score'] + 20, 100)
        }
    
    def _get_improvement_action(self, risk_type: str) -> str:
        """获取整改建议"""
        actions = {
            'no_hat': '全员佩戴工帽，设置检查机制',
            'garbage_overflow': '及时清理垃圾，增加垃圾桶容量',
            'violation': '培训员工规范操作，加强监督',
            'smoking': '严禁后厨吸烟，设置吸烟区',
            'mouse': '联系专业除虫公司，封堵鼠洞',
            'cockroach': '专业消杀，清理卫生死角',
            'no_mask': '全员佩戴口罩，定期检查',
            'improper_storage': '规范食材存放，生熟分开'
        }
        return actions.get(risk_type, '加强管理，定期检查')


def main():
    parser = argparse.ArgumentParser(description='星眸API对接工具')
    parser.add_argument('--action', type=str, default='inspect',
                       choices=['inspect', 'alerts', 'score', 'plan'],
                       help='操作类型')
    parser.add_argument('--output', type=str, default='starmoon_data.json', help='输出文件')
    
    args = parser.parse_args()
    
    client = StarmoonAPIClient()
    
    # 模拟数据（当未配置凭证时返回模拟数据）
    mock_data = {
        'timestamp': datetime.now().isoformat(),
        'message': '模拟数据（未配置OAuth凭证）',
        'safety_score': 85,
        'grade': 'B',
        'status': '良好',
        'alerts': [
            {
                'type': 'no_hat',
                'name': '未戴工帽',
                'level': 'warning',
                'count': 2,
                'location': '后厨A区'
            },
            {
                'type': 'garbage_overflow',
                'name': '垃圾溢出',
                'level': 'warning',
                'count': 1,
                'location': '后厨B区'
            }
        ],
        'improvement_plan': [
            {
                'risk_name': '未戴工帽',
                'action': '全员佩戴工帽，设置检查机制',
                'priority': '中',
                'deadline': (datetime.now() + timedelta(days=7)).strftime('%Y-%m-%d')
            }
        ]
    }
    
    try:
        if client._check_token():
            # 真实API调用
            if args.action == 'inspect':
                result = client.inspect_kitchen()
            elif args.action == 'alerts':
                result = client.get_risk_alerts()
            elif args.action == 'score':
                result = client.calculate_safety_score()
            else:
                result = client.generate_improvement_plan()
        else:
            # 返回模拟数据
            result = mock_data
        
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        
        print(f"[SUCCESS] 数据已生成: {args.output}")
        
        if 'error' in result:
            print(f"\n[WARNING] {result['error']}")
            print(f"[INFO] 返回模拟数据用于测试")
        
        if 'safety_score' in result:
            print(f"\n[SAFETY SCORE] 食品安全评分:")
            print(f"  - 评分: {result['safety_score']}分")
            print(f"  - 等级: {result['grade']} ({result['status']})")
        
        if 'alerts' in result:
            print(f"\n[ALERTS] 风险预警:")
            for alert in result['alerts'][:3]:
                print(f"  - [{alert['level'].upper()}] {alert['name']}: {alert.get('count', 1)}次")
        
        return 0
        
    except Exception as e:
        print(f"[ERROR] 操作失败: {str(e)}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
