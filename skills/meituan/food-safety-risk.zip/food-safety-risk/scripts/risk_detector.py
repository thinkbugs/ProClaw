#!/usr/bin/env python3
"""
食品安全风险检测引擎
违规识别、风险预警、事件管理

使用方式:
    python risk_detector.py --mode realtime --output report.json
"""

import argparse
import json
import sys
from datetime import datetime
from typing import Dict, List
import numpy as np


class RiskDetector:
    """食品安全风险检测引擎"""
    
    def __init__(self):
        self.risk_types = {
            'pest': {
                'name': '有害生物',
                'items': ['老鼠', '蟑螂', '苍蝇', '蚊子'],
                'severity': 'critical',
                'threshold': 0.85  # 置信度阈值
            },
            'hygiene': {
                'name': '卫生问题',
                'items': ['垃圾桶满溢', '地面积水', '油污', '杂物堆积'],
                'severity': 'high',
                'threshold': 0.80
            },
            'behavior': {
                'name': '行为违规',
                'items': ['未戴帽', '未戴口罩', '吸烟', '玩手机', '徒手接触食品'],
                'severity': 'medium',
                'threshold': 0.75
            },
            'operation': {
                'name': '操作违规',
                'items': ['生熟不分', '温度异常', '交叉污染', '过期食材'],
                'severity': 'critical',
                'threshold': 0.90
            }
        }
        
        self.severity_levels = {
            'critical': {'level': 1, 'name': '严重', 'response_time': 5},
            'high': {'level': 2, 'name': '高', 'response_time': 15},
            'medium': {'level': 3, 'name': '中', 'response_time': 30},
            'low': {'level': 4, 'name': '低', 'response_time': 60}
        }
    
    def detect_risks(self, detection_data: List[Dict]) -> Dict:
        """
        风险检测
        
        参数:
            detection_data: [
                {
                    'timestamp': '2024-01-15 14:23:15',
                    'area': 'cooking_area',
                    'type': 'pest',
                    'item': '老鼠',
                    'confidence': 0.965
                }
            ]
        """
        detected_risks = []
        
        for data in detection_data:
            risk_type = data['type']
            if risk_type not in self.risk_types:
                continue
            
            risk_info = self.risk_types[risk_type]
            confidence = data['confidence']
            
            # 检查是否超过阈值
            if confidence < risk_info['threshold']:
                continue
            
            # 确定严重程度
            severity_info = self.severity_levels[risk_info['severity']]
            
            # 生成风险事件
            risk_event = {
                'event_id': f"RISK-{datetime.now().strftime('%Y%m%d%H%M%S')}",
                'timestamp': data['timestamp'],
                'area': data['area'],
                'risk_type': risk_type,
                'risk_name': risk_info['name'],
                'item': data['item'],
                'confidence': confidence,
                'severity': risk_info['severity'],
                'severity_name': severity_info['name'],
                'response_time_minutes': severity_info['response_time'],
                'status': 'pending',
                'actions': self._suggest_actions(risk_type, data['item'])
            }
            
            detected_risks.append(risk_event)
        
        # 按严重程度排序
        detected_risks.sort(key=lambda x: self.severity_levels[x['severity']]['level'])
        
        return {
            'timestamp': datetime.now().isoformat(),
            'total_risks': len(detected_risks),
            'by_severity': self._count_by_severity(detected_risks),
            'risks': detected_risks
        }
    
    def _suggest_actions(self, risk_type: str, item: str) -> List[str]:
        """建议处置措施"""
        action_map = {
            'pest': [
                '立即排查可能入侵点',
                '联系专业除虫公司',
                '清理周边环境',
                '设置捕鼠设施'
            ],
            'hygiene': [
                '立即清理整改',
                '通知相关人员',
                '加强日常清洁',
                '建立清洁台账'
            ],
            'behavior': [
                '现场纠正违规行为',
                '记录并教育',
                '加强培训',
                '纳入考核'
            ],
            'operation': [
                '立即停止相关操作',
                '隔离问题食材',
                '培训正确操作流程',
                '建立操作检查机制'
            ]
        }
        
        return action_map.get(risk_type, ['立即处理', '记录备案'])
    
    def _count_by_severity(self, risks: List[Dict]) -> Dict:
        """按严重程度统计"""
        count = {level: 0 for level in self.severity_levels.keys()}
        
        for risk in risks:
            count[risk['severity']] += 1
        
        return count
    
    def generate_report(self, detection_results: Dict) -> Dict:
        """生成风险报告"""
        # 识别的风险
        risks = detection_results.get('risks', [])
        
        # 整改建议
        recommendations = []
        for risk in risks:
            recommendations.append({
                'priority': self.severity_levels[risk['severity']]['level'],
                'issue': f"{risk['area']}发现{risk['item']}",
                'severity': risk['severity_name'],
                'actions': risk['actions']
            })
        
        return {
            'timestamp': datetime.now().isoformat(),
            'summary': {
                'total_risks': len(risks),
                'critical': detection_results['by_severity']['critical'],
                'high': detection_results['by_severity']['high'],
                'medium': detection_results['by_severity']['medium'],
                'low': detection_results['by_severity']['low']
            },
            'risks': risks,
            'recommendations': recommendations
        }


def main():
    parser = argparse.ArgumentParser(description='食品安全风险检测工具')
    parser.add_argument('--mode', type=str, default='batch', choices=['batch', 'realtime'], help='检测模式')
    parser.add_argument('--output', type=str, default='risk_report.json', help='输出文件')
    
    args = parser.parse_args()
    
    detector = RiskDetector()
    
    # 示例检测数据
    sample_detections = [
        {
            'timestamp': '2024-01-15 14:23:15',
            'area': 'cooking_area',
            'type': 'pest',
            'item': '老鼠',
            'confidence': 0.965
        },
        {
            'timestamp': '2024-01-15 14:25:30',
            'area': 'storage_area',
            'type': 'hygiene',
            'item': '垃圾桶满溢',
            'confidence': 0.82
        },
        {
            'timestamp': '2024-01-15 14:28:45',
            'area': 'cooking_area',
            'type': 'behavior',
            'item': '未戴口罩',
            'confidence': 0.88
        }
    ]
    
    try:
        # 检测风险
        detection_results = detector.detect_risks(sample_detections)
        
        # 生成报告
        report = detector.generate_report(detection_results)
        
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        
        print(f"[SUCCESS] 风险报告已生成: {args.output}")
        print(f"\n[INFO] 风险概览:")
        print(f"  - 总风险数: {report['summary']['total_risks']}")
        print(f"  - 严重: {report['summary']['critical']}")
        print(f"  - 高: {report['summary']['high']}")
        print(f"  - 中: {report['summary']['medium']}")
        
        if report['risks']:
            print(f"\n[ALERT] 检测到的风险:")
            for risk in report['risks'][:3]:
                print(f"  - [{risk['severity_name']}] {risk['area']}: {risk['item']}")
        
        return 0
        
    except Exception as e:
        print(f"[ERROR] 检测失败: {str(e)}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
