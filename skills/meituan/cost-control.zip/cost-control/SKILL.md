---
name: cost-control
description: 践行萨利亚式杜绝浪费理念，实现食材、人力、能耗成本的精细管控；当用户需要进行成本核算、损耗分析、浪费识别或优化成本结构时使用
author: ProClaw
author_url: https://www.ProClaw.top
dependency:
  python:
    - numpy==1.26.2
---

# 餐饮门店成本管控Skill

## 任务目标
- 本Skill用于：餐饮门店全成本链路的精细化管理与优化
- 能力包含：成本核算、损耗分析、人力优化、能耗监控、浪费根因分析
- 触发条件：成本分析需求、损耗异常、人力成本过高、能耗超标、浪费识别

## 前置准备
- 依赖说明：scripts脚本所需的依赖包及版本
  ```
  numpy==1.26.2
  ```

## 操作步骤

### 标准流程

#### 1. 食材成本核算
- 建立标准成本卡（每道菜的理论成本）
- 计算实际成本与标准成本偏差
- 调用 `scripts/cost_calculator.py` 进行成本核算
- 智能体根据 `references/cost_standards.md` 判断合理性

**核心公式**：
```
食材成本率 = 食材成本 / 营业额 × 100%
毛利率 = (营业额 - 食材成本) / 营业额 × 100%
成本偏差率 = (实际成本 - 标准成本) / 标准成本 × 100%
```

#### 2. 损耗分析与浪费识别
- 调用 `scripts/waste_analyzer.py` 进行损耗分析
- 损耗类型识别：
  - **加工损耗**：食材预处理过程中的损耗
  - **储存损耗**：过期、变质导致的损耗
  - **出品损耗**：退菜、做错导致的损耗
  - **管理损耗**：盘点差异、记录缺失
- 输出损耗清单与根因分析

**萨利亚式浪费识别**：
- 目标损耗率：< 1%
- 预警损耗率：> 2%
- 严重损耗率：> 3%

#### 3. 人力成本优化
- 调用 `scripts/labor_optimizer.py` 进行排班优化
- 分析维度：
  - 时段人效（营业额/人）
  - 工时利用率
  - 加班成本占比
- 输出优化建议

**人力成本控制要点**：
- 以30分钟为单位精细排班
- 高峰时段充足人手，低峰时段精简人力
- 灵活用工占比控制在30-40%

#### 4. 能耗监控
- 监控水、电、燃气消耗
- 识别异常能耗（打烊后设备未关）
- 生成节能建议

**能耗标准**：
- 电费：< 营业额的2%
- 水费：< 营业额的0.5%
- 燃气费：< 营业额的1.5%

#### 5. 成本优化方案生成
- 智能体综合分析各项成本数据
- 输出优化方案：
  - 短期措施（立即执行）
  - 中期措施（1-4周）
  - 长期措施（1-3个月）

### 可选分支

#### 分支A：专项损耗诊断
- 当某食材损耗率>3%时，触发深度诊断
- 穿透分析：从采购→储存→加工→出品全链路排查

#### 分支B：人力成本专项优化
- 当人力成本率>25%时，触发人力优化
- 分析排班合理性、人效、加班情况

#### 分支C：能耗异常排查
- 当能耗成本异常升高时，排查设备使用情况
- 识别浪费点并制定节能方案

## 资源索引

### 必要脚本
- [scripts/cost_calculator.py](scripts/cost_calculator.py) - 成本核算引擎，支持标准成本计算、实际成本对比、偏差分析
- [scripts/waste_analyzer.py](scripts/waste_analyzer.py) - 损耗分析工具，识别加工/储存/出品/管理损耗，输出根因分析
- [scripts/cost_optimizer.py](scripts/cost_optimizer.py) - 成本优化引擎，支持成本结构分析、优化建议生成、实时预警、决策支持
- [scripts/waste_analyzer.py](scripts/waste_analyzer.py) - 损耗分析算法
- [scripts/labor_optimizer.py](scripts/labor_optimizer.py) - 人力优化算法

### 领域参考
- [references/cost_standards.md](references/cost_standards.md) - 餐饮成本控制标准
- [references/waste_case_library.md](references/waste_case_library.md) - 损耗案例库
- [references/salearna_philosophy.md](references/salearna_philosophy.md) - 萨利亚成本哲学

### 输出资产
- 成本核算报告
- 损耗分析报告
- 人力优化建议
- 节能方案
- 成本控制月报

## 注意事项

### 数据准确性要求
- 成本数据必须准确到分
- 盘点数据必须真实
- 损耗记录必须及时

### 成本控制原则
1. **杜绝浪费**：每一分成本都要有价值
2. **精细管理**：以菜品、时段为单位精细核算
3. **持续优化**：每周复盘，每月改进
4. **全员参与**：成本控制是每个人的责任

### 与其他Agent协作
- 发现食材成本异常 → 触发采购供应链Agent
- 发现出品损耗高 → 触发后厨生产Agent
- 发现人力成本高 → 触发店长Agent

## 使用示例

### 示例1：日成本核算
```bash
# 计算今日成本
python scripts/cost_calculator.py --date 2024-01-15 --output cost_report.json

# 分析损耗
python scripts/waste_analyzer.py --input cost_report.json --output waste_report.json

# 智能体解读并给出优化建议
```

### 示例2：周度成本分析
```bash
# 生成周报
python scripts/cost_calculator.py --start 2024-01-08 --end 2024-01-14 --output weekly_cost.json

# 分析损耗趋势
python scripts/waste_analyzer.py --mode trend --input weekly_cost.json

# 智能体提出改进方案
```

### 示例3：人力优化
```bash
# 分析人力成本
python scripts/labor_optimizer.py --date 2024-01-15 --output labor_report.json

# 智能体给出排班优化建议
```

## 顶级玩家实战要点

### 1. 萨利亚式成本哲学
- "利润是挤出来的，不是赚出来的"
- 每一分成本都要有价值，没有价值的成本就是浪费
- 成本控制不是省钱，而是用更优的方式创造价值

### 2. 从核算到管控
- 不要只做成本核算，要做成本管控
- 核算是事后，管控是事前和事中
- 建立"预警-干预-验证"闭环

### 3. 根因穿透
- 发现损耗不要止步于"有损耗"
- 穿透分析：为什么有损耗？是哪个环节？谁的责任？
- 制定针对性的改进措施

### 4. 成本与品质平衡
- 成本控制不能牺牲品质
- 顾客体验是底线
- 用更聪明的方式降低成本，而不是简单削减

### 5. 数据驱动决策
- 用数据说话，不用感觉决策
- 建立成本基线，识别异常
- 持续监控，快速迭代
