#!/usr/bin/env python3
"""
餐饮门店成本核算引擎
实现标准成本法，计算成本偏差，支持多维度成本分析

使用方式:
    python cost_calculator.py --date 2024-01-15 --output cost_report.json
    python cost_calculator.py --start 2024-01-01 --end 2024-01-07 --output weekly.json
"""

import argparse
import json
import sys
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import numpy as np


class CostCalculator:
    """餐饮门店成本核算引擎"""
    
    def __init__(self):
        self.standard_costs = {}  # 标准成本卡
        self.cost_targets = {
            'food_cost_ratio': 30.0,  # 目标食材成本率
            'labor_cost_ratio': 20.0,  # 目标人力成本率
            'energy_cost_ratio': 4.0,  # 目标能耗成本率
            'total_cost_ratio': 65.0   # 目标总成本率
        }
    
    def load_standard_cost_card(self, dishes: List[Dict]) -> None:
        """
        加载标准成本卡
        
        参数:
            dishes: 菜品标准成本列表
            [
                {
                    'dish_id': '001',
                    'dish_name': '宫保鸡丁',
                    'standard_cost': 12.5,  # 标准食材成本
                    'ingredients': [
                        {'name': '鸡肉', 'quantity': 150, 'unit': 'g', 'cost': 6.0},
                        {'name': '花生', 'quantity': 30, 'unit': 'g', 'cost': 1.5},
                        ...
                    ]
                }
            ]
        """
        for dish in dishes:
            self.standard_costs[dish['dish_id']] = dish
    
    def calculate_dish_cost(self, dish_id: str, quantity: int, 
                            actual_cost: Optional[float] = None) -> Dict:
        """
        计算单品成本
        
        返回:
            {
                'dish_id': '001',
                'dish_name': '宫保鸡丁',
                'quantity': 10,
                'standard_cost': 125.0,
                'actual_cost': 130.0,
                'cost_variance': 5.0,
                'cost_variance_ratio': 4.0
            }
        """
        if dish_id not in self.standard_costs:
            return {
                'dish_id': dish_id,
                'error': '未找到标准成本卡'
            }
        
        dish = self.standard_costs[dish_id]
        standard_cost = dish['standard_cost'] * quantity
        
        result = {
            'dish_id': dish_id,
            'dish_name': dish['dish_name'],
            'quantity': quantity,
            'standard_cost': round(standard_cost, 2)
        }
        
        if actual_cost is not None:
            variance = actual_cost - standard_cost
            variance_ratio = (variance / standard_cost * 100) if standard_cost > 0 else 0
            
            result.update({
                'actual_cost': round(actual_cost, 2),
                'cost_variance': round(variance, 2),
                'cost_variance_ratio': round(variance_ratio, 2),
                'variance_level': self._classify_variance(variance_ratio)
            })
        
        return result
    
    def _classify_variance(self, variance_ratio: float) -> str:
        """分类成本偏差程度"""
        abs_ratio = abs(variance_ratio)
        if abs_ratio < 5:
            return 'normal'
        elif abs_ratio < 10:
            return 'slight'
        elif abs_ratio < 20:
            return 'moderate'
        else:
            return 'severe'
    
    def calculate_daily_cost(self, data: Dict) -> Dict:
        """
        计算日成本
        
        参数:
            data: {
                'date': '2024-01-15',
                'revenue': 15000,
                'food_cost': 4500,
                'labor_cost': 2500,
                'energy_cost': 600,
                'other_cost': 400,
                'dishes': [
                    {'dish_id': '001', 'quantity': 10, 'actual_cost': 130.0}
                ]
            }
        """
        revenue = data.get('revenue', 0)
        if revenue <= 0:
            raise ValueError("营业额必须大于0")
        
        # 总成本
        total_cost = (data.get('food_cost', 0) + 
                     data.get('labor_cost', 0) + 
                     data.get('energy_cost', 0) + 
                     data.get('other_cost', 0))
        
        # 成本结构
        cost_structure = {
            'food_cost': data.get('food_cost', 0),
            'food_cost_ratio': round(data.get('food_cost', 0) / revenue * 100, 2),
            'labor_cost': data.get('labor_cost', 0),
            'labor_cost_ratio': round(data.get('labor_cost', 0) / revenue * 100, 2),
            'energy_cost': data.get('energy_cost', 0),
            'energy_cost_ratio': round(data.get('energy_cost', 0) / revenue * 100, 2),
            'other_cost': data.get('other_cost', 0),
            'other_cost_ratio': round(data.get('other_cost', 0) / revenue * 100, 2),
            'total_cost': round(total_cost, 2),
            'total_cost_ratio': round(total_cost / revenue * 100, 2)
        }
        
        # 毛利
        gross_profit = revenue - data.get('food_cost', 0)
        net_profit = revenue - total_cost
        
        # 成本偏差分析
        cost_variances = []
        for key, target in self.cost_targets.items():
            actual = cost_structure.get(key, 0)
            variance = actual - target
            variance_ratio = (variance / target * 100) if target > 0 else 0
            
            cost_variances.append({
                'metric': key,
                'target': target,
                'actual': actual,
                'variance': round(variance, 2),
                'variance_ratio': round(variance_ratio, 2),
                'status': 'good' if abs(variance) < 2 else 'warning' if abs(variance) < 5 else 'alert'
            })
        
        # 菜品成本分析
        dish_costs = []
        if 'dishes' in data:
            for dish in data['dishes']:
                dish_cost = self.calculate_dish_cost(
                    dish['dish_id'],
                    dish['quantity'],
                    dish.get('actual_cost')
                )
                dish_costs.append(dish_cost)
        
        return {
            'date': data.get('date', ''),
            'timestamp': datetime.now().isoformat(),
            'revenue': revenue,
            'cost_structure': cost_structure,
            'profitability': {
                'gross_profit': round(gross_profit, 2),
                'gross_margin': round(gross_profit / revenue * 100, 2),
                'net_profit': round(net_profit, 2),
                'net_margin': round(net_profit / revenue * 100, 2)
            },
            'cost_variances': cost_variances,
            'dish_costs': dish_costs,
            'cost_alerts': self._generate_cost_alerts(cost_structure)
        }
    
    def _generate_cost_alerts(self, cost_structure: Dict) -> List[Dict]:
        """生成成本预警"""
        alerts = []
        
        # 食材成本预警
        if cost_structure['food_cost_ratio'] > 35:
            alerts.append({
                'level': 'high',
                'type': 'food_cost',
                'message': f"食材成本率{cost_structure['food_cost_ratio']}%，超过目标值35%",
                'recommendation': '检查采购价格、损耗率、出品标准化'
            })
        elif cost_structure['food_cost_ratio'] > 32:
            alerts.append({
                'level': 'medium',
                'type': 'food_cost',
                'message': f"食材成本率{cost_structure['food_cost_ratio']}%，接近预警线",
                'recommendation': '关注食材成本趋势，及时干预'
            })
        
        # 人力成本预警
        if cost_structure['labor_cost_ratio'] > 25:
            alerts.append({
                'level': 'high',
                'type': 'labor_cost',
                'message': f"人力成本率{cost_structure['labor_cost_ratio']}%，超过目标值25%",
                'recommendation': '优化排班，提升人效'
            })
        
        # 能耗成本预警
        if cost_structure['energy_cost_ratio'] > 5:
            alerts.append({
                'level': 'medium',
                'type': 'energy_cost',
                'message': f"能耗成本率{cost_structure['energy_cost_ratio']}%，超过目标值5%",
                'recommendation': '检查设备使用情况，优化能耗管理'
            })
        
        return alerts
    
    def calculate_cost_trend(self, historical_data: List[Dict]) -> Dict:
        """
        计算成本趋势
        
        参数:
            historical_data: 多日成本数据列表
        """
        if len(historical_data) < 3:
            return {'message': '数据量不足，无法分析趋势'}
        
        # 提取各项成本趋势
        food_costs = [d['cost_structure']['food_cost_ratio'] for d in historical_data]
        labor_costs = [d['cost_structure']['labor_cost_ratio'] for d in historical_data]
        total_costs = [d['cost_structure']['total_cost_ratio'] for d in historical_data]
        
        return {
            'food_cost_trend': {
                'values': food_costs,
                'avg': round(np.mean(food_costs), 2),
                'trend': 'rising' if food_costs[-1] > food_costs[0] else 'declining' if food_costs[-1] < food_costs[0] else 'stable'
            },
            'labor_cost_trend': {
                'values': labor_costs,
                'avg': round(np.mean(labor_costs), 2),
                'trend': 'rising' if labor_costs[-1] > labor_costs[0] else 'declining' if labor_costs[-1] < labor_costs[0] else 'stable'
            },
            'total_cost_trend': {
                'values': total_costs,
                'avg': round(np.mean(total_costs), 2),
                'trend': 'rising' if total_costs[-1] > total_costs[0] else 'declining' if total_costs[-1] < total_costs[0] else 'stable'
            }
        }


def main():
    parser = argparse.ArgumentParser(description='餐饮门店成本核算工具')
    parser.add_argument('--date', type=str, help='分析日期 (YYYY-MM-DD)')
    parser.add_argument('--output', type=str, default='cost_report.json', help='输出文件名')
    
    args = parser.parse_args()
    
    calculator = CostCalculator()
    
    # 示例标准成本卡
    standard_dishes = [
        {
            'dish_id': '001',
            'dish_name': '宫保鸡丁',
            'standard_cost': 12.5
        },
        {
            'dish_id': '002',
            'dish_name': '鱼香肉丝',
            'standard_cost': 11.0
        }
    ]
    calculator.load_standard_cost_card(standard_dishes)
    
    # 示例数据
    sample_data = {
        'date': args.date or datetime.now().strftime('%Y-%m-%d'),
        'revenue': 15000,
        'food_cost': 4500,
        'labor_cost': 2500,
        'energy_cost': 600,
        'other_cost': 400,
        'dishes': [
            {'dish_id': '001', 'quantity': 10, 'actual_cost': 130.0},
            {'dish_id': '002', 'quantity': 8, 'actual_cost': 92.0}
        ]
    }
    
    try:
        report = calculator.calculate_daily_cost(sample_data)
        
        # 输出结果
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        
        print(f"[SUCCESS] 成本核算报告已生成: {args.output}")
        print(f"\n[INFO] 核心指标:")
        print(f"  - 总成本率: {report['cost_structure']['total_cost_ratio']}%")
        print(f"  - 食材成本率: {report['cost_structure']['food_cost_ratio']}%")
        print(f"  - 人力成本率: {report['cost_structure']['labor_cost_ratio']}%")
        print(f"  - 毛利率: {report['profitability']['gross_margin']}%")
        print(f"  - 净利率: {report['profitability']['net_margin']}%")
        
        if report['cost_alerts']:
            print(f"\n[WARNING] 成本预警:")
            for alert in report['cost_alerts']:
                print(f"  - [{alert['level'].upper()}] {alert['message']}")
        
        return 0
        
    except Exception as e:
        print(f"[ERROR] 成本核算失败: {str(e)}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
