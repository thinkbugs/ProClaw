#!/usr/bin/env python3
"""
实时预警与优化决策引擎
成本预警、优化建议、决策支持

使用方式:
    python cost_optimizer.py --output optimization_report.json
"""

import argparse
import json
import sys
from datetime import datetime, timedelta
from typing import Dict, List
import numpy as np


class CostOptimizer:
    """成本优化引擎"""
    
    def __init__(self):
        self.cost_targets = {
            'food_cost_rate': {'target': 0.30, 'warning': 0.35, 'critical': 0.40},
            'labor_cost_rate': {'target': 0.20, 'warning': 0.25, 'critical': 0.30},
            'rent_cost_rate': {'target': 0.10, 'warning': 0.15, 'critical': 0.20},
            'utility_cost_rate': {'target': 0.03, 'warning': 0.05, 'critical': 0.08}
        }
        self.optimization_strategies = []
    
    def analyze_cost_structure(self, cost_data: Dict) -> Dict:
        """
        分析成本结构
        
        参数:
            cost_data: {
                'revenue': 50000,
                'food_cost': 16000,
                'labor_cost': 12000,
                'rent_cost': 6000,
                'utility_cost': 1500,
                'other_cost': 2500
            }
        """
        revenue = cost_data.get('revenue', 0)
        
        # 计算各项成本占比
        cost_rates = {
            'food_cost_rate': cost_data.get('food_cost', 0) / revenue if revenue > 0 else 0,
            'labor_cost_rate': cost_data.get('labor_cost', 0) / revenue if revenue > 0 else 0,
            'rent_cost_rate': cost_data.get('rent_cost', 0) / revenue if revenue > 0 else 0,
            'utility_cost_rate': cost_data.get('utility_cost', 0) / revenue if revenue > 0 else 0
        }
        
        # 评估各项成本
        evaluation = {}
        for cost_type, rate in cost_rates.items():
            target = self.cost_targets[cost_type]
            
            if rate >= target['critical']:
                status = 'critical'
            elif rate >= target['warning']:
                status = 'warning'
            elif rate <= target['target']:
                status = 'excellent'
            else:
                status = 'good'
            
            evaluation[cost_type] = {
                'current_rate': round(rate * 100, 1),
                'target_rate': round(target['target'] * 100, 1),
                'warning_rate': round(target['warning'] * 100, 1),
                'status': status,
                'gap_to_target': round((rate - target['target']) * 100, 1),
                'potential_savings': round((rate - target['target']) * revenue, 2) if rate > target['target'] else 0
            }
        
        # 总成本率
        total_cost_rate = sum(cost_rates.values())
        
        return {
            'timestamp': datetime.now().isoformat(),
            'total_cost_rate': round(total_cost_rate * 100, 1),
            'gross_margin': round((1 - total_cost_rate) * 100, 1),
            'cost_breakdown': evaluation,
            'total_potential_savings': sum(e['potential_savings'] for e in evaluation.values())
        }
    
    def generate_optimization_recommendations(self, analysis: Dict) -> List[Dict]:
        """生成优化建议"""
        recommendations = []
        
        for cost_type, data in analysis['cost_breakdown'].items():
            if data['status'] in ['critical', 'warning']:
                if cost_type == 'food_cost_rate':
                    recommendations.append({
                        'area': '食材成本',
                        'current': f"{data['current_rate']}%",
                        'target': f"{data['target_rate']}%",
                        'actions': [
                            '优化采购渠道，集中采购降低单价',
                            '减少食材浪费，提升利用率',
                            '调整菜品结构，提高高毛利菜品占比',
                            '建立标准配方，控制用量'
                        ],
                        'expected_savings': data['potential_savings'],
                        'priority': 'high' if data['status'] == 'critical' else 'medium'
                    })
                
                elif cost_type == 'labor_cost_rate':
                    recommendations.append({
                        'area': '人力成本',
                        'current': f"{data['current_rate']}%",
                        'target': f"{data['target_rate']}%",
                        'actions': [
                            '优化排班，高峰期集中人力',
                            '提升人效，培训多技能员工',
                            '引入智能化设备，减少重复劳动',
                            '优化服务流程，提高翻台率'
                        ],
                        'expected_savings': data['potential_savings'],
                        'priority': 'high' if data['status'] == 'critical' else 'medium'
                    })
                
                elif cost_type == 'utility_cost_rate':
                    recommendations.append({
                        'area': '能源成本',
                        'current': f"{data['current_rate']}%",
                        'target': f"{data['target_rate']}%",
                        'actions': [
                            '更换节能设备',
                            '优化空调使用策略',
                            '减少非营业时段能耗',
                            '定期维护设备，保持高效运转'
                        ],
                        'expected_savings': data['potential_savings'],
                        'priority': 'medium'
                    })
        
        return sorted(recommendations, key=lambda x: x['expected_savings'], reverse=True)
    
    def calculate_optimization_impact(self, recommendations: List[Dict]) -> Dict:
        """计算优化影响"""
        total_savings = sum(r['expected_savings'] for r in recommendations)
        
        high_priority_savings = sum(r['expected_savings'] for r in recommendations if r['priority'] == 'high')
        
        return {
            'total_potential_savings': round(total_savings, 2),
            'high_priority_savings': round(high_priority_savings, 2),
            'monthly_savings': round(total_savings * 30, 2),
            'yearly_savings': round(total_savings * 365, 2),
            'implementation_timeline': '2-4周',
            'roi': '预计1-2个月收回优化投入'
        }
    
    def generate_action_plan(self, recommendations: List[Dict]) -> List[Dict]:
        """生成行动计划"""
        action_plan = []
        
        for i, rec in enumerate(recommendations, 1):
            for j, action in enumerate(rec['actions'][:2], 1):  # 每个领域取前2个行动
                action_plan.append({
                    'id': f"A{i}.{j}",
                    'area': rec['area'],
                    'action': action,
                    'expected_savings': round(rec['expected_savings'] / 2, 2),
                    'priority': rec['priority'],
                    'deadline': (datetime.now() + timedelta(days=7*j)).strftime('%Y-%m-%d'),
                    'owner': '待指派',
                    'status': 'pending'
                })
        
        return action_plan


class RealtimeAlerter:
    """实时预警器"""
    
    def __init__(self):
        self.alert_rules = {
            'food_cost_spike': {
                'condition': 'food_cost_rate > 0.40',
                'level': 'critical',
                'message': '食材成本率超过40%，需立即采取措施'
            },
            'low_margin': {
                'condition': 'gross_margin < 0.35',
                'level': 'critical',
                'message': '毛利率低于35%，经营风险高'
            },
            'high_waste': {
                'condition': 'waste_rate > 0.05',
                'level': 'warning',
                'message': '食材浪费率超过5%，建议优化'
            }
        }
    
    def check_alerts(self, metrics: Dict) -> List[Dict]:
        """检查预警条件"""
        alerts = []
        
        # 食材成本预警
        if metrics.get('food_cost_rate', 0) > 0.40:
            alerts.append({
                'rule': 'food_cost_spike',
                'level': 'critical',
                'message': f"食材成本率 {metrics['food_cost_rate']*100:.1f}% 超过临界值40%",
                'timestamp': datetime.now().isoformat()
            })
        
        # 毛利率预警
        if metrics.get('gross_margin', 1) < 0.35:
            alerts.append({
                'rule': 'low_margin',
                'level': 'critical',
                'message': f"毛利率 {metrics['gross_margin']*100:.1f}% 低于35%",
                'timestamp': datetime.now().isoformat()
            })
        
        # 浪费预警
        if metrics.get('waste_rate', 0) > 0.05:
            alerts.append({
                'rule': 'high_waste',
                'level': 'warning',
                'message': f"食材浪费率 {metrics['waste_rate']*100:.1f}% 超过5%",
                'timestamp': datetime.now().isoformat()
            })
        
        return alerts


def main():
    parser = argparse.ArgumentParser(description='成本优化工具')
    parser.add_argument('--output', type=str, default='optimization_report.json', help='输出文件')
    
    args = parser.parse_args()
    
    optimizer = CostOptimizer()
    alerter = RealtimeAlerter()
    
    # 示例成本数据
    cost_data = {
        'revenue': 50000,
        'food_cost': 18000,
        'labor_cost': 11000,
        'rent_cost': 5000,
        'utility_cost': 2000,
        'other_cost': 2000
    }
    
    try:
        # 成本结构分析
        analysis = optimizer.analyze_cost_structure(cost_data)
        
        # 生成优化建议
        recommendations = optimizer.generate_optimization_recommendations(analysis)
        
        # 计算优化影响
        impact = optimizer.calculate_optimization_impact(recommendations)
        
        # 生成行动计划
        action_plan = optimizer.generate_action_plan(recommendations)
        
        # 实时预警
        metrics = {
            'food_cost_rate': cost_data['food_cost'] / cost_data['revenue'],
            'gross_margin': analysis['gross_margin'] / 100,
            'waste_rate': 0.03
        }
        alerts = alerter.check_alerts(metrics)
        
        result = {
            'timestamp': datetime.now().isoformat(),
            'cost_analysis': analysis,
            'optimization_recommendations': recommendations,
            'optimization_impact': impact,
            'action_plan': action_plan,
            'alerts': alerts
        }
        
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        
        print(f"[SUCCESS] 成本优化报告已生成: {args.output}")
        
        print(f"\n[COST STRUCTURE] 成本结构:")
        print(f"  - 总成本率: {analysis['total_cost_rate']}%")
        print(f"  - 毛利率: {analysis['gross_margin']}%")
        
        print(f"\n[OPTIMIZATION] 优化潜力:")
        print(f"  - 月度节省: ¥{impact['monthly_savings']}")
        print(f"  - 年度节省: ¥{impact['yearly_savings']}")
        
        if alerts:
            print(f"\n[ALERTS] 预警 ({len(alerts)} 个):")
            for alert in alerts:
                print(f"  - [{alert['level'].upper()}] {alert['message']}")
        
        return 0
        
    except Exception as e:
        print(f"[ERROR] 分析失败: {str(e)}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
