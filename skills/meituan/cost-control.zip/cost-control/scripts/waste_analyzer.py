#!/usr/bin/env python3
"""
餐饮门店损耗分析引擎
识别损耗类型、计算损耗率、根因分析

使用方式:
    python waste_analyzer.py --date 2024-01-15 --output waste_report.json
    python waste_analyzer.py --mode trend --input data.csv
"""

import argparse
import json
import sys
from datetime import datetime
from typing import Dict, List, Optional, Tuple
import numpy as np


class WasteAnalyzer:
    """餐饮门店损耗分析引擎"""
    
    def __init__(self):
        self.waste_types = {
            'processing': {
                'name': '加工损耗',
                'description': '食材预处理过程中的损耗',
                'typical_rate': 0.5,  # 正常损耗率
                'examples': ['去皮', '去骨', '切配损耗', '清洗损耗']
            },
            'storage': {
                'name': '储存损耗',
                'description': '储存过程中因过期、变质导致的损耗',
                'typical_rate': 0.3,
                'examples': ['过期报废', '变质损耗', '串味损耗', '干耗']
            },
            'production': {
                'name': '出品损耗',
                'description': '出品过程中的损耗',
                'typical_rate': 0.2,
                'examples': ['做错重做', '顾客退菜', '出品不达标']
            },
            'management': {
                'name': '管理损耗',
                'description': '管理不当导致的损耗',
                'typical_rate': 0.1,
                'examples': ['盘点差异', '记录缺失', '偷盗损耗']
            }
        }
        
        self.waste_thresholds = {
            'excellent': 1.0,  # 优秀损耗率
            'good': 2.0,       # 良好损耗率
            'warning': 3.0,    # 预警损耗率
            'alert': 5.0       # 严重损耗率
        }
    
    def classify_waste(self, waste_amount: float, total_purchase: float,
                       waste_details: Optional[Dict] = None) -> Dict:
        """
        分类损耗
        
        参数:
            waste_amount: 损耗金额
            total_purchase: 采购金额
            waste_details: 损耗明细
                {
                    'processing': 50.0,
                    'storage': 30.0,
                    'production': 20.0,
                    'management': 10.0
                }
        """
        waste_rate = (waste_amount / total_purchase * 100) if total_purchase > 0 else 0
        
        result = {
            'waste_amount': round(waste_amount, 2),
            'total_purchase': round(total_purchase, 2),
            'waste_rate': round(waste_rate, 2),
            'waste_level': self._classify_waste_level(waste_rate)
        }
        
        if waste_details:
            result['breakdown'] = {}
            for waste_type, amount in waste_details.items():
                if waste_type in self.waste_types:
                    type_rate = (amount / total_purchase * 100) if total_purchase > 0 else 0
                    result['breakdown'][waste_type] = {
                        'name': self.waste_types[waste_type]['name'],
                        'amount': round(amount, 2),
                        'rate': round(type_rate, 2),
                        'status': 'normal' if type_rate <= self.waste_types[waste_type]['typical_rate'] else 'high'
                    }
        
        return result
    
    def _classify_waste_level(self, waste_rate: float) -> str:
        """判定损耗等级"""
        if waste_rate <= self.waste_thresholds['excellent']:
            return 'excellent'
        elif waste_rate <= self.waste_thresholds['good']:
            return 'good'
        elif waste_rate <= self.waste_thresholds['warning']:
            return 'warning'
        else:
            return 'alert'
    
    def analyze_ingredient_waste(self, ingredient_data: List[Dict]) -> Dict:
        """
        分析食材损耗
        
        参数:
            ingredient_data: [
                {
                    'ingredient_name': '鸡肉',
                    'purchase_amount': 1000.0,
                    'actual_usage': 950.0,
                    'theoretical_usage': 900.0,
                    'waste_details': {
                        'processing': 30.0,
                        'storage': 15.0,
                        'production': 5.0
                    }
                }
            ]
        """
        analysis = []
        
        for item in ingredient_data:
            purchase = item.get('purchase_amount', 0)
            actual = item.get('actual_usage', 0)
            theoretical = item.get('theoretical_usage', 0)
            
            # 总损耗
            total_waste = purchase - actual
            waste_rate = (total_waste / purchase * 100) if purchase > 0 else 0
            
            # 异常损耗（超出理论用量的部分）
            abnormal_waste = actual - theoretical if actual > theoretical else 0
            
            # 损耗分类
            waste_classification = self.classify_waste(
                abs(total_waste),
                purchase,
                item.get('waste_details')
            )
            
            analysis.append({
                'ingredient_name': item.get('ingredient_name', ''),
                'purchase_amount': round(purchase, 2),
                'actual_usage': round(actual, 2),
                'theoretical_usage': round(theoretical, 2),
                'total_waste': round(abs(total_waste), 2),
                'waste_rate': round(waste_rate, 2),
                'abnormal_waste': round(abnormal_waste, 2),
                'waste_level': waste_classification['waste_level'],
                'breakdown': waste_classification.get('breakdown', {}),
                'root_cause': self._suggest_root_cause(waste_rate, item.get('waste_details', {}))
            })
        
        # 排序：按损耗率降序
        analysis.sort(key=lambda x: x['waste_rate'], reverse=True)
        
        return {
            'timestamp': datetime.now().isoformat(),
            'total_ingredients': len(analysis),
            'high_waste_items': len([a for a in analysis if a['waste_level'] in ['warning', 'alert']]),
            'analysis': analysis,
            'summary': self._generate_summary(analysis)
        }
    
    def _suggest_root_cause(self, waste_rate: float, waste_details: Dict) -> List[str]:
        """建议根因"""
        causes = []
        
        if waste_rate > 3.0:
            # 高损耗，需要深度分析
            max_type = max(waste_details.items(), key=lambda x: x[1]) if waste_details else (None, 0)
            
            if max_type[0] == 'processing':
                causes.append('加工损耗过高，检查刀工技术和出品标准')
            elif max_type[0] == 'storage':
                causes.append('储存损耗过高，检查储存条件和效期管理')
            elif max_type[0] == 'production':
                causes.append('出品损耗过高，检查出品质量和培训')
            elif max_type[0] == 'management':
                causes.append('管理损耗过高，检查盘点流程和库存管理')
        
        if waste_rate > 5.0:
            causes.append('损耗严重超标，建议立即核查')
        
        return causes
    
    def _generate_summary(self, analysis: List[Dict]) -> Dict:
        """生成损耗摘要"""
        if not analysis:
            return {}
        
        total_waste_rate = np.mean([a['waste_rate'] for a in analysis])
        
        # 识别问题食材
        problem_ingredients = [a for a in analysis if a['waste_level'] in ['warning', 'alert']]
        
        return {
            'avg_waste_rate': round(total_waste_rate, 2),
            'total_waste_amount': round(sum(a['total_waste'] for a in analysis), 2),
            'problem_ingredients_count': len(problem_ingredients),
            'top_waste_items': [a['ingredient_name'] for a in analysis[:3]],
            'overall_level': self._classify_waste_level(total_waste_rate),
            'salearna_target': 1.0,  # 萨利亚目标损耗率
            'gap_to_target': round(total_waste_rate - 1.0, 2)
        }
    
    def generate_waste_report(self, data: Dict) -> Dict:
        """
        生成损耗报告
        
        参数:
            data: {
                'date': '2024-01-15',
                'total_purchase': 10000.0,
                'total_waste': 150.0,
                'ingredients': [...]
            }
        """
        # 总体损耗分析
        overall = self.classify_waste(
            data.get('total_waste', 0),
            data.get('total_purchase', 1)
        )
        
        # 食材维度分析
        ingredient_analysis = self.analyze_ingredient_waste(data.get('ingredients', []))
        
        # 改进建议
        recommendations = self._generate_recommendations(overall, ingredient_analysis)
        
        return {
            'date': data.get('date', ''),
            'timestamp': datetime.now().isoformat(),
            'overall': overall,
            'ingredient_analysis': ingredient_analysis,
            'recommendations': recommendations,
            'salearna_philosophy': {
                'target_waste_rate': 1.0,
                'principle': '每一分成本都要有价值，杜绝浪费是利润的源泉',
                'action_required': overall['waste_rate'] > 2.0
            }
        }
    
    def _generate_recommendations(self, overall: Dict, ingredient_analysis: Dict) -> List[Dict]:
        """生成改进建议"""
        recommendations = []
        
        # 总体建议
        if overall['waste_rate'] > 2.0:
            recommendations.append({
                'priority': 'high',
                'area': '总体损耗',
                'issue': f"总损耗率{overall['waste_rate']}%，超出萨利亚目标",
                'action': '立即开展损耗专项整治',
                'expected_benefit': f"若降至1%，可节约¥{round(ingredient_analysis['summary']['total_waste_amount'] * 0.5, 2)}"
            })
        
        # 食材建议
        high_waste_items = [a for a in ingredient_analysis.get('analysis', []) 
                           if a['waste_level'] in ['warning', 'alert']]
        
        for item in high_waste_items[:3]:
            recommendations.append({
                'priority': 'medium',
                'area': item['ingredient_name'],
                'issue': f"损耗率{item['waste_rate']}%",
                'action': item['root_cause'][0] if item['root_cause'] else '深入分析损耗原因',
                'expected_benefit': f"若降至正常水平，可节约¥{round(item['total_waste'] * 0.5, 2)}/周"
            })
        
        return recommendations


def main():
    parser = argparse.ArgumentParser(description='餐饮门店损耗分析工具')
    parser.add_argument('--date', type=str, help='分析日期 (YYYY-MM-DD)')
    parser.add_argument('--output', type=str, default='waste_report.json', help='输出文件名')
    parser.add_argument('--mode', type=str, default='daily', choices=['daily', 'trend'], help='分析模式')
    
    args = parser.parse_args()
    
    analyzer = WasteAnalyzer()
    
    # 示例数据
    sample_data = {
        'date': args.date or datetime.now().strftime('%Y-%m-%d'),
        'total_purchase': 10000.0,
        'total_waste': 180.0,
        'ingredients': [
            {
                'ingredient_name': '鸡肉',
                'purchase_amount': 2000.0,
                'actual_usage': 1900.0,
                'theoretical_usage': 1850.0,
                'waste_details': {
                    'processing': 60.0,
                    'storage': 30.0,
                    'production': 10.0
                }
            },
            {
                'ingredient_name': '蔬菜',
                'purchase_amount': 1500.0,
                'actual_usage': 1350.0,
                'theoretical_usage': 1320.0,
                'waste_details': {
                    'processing': 100.0,
                    'storage': 30.0,
                    'production': 20.0
                }
            },
            {
                'ingredient_name': '大米',
                'purchase_amount': 800.0,
                'actual_usage': 790.0,
                'theoretical_usage': 785.0,
                'waste_details': {
                    'processing': 5.0,
                    'storage': 5.0
                }
            }
        ]
    }
    
    try:
        report = analyzer.generate_waste_report(sample_data)
        
        # 输出结果
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        
        print(f"[SUCCESS] 损耗分析报告已生成: {args.output}")
        print(f"\n[INFO] 核心指标:")
        print(f"  - 总损耗率: {report['overall']['waste_rate']}%")
        print(f"  - 损耗等级: {report['overall']['waste_level']}")
        print(f"  - 萨利亚目标: 1.0%")
        print(f"  - 差距: {report['overall']['waste_rate'] - 1.0}%")
        
        if report['recommendations']:
            print(f"\n[RECOMMENDATION] 改进建议:")
            for rec in report['recommendations'][:3]:
                print(f"  - [{rec['priority'].upper()}] {rec['area']}: {rec['action']}")
        
        return 0
        
    except Exception as e:
        print(f"[ERROR] 损耗分析失败: {str(e)}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
