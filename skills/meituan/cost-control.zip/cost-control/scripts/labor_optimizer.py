#!/usr/bin/env python3
"""
餐饮门店人力优化引擎
排班优化、人效分析、人力成本控制

使用方式:
    python labor_optimizer.py --date 2024-01-15 --output labor_report.json
    python labor_optimizer.py --mode optimize --input schedule.csv
"""

import argparse
import json
import sys
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import numpy as np


class LaborOptimizer:
    """餐饮门店人力优化引擎"""
    
    def __init__(self):
        self.position_types = {
            'front_hall': {
                'name': '前厅',
                'target_efficiency': 3000,  # 目标人效（元/人/天）
                'min_staff': 1,
                'max_staff': 5
            },
            'kitchen': {
                'name': '后厨',
                'target_efficiency': 4000,
                'min_staff': 2,
                'max_staff': 8
            },
            'delivery': {
                'name': '外卖打包',
                'target_efficiency': 5000,
                'min_staff': 1,
                'max_staff': 3
            }
        }
        
        self.time_slots = [
            {'name': '早市', 'start': '07:00', 'end': '10:00', 'expected_ratio': 0.15},
            {'name': '午市', 'start': '11:00', 'end': '14:00', 'expected_ratio': 0.40},
            {'name': '下午', 'start': '14:00', 'end': '17:00', 'expected_ratio': 0.10},
            {'name': '晚市', 'start': '17:00', 'end': '21:00', 'expected_ratio': 0.35}
        ]
    
    def calculate_labor_efficiency(self, revenue: float, staff_count: int,
                                    position: Optional[str] = None) -> Dict:
        """
        计算人效
        
        参数:
            revenue: 营业额
            staff_count: 员工数量
            position: 岗位类型
        """
        if staff_count <= 0:
            return {'error': '员工数量必须大于0'}
        
        efficiency = revenue / staff_count
        
        result = {
            'revenue': round(revenue, 2),
            'staff_count': staff_count,
            'efficiency': round(efficiency, 2),
            'efficiency_per_hour': round(efficiency / 12, 2)  # 假设工作12小时
        }
        
        if position and position in self.position_types:
            target = self.position_types[position]['target_efficiency']
            result.update({
                'target': target,
                'gap': round(efficiency - target, 2),
                'achievement_rate': round(efficiency / target * 100, 2),
                'status': 'good' if efficiency >= target else 'warning' if efficiency >= target * 0.8 else 'poor'
            })
        
        return result
    
    def analyze_schedule(self, schedule_data: Dict) -> Dict:
        """
        分析排班合理性
        
        参数:
            schedule_data: {
                'date': '2024-01-15',
                'revenue': 15000,
                'staff_schedule': [
                    {
                        'position': 'front_hall',
                        'staff': [
                            {'name': '张三', 'start': '09:00', 'end': '21:00', 'type': 'fulltime'},
                            {'name': '李四', 'start': '11:00', 'end': '14:00', 'type': 'parttime'}
                        ]
                    }
                ]
            }
        """
        revenue = schedule_data.get('revenue', 0)
        
        analysis = {
            'date': schedule_data.get('date', ''),
            'timestamp': datetime.now().isoformat(),
            'revenue': revenue,
            'total_staff_hours': 0,
            'total_labor_cost': 0,
            'position_analysis': []
        }
        
        for position_schedule in schedule_data.get('staff_schedule', []):
            position = position_schedule['position']
            staff_list = position_schedule['staff']
            
            # 计算总工时
            total_hours = 0
            for staff in staff_list:
                start = datetime.strptime(staff['start'], '%H:%M')
                end = datetime.strptime(staff['end'], '%H:%M')
                hours = (end - start).seconds / 3600
                total_hours += hours
            
            # 计算人效
            avg_staff = total_hours / 12  # 平均在岗人数
            efficiency = self.calculate_labor_efficiency(revenue / 3, max(1, int(avg_staff)), position)
            
            # 计算人力成本（简化）
            hourly_rate = 20 if position == 'front_hall' else 25  # 元/小时
            labor_cost = total_hours * hourly_rate
            
            position_analysis = {
                'position': position,
                'position_name': self.position_types[position]['name'],
                'staff_count': len(staff_list),
                'total_hours': round(total_hours, 2),
                'avg_staff': round(avg_staff, 2),
                'labor_cost': round(labor_cost, 2),
                'efficiency': efficiency,
                'status': efficiency.get('status', 'unknown')
            }
            
            analysis['position_analysis'].append(position_analysis)
            analysis['total_staff_hours'] += total_hours
            analysis['total_labor_cost'] += labor_cost
        
        # 总体分析
        analysis['overall_efficiency'] = round(revenue / max(1, analysis['total_staff_hours'] / 12), 2)
        analysis['labor_cost_ratio'] = round(analysis['total_labor_cost'] / revenue * 100, 2) if revenue > 0 else 0
        
        # 生成优化建议
        analysis['optimization_suggestions'] = self._generate_optimization_suggestions(analysis)
        
        return analysis
    
    def _generate_optimization_suggestions(self, analysis: Dict) -> List[Dict]:
        """生成排班优化建议"""
        suggestions = []
        
        for pos_analysis in analysis.get('position_analysis', []):
            position = pos_analysis['position']
            efficiency = pos_analysis['efficiency']
            
            # 人效低于目标
            if efficiency.get('status') in ['warning', 'poor']:
                suggestions.append({
                    'priority': 'high' if efficiency['status'] == 'poor' else 'medium',
                    'position': pos_analysis['position_name'],
                    'issue': f"人效{efficiency['efficiency']}元/人，低于目标{efficiency.get('target', 0)}元/人",
                    'action': '考虑减少低峰时段人员配置，或增加高峰时段营收',
                    'expected_improvement': f"人效可提升至{efficiency.get('target', 0)}元/人"
                })
            
            # 人力成本过高
            if pos_analysis['labor_cost'] / analysis['revenue'] * 100 > 8:
                suggestions.append({
                    'priority': 'medium',
                    'position': pos_analysis['position_name'],
                    'issue': f"人力成本占比{round(pos_analysis['labor_cost'] / analysis['revenue'] * 100, 2)}%，过高",
                    'action': '优化排班，减少非必要工时',
                    'expected_improvement': f"可节约¥{round(pos_analysis['labor_cost'] * 0.2, 2)}"
                })
        
        return suggestions
    
    def optimize_schedule(self, revenue_forecast: Dict, constraints: Dict) -> Dict:
        """
        优化排班（基于萨利亚30分钟精细排班原则）
        
        参数:
            revenue_forecast: {
                '07:00-07:30': 500,
                '07:30-08:00': 600,
                ...
            }
            constraints: {
                'min_staff_per_position': {'front_hall': 1, 'kitchen': 2},
                'available_staff': [...],
                'hourly_rate': 20
            }
        """
        # 萨利亚原则：以30分钟为单位精细排班
        time_units = []
        for hour in range(7, 22):  # 07:00 - 22:00
            for minute in [0, 30]:
                time_key = f"{hour:02d}:{minute:02d}"
                next_time = f"{hour:02d}:{minute+30:02d}" if minute == 0 else f"{hour+1:02d}:00"
                
                # 预测该时段营收
                forecast = revenue_forecast.get(f"{time_key}-{next_time}", 0)
                
                # 计算所需人数（基于营收预测）
                required_staff = self._calculate_required_staff(forecast, constraints)
                
                time_units.append({
                    'time': time_key,
                    'forecast_revenue': forecast,
                    'required_staff': required_staff
                })
        
        return {
            'optimization_method': '萨利亚30分钟精细排班法',
            'time_units': time_units,
            'total_staff_hours': sum(t['required_staff']['total'] * 0.5 for t in time_units),
            'estimated_cost': sum(t['required_staff']['total'] * 0.5 * constraints.get('hourly_rate', 20) for t in time_units),
            'principle': '高峰时段充足人手，低峰时段精简人力，灵活用工占比30-40%'
        }
    
    def _calculate_required_staff(self, forecast_revenue: float, constraints: Dict) -> Dict:
        """计算所需员工数"""
        # 简化模型：每1000元营收需要1人
        base_staff = max(1, int(forecast_revenue / 1000))
        
        min_staff = constraints.get('min_staff_per_position', {})
        
        return {
            'front_hall': max(min_staff.get('front_hall', 1), int(base_staff * 0.4)),
            'kitchen': max(min_staff.get('kitchen', 2), int(base_staff * 0.5)),
            'delivery': max(min_staff.get('delivery', 1), int(base_staff * 0.1)),
            'total': base_staff
        }
    
    def analyze_overtime(self, attendance_data: List[Dict]) -> Dict:
        """
        分析加班情况
        
        参数:
            attendance_data: [
                {
                    'staff_name': '张三',
                    'scheduled_hours': 8,
                    'actual_hours': 10,
                    'overtime_hours': 2
                }
            ]
        """
        total_scheduled = sum(a['scheduled_hours'] for a in attendance_data)
        total_actual = sum(a['actual_hours'] for a in attendance_data)
        total_overtime = sum(a['overtime_hours'] for a in attendance_data)
        
        overtime_ratio = (total_overtime / total_scheduled * 100) if total_scheduled > 0 else 0
        
        # 识别高加班人员
        high_overtime_staff = [a for a in attendance_data if a['overtime_hours'] > 10]
        
        return {
            'total_staff': len(attendance_data),
            'total_scheduled_hours': round(total_scheduled, 2),
            'total_actual_hours': round(total_actual, 2),
            'total_overtime_hours': round(total_overtime, 2),
            'overtime_ratio': round(overtime_ratio, 2),
            'high_overtime_staff': len(high_overtime_staff),
            'status': 'normal' if overtime_ratio < 10 else 'warning' if overtime_ratio < 20 else 'alert',
            'recommendations': [
                '合理安排排班，减少加班',
                '培养多技能员工，灵活调配',
                '高峰时段增加兼职人员'
            ] if overtime_ratio > 10 else []
        }


def main():
    parser = argparse.ArgumentParser(description='餐饮门店人力优化工具')
    parser.add_argument('--date', type=str, help='分析日期 (YYYY-MM-DD)')
    parser.add_argument('--output', type=str, default='labor_report.json', help='输出文件名')
    parser.add_argument('--mode', type=str, default='analyze', choices=['analyze', 'optimize'], help='运行模式')
    
    args = parser.parse_args()
    
    optimizer = LaborOptimizer()
    
    # 示例数据
    sample_schedule = {
        'date': args.date or datetime.now().strftime('%Y-%m-%d'),
        'revenue': 15000,
        'staff_schedule': [
            {
                'position': 'front_hall',
                'staff': [
                    {'name': '张三', 'start': '09:00', 'end': '21:00', 'type': 'fulltime'},
                    {'name': '李四', 'start': '11:00', 'end': '14:00', 'type': 'parttime'},
                    {'name': '王五', 'start': '17:00', 'end': '21:00', 'type': 'parttime'}
                ]
            },
            {
                'position': 'kitchen',
                'staff': [
                    {'name': '赵六', 'start': '08:00', 'end': '20:00', 'type': 'fulltime'},
                    {'name': '钱七', 'start': '10:00', 'end': '22:00', 'type': 'fulltime'}
                ]
            }
        ]
    }
    
    try:
        report = optimizer.analyze_schedule(sample_schedule)
        
        # 输出结果
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        
        print(f"[SUCCESS] 人力分析报告已生成: {args.output}")
        print(f"\n[INFO] 核心指标:")
        print(f"  - 总工时: {report['total_staff_hours']}小时")
        print(f"  - 人力成本: ¥{report['total_labor_cost']}")
        print(f"  - 人力成本率: {report['labor_cost_ratio']}%")
        print(f"  - 整体人效: ¥{report['overall_efficiency']}/人")
        
        if report['optimization_suggestions']:
            print(f"\n[OPTIMIZATION] 优化建议:")
            for sug in report['optimization_suggestions'][:2]:
                print(f"  - [{sug['priority'].upper()}] {sug['position']}: {sug['action']}")
        
        return 0
        
    except Exception as e:
        print(f"[ERROR] 人力分析失败: {str(e)}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
